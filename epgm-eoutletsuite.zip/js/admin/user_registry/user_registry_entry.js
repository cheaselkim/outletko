$(document).ready(function(){

	business_type();
	subscription_type();
	currency();
	account_id();

	$("#subscription_date").keyup(function(){
		renewal_date();
	});

	$("#subscription_date").click(function(){
		renewal_date();
	});

	$("#subscription_type").change(function(){
		renewal_date();
	});

	$("#business_type").change(function(){
		account_id();
	});

	$("#save").click(function(){
		save();
	});


});	

function business_type(){
	$.ajax({
		type : "GET",
		dataType : "JSON",
		url : base_url + "User_registry/business_type",
		success: function(data){
            for (var i = 0; i < data.length; i++) {
                $("#business_type").append("<option value='"+data[i].id+"'>"+data[i].desc +"</option>");
            }			
		},error: function(err){
			console.log(err.responseText);
		}
	})
}

function subscription_type(){
	$.ajax({
		type : "GET",
		dataType : "JSON",
		url : base_url + "User_registry/subscription_type",
		success : function(data){
            for (var i = 0; i < data.length; i++) {
                $("#subscription_type").append("<option value='"+data[i].id+"' data-days = '"+data[i].days+"'>"+data[i].desc +"</option>");
            }			
            $("#subscription_type").val("5");
		}, error : function(err){
			console.log(err.responseText);
		}
	})
}

function currency(){
	$.ajax({
		url : base_url + "User_registry/currency",
		type : "GET",
		dataType : "JSON",
		success : function(data){
			for (var i = 0; i < data.length; i++) {
				$("#currency").append("<option value='"+data[i].id+"'>"+data[i].curr_code	+"</option>");
			}
		}, error: function(err){
			console.log(err.responseText);
		}
	});	
}

function account_id(){
	var business_type = $("#business_type").val();

	$.ajax({
		type : "GET",
		dataType : "JSON",
		url : base_url + "User_registry/account_id",
		success : function(result){
			var account_id = result.year + business_type + result.account_id;
			$("#account_no").val(account_id);
		}, error : function(err){
			console.log(err.responseText);
		}
	});

}

function renewal_date(){
	var date = $("#subscription_date").val();
	var days = $("#subscription_type option:selected").data("days");
	var newdate = new Date(date);
	newdate.setDate(newdate.getDate() + days);
	var renewal_date = $.datepicker.formatDate("yy-mm-dd", newdate);
	$("#renewal_date").val(renewal_date);
}

function save(){

	var last_name = $("#last_name").val();
	var first_name = $("#first_name").val();
	var middle_name = $("#middle_name").val();
	var email = $("#email").val();
	var mobile_no = $("#mobile_no").val();
	var phone_no = $("#phone_no").val();
	var address = $("#address_no").val();
	var account_id = $("#account_no").val();
	var account_name = $("#account_name").val();
	var account_status = $("#account_status").val();
	var currency = $("#currency").val();
	var business_type = $("#business_type").val();
	var subscription_type = $("#subscription_type").val();
	var subscription_date = $("#subscription_date").val();
	var renewal_date = $("#renewal_date").val();
	var recruited_by = $("#recruited_by").val();
	var outlet = $("#no_outlet").val();
	var vat = $("#vat").val();

	var data = {last_name : last_name, first_name : first_name, middle_name : middle_name, email : email, mobile_no : mobile_no, 
		phone_no : phone_no, address : address, account_id : account_id, account_name : account_name, account_status : account_status,
		currency : currency, business_type : business_type, subscription_type : subscription_type, subscription_date : subscription_date,
		renewal_date : renewal_date, recruited_by : recruited_by, outlet : outlet, vat : vat}

	console.log(data);

	$.ajax({
		data : data,
		type : "POST",
		dataType : "JSON",
		url : base_url + "User_registry/insert_account",
		crossOrigin: false,
		success : function(result){
			swal({
				title : "Successfully Saved",
				type : "success",
				timer: 2000
			}, function(){
				location.reload();
			})
		}, error : function(err){
			console.log(err.responseText);
		}
	});

}