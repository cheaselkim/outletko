$(document).ready(function(){

	report_type();
	report();
	outlet();

	$("#div-sales-transaction").hide();
	$("#div-sales-product").hide();
	$("#div-sales-agent").hide();
	$("#div-inventory").hide();

	$(".total_amount").number(true,2);
	$(".total_trans").number(true,0);
	$(".total_share").number(true,0);

	$("#report_type").change(function(){
		reports();
	});

	$("#view").click(function(){
		report();
	});

});

function report_type(){
	$.ajax({
		type : "GET",
		dataType : "JSON",
		url : base_url + "Report/report_type",
		success : function(data){
			for (var i = 0; i < data.length; i++) {
				$("#report_type").append("<option value='"+data[i].report_type+"'>"+data[i].report_type +"</option>");
			}
			reports();
		}, error : function(err){
			console.log("error" + err.responseText);
		}
	})
}

function reports(){
	var report_type = $("#report_type").val();
	$("#reports").empty();
	$.ajax({
		data : {report_type : report_type},
		type : "POST",
		dataType : "JSON",
		url : base_url + "Report/reports",
		success : function(data){
			for (var i = 0; i < data.length; i++) {
				$("#reports").append("<option value='"+data[i].id+"'>"+data[i].report_name +"</option>");
			}
			report();
		}, error : function(err){
			console.log(err.responseText);
		}
	})
}

function outlet(){
	$.ajax({
		type : "GET",
		dataType : "JSON",
		url : base_url + "Report/outlet",
		success : function(data){
			for (var i = 0; i < data.length; i++) {
				$("#outlet").append("<option value='"+data[i].outlet_id+"'>"+data[i].outlet_code +"</option>");
			}			
		}, error : function(err){
			console.log(err.responseText);
		}
	})
}

function report(){
	var report = $("#reports").val();
	var fdate = $("#fdate").val();
	var tdate = $("#tdate").val();
	var outlet = $("#outlet").val();

	$.ajax({
		data : {report : report, fdate : fdate, tdate : tdate, outlet : outlet},
		type : "POST",
		dataType : "JSON",
		url : base_url + "Report/report",
		success : function(result){	
			$("#div-report").html(result);
			total_report(report);
		}, error : function(err){
			console.log(err.responseText);
		}
	})
}

function total_report(report){
	$(".div-total").hide();
	var trans = $("table tbody tr").length;
	var total_amount = 0;
	var total_qty = 0;
	var total_share = 0;
	
	if (report == "2" || report == "3" || report == "4"){

      	$('.table tbody tr').each(function (row, tr){
         	total_amount += Number(str_to_num($(tr).find("td:eq(4)").text()));
       	});		

		$("#div-sales-transaction").show();
		$("#div-sales-transaction #total_trans").val(trans);
		$("#div-sales-transaction #total_amount").val(total_amount);
	}else if (report == "7"){
      	$('.table tbody tr').each(function (row, tr){
         	total_amount += Number(str_to_num($(tr).find("td:eq(7)").text()));
         	total_qty += Number(str_to_num($(tr).find("td:eq(4)").text()));         	
       	});		

		$("#div-sales-product").show();
		$("#div-sales-product #total_trans").val(total_qty);
		$("#div-sales-product #total_amount").val(total_amount);		
	}else if (report == "8"){
      	$('.table tbody tr').each(function (row, tr){
         	total_amount += Number(str_to_num($(tr).find("td:eq(3)").text()));
         	total_share += Number(str_to_num($(tr).find("td:eq(4)").text()));         	
       	});		

		$("#div-sales-agent").show();
		$("#div-sales-agent #total_share").val(total_share);
		$("#div-sales-agent #total_amount").val(total_amount);		
	}else if (report == "9" || report == "10" || report == "11" || report == "12"){
		$("#div-inventory").show();
		$("#div-inventory #total_trans").val(trans);
	}
}