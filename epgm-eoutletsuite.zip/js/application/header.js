$(document).ready(function(){


	all_access();
	transaction();

	setInterval(function() {
		transaction();
	}, 5000);

	if ($("#span_outlet_id").text() == ""){
		// $("#modal_outlet").modal("show");
		count_outlet();
	}else{
		$("#modal_outlet").modal("hide");
	}

	$("#btn_main_menu").click(function(){
		main_menu($("#main_menu_module").val());
	});

	if ($("#main_menu_module").val() <= 0){
		$("#btn_main_menu").attr("disabled", true);
	}

	$('.disabled').on('click',function(e){
		return false;
	})

	$("#total_sales_for_today").number(true, 2);

	// report_menu();

});

function transaction(){
	$.ajax({
		type : "GET",
		dataType : "JSON",
		url :base_url + "Header/get_transaction",
		success: function(result){
			$("#last_tran_no").text(result.last_trans);
			$("#no_of_trans").text(result.no_of_trans);
			$("#total_sales_for_today").val(result.total_sales);
		}, error: function(err){
			console.log(err.responseText);
		}
	});	
}

function count_outlet(){
	$.ajax({
		type : "GET",
		dataType : "JSON",
		url :base_url + "Header/count_outlet",
		success: function(result){
			if (result.count > 1){
				$("#modal_outlet").modal("show");
				$("#div_list_outlet").html(result.outlet);
			}else{
				select_outlet(result.outlet);
			}
		}, error: function(err){
			console.log(err.responseText);
		}
	});
}

function find_user_outlet(){
	$.ajax({
		type : "GET",
		dataType : "JSON",
		url : "Header/find_user_outlet",
		success : function(result){
			$("#div_list_outlet").html(result);
		}, error : function(err){
			console.log(err.responseText);
		}
	});
}

function select_outlet(id){
	$.ajax({
		data : {"id" : id},
		type : "POST",
		dataType : "JSON",
		url : base_url + "Header/select_outlet",
		success : function(result){
			$("#modal_outlet").modal("hide");
			$("#span_outlet_id").text(result);
			all_access();
		}, error : function(err){
			console.log(err.responseText);
		}
	});
}

function all_access(){
	$.ajax({
		type : "GET",
		dataType : "JSON",
		url : base_url + "Header/all_access",
		success : function(data){
			if (data.result == "1"){
				for (var i = 1; i <= 8; i++) {
					$("#menu_"+i).removeClass("disabled");
				}
			}else{
				var access = data.access;
				for (var i = 0; i < access.length; i++) {
					$("#menu_"+ access[i].module_id).removeClass("disabled");
				}
			}
		}, error : function(err){
			console.log(err.responseText);
		}
	});	
}

function select_function($sub_module, $function){
	var $module = $("#menu_module").val();
	window.open(base_url + "app/" + $module + "/" + $sub_module + "/" + $function, "_self");
}

function main_menu($module){
	$.ajax({
		data : {"module" : $module, "sub_module" : "0"},
		type : "POST",
		dataType : "JSON",
		url : base_url + "Header/roles",
		success : function(result){
		    console.log(result);
			if ($module == "7" || $module == "6"){
				console.log($("#div-query").is(":visible"));
				if ($("#div-query").is(":visible") == true){
					window.open(base_url, "_self");
				}else{
					window.open(base_url + "app/"+$module+"/0/4", "_self");
				}
			}else{
				// if (result.count == 1){
				// 	window.open(base_url + "app/"+$module+"/" + result.roles, "_self");
				// }else{
					$("#header-menu").text(result.menu);
					$("#menu-content").html(result.roles);
					$("#sales_modal").modal("show");
					if ($module == "4"){
						$("#sales_modal").css("margin-top", "-10%");
					}
				// }				
			}

		}, error : function(err){
			console.log(err.responseText);
		}
	});
}

function product(){
	$("#prod_modal").modal("show");
}

function str_to_num(string){
	return string.replace(/,/g,"");
}

function report_menu(){
	var main_menu_module = $("#main_menu_module").val();
    var desktopView = $(document).width();

	if($("#div-report-menu").is(":visible")){
		$("#div-report-menu").hide(500);
		if (main_menu_module == 0){
			$(".div-body-menu").show(500);
		}else{
		}
	} else{
		$(".div-body-menu").hide(500);
		$("#div-report-menu").show(500);
	}	

}

