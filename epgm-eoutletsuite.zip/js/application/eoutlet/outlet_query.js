$(document).ready(function(){
    
  index();
  outlet_type();

  var app_func = $("#outlet_func").val();

  if (app_func == "3"){
    $("#div-outlet-status").show();
  }else{
    $("#div-outlet-status").hide();
  }

  $('#outlet_search').click(function() {
    var type = $("#outlet_type").val();
    var status = $('#outlet_status').val();
    index(type,status);
  });

  $('#outlet_type').change(function() {
    var type = $(this).val();
    var status = $('#outlet_status').val();
    index(type,status);
  });

  $('#outlet_status').change(function() {
    var status = $(this).val();
    var type = $('#outlet_type').val();
    index(type,status);
  });

  $('#search').click(function() {
    var type = "";
    var status = "";
    var term = $('#search_box').val();
    index(type,status,term);
  });

  $("#search_box").autocomplete({
    minLength: 0,
    source: base_url + "outlet/search_field/",
    focus: function( event, ui ) {
      return false;
    },
    select: function( event, ui ) {
      $(this).val(ui.item.term);
      return false; 
    }
  })
  .autocomplete( "instance" )._renderItem = function( ul, item ) {
    return $( "<li>" )
    .append( "<div>" + item.term + "</div>" )
    .appendTo( ul );
  };   


});

function outlet_type(){
  $.ajax({
    url : base_url + "Outlet/outlet_type",
    type : "GET",
    dataType : "JSON",
    success : function(data){
      for (var i = 0; i < data.length; i++) {
        $("#outlet_type").append("<option value='"+data[i].id+"'>"+data[i].outlet_type  +"</option>");
      }
    }, error: function(err){
      console.log(err.responseText);
    }
  });

}

function index(type="",status="",term=""){
  var app_func = $("#outlet_func").val();
  $.ajax({
    data: {type : type, status: status,term:term, app_func : app_func}, 
    type: "POST", 
    url : base_url +  "Outlet/outlet_list",
    dataType : "JSON",
    success : function(result){
      $("#query-table").html(result);
    }, error: function(err){
      console.log(err.responseText);
    }
  });

}

function view_outlet(id){

  $("#mod_quota").number(true,2);
  $("#modal_query").find(":input").attr("readonly", true);
  $("#modal_query").modal("show");
  $.ajax({
    data : {"id" : id},
    url : base_url + "Outlet/select_id",
    type : "POST",
    dataType : "JSON",
    success : function (result){
      $("#modal_query").modal("show");
      $("#mod_no").val(result[0].outlet_code);
      $("#mod_name").val(result[0].outlet_name);
      $("#mod_loc").val(result[0].outlet_location);
      $("#mod_city").val(result[0].city_desc);
      $("#mod_province").val(result[0].province_desc);
      $("#mod_type").val(result[0].outlet_type_desc);
      $("#mod_quota").val(result[0].outlet_monthly_quota);
      $("#mod_status").val(result[0].status_desc);
    }, error : function(err){
      console.log(err.responseText);
    }
  });
}

function delete_outlet(id,key){
  var trans_no = $("#tbl-outlet tbody tr:eq("+(key)+")").find("td:eq(2)").text();
  swal({
    title: "Are you sure do you want to Delete "+trans_no+" ?",
    type: "warning",
    showCancelButton: true,
    confirmButtonColor: '#DD6B55',
    confirmButtonText: 'Confirm',
    closeOnConfirm: false,
    closeOnCancel: false,
    timer: 3000
  },function(isConfirm){
    if (isConfirm){
      $.ajax({
        data : {"id" : id},
        url : base_url + "Outlet/delete_outlet",
        type : "POST",
        dataType : "JSON",
        success : function (result){
          index();
          swal("Successfully Delete", "", "success");
        }, error : function(err){
          console.log(err.responseText);
        }       
      });
    }else{
        swal("Cancelled", "", "error");
    }
  });


}

function edit_outlet(id){
  $("body").empty();
  $("body").load(base_url + "menu/edit_menu/2/0/2/"+id);
}