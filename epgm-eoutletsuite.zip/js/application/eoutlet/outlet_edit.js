$(document).ready(function(){

  var id = $("#outlet_id").val();
  get_outlet_dtl(id)

  $("#save_outlet").click(function(){
    var outlet_no = $('#outlet_no').val();
    save_outlet(outlet_no);
  });

});

function get_outlet_dtl(id){
  $.ajax({
    data : {"id" : id},
    url : base_url + "Outlet/get_outlet_dtl",
    type : "POST",
    dataType : "JSON",
    success : function(data){
      $('#outlet_no').val(data.outlet_dtl[0]['outlet_code']);
      $('#outlet_name').val(data.outlet_dtl[0]['outlet_name']);
      $('#outlet_location').val(data.outlet_dtl[0]['outlet_location']);
      $('#outlet_city').val(data.outlet_dtl[0]['outlet_city']);
      $('#outlet_province').val(data.outlet_dtl[0]['outlet_province']);
      $('#outlet_type').val(data.outlet_dtl[0]['outlet_type']);
      $('#outlet_quota').val(data.outlet_dtl[0]['outlet_monthly_quota']);
      $('#outlet_status').val(data.outlet_dtl[0]['outlet_status']);
    }, error: function(err){
      console.log(err.responseText);
    }
  });
}

function save_outlet(outlet_no){
      var outlet_code = $('#outlet_no').val();
      var outlet_name = $('#outlet_name').val();
      var outlet_location = $('#outlet_location').val();
      var outlet_city = $('#outlet_city').val();
      var outlet_province = $('#outlet_province').val();
      var outlet_type = $('#outlet_type').val();
      var outlet_monthly_quota = $('#outlet_quota').val();
      var outlet_status = $('#outlet_status').val();
      if(jQuery.trim(outlet_code).length <= 0 || jQuery.trim(outlet_name).length <= 0 || jQuery.trim(outlet_location).length <= 0 
        || jQuery.trim(outlet_city).length <= 0 || jQuery.trim(outlet_province).length <= 0 
        || jQuery.trim(outlet_type).length <= 0 || jQuery.trim(outlet_monthly_quota).length <= 0 
        || jQuery.trim(outlet_status).length <= 0) {
            alert('Please fill up required fields.');
            return false            
      }
      var outlet_hdr = {
            
            outlet_name : outlet_name,
            outlet_location : outlet_location,
            outlet_city : outlet_city,
            outlet_province : outlet_province,
            outlet_type : outlet_type,
            outlet_monthly_quota : outlet_monthly_quota,
            outlet_status : outlet_status, 
      } 
      var data = {outlet_hdr:outlet_hdr,outlet_id: outlet_code};
      console.log(data);
      //return false;
      $.ajax({

            data : data
            , type: "POST"
            , url: base_url + "Outlet/update_outlet"
            , dataType: 'json'
            , crossOrigin: false     
            , success: function(result) {
              swal({
                title : "Successfully Updated",
                type : "success",
                timer: 2000
              }, function(){
                location.reload();
              });
            }, error: function(err) {
                console.log(err.responseText);
            }
      });  
}

