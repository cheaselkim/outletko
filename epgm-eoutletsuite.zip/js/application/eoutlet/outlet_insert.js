$(document).ready(function(){

	$("#outlet_quota").number(true, 2);
		
	outlet_type();


	$("#outlet_city").keyup(function(){
		if ($(this).val() == ""){
			$("#outlet_province").val("");
		}
	});

	$("#outlet_city").autocomplete({
		focus: function(event, ui){
			$("#outlet_province").val(ui.item.outlet_province);
		},
		select: function(event, ui){
			$("#outlet_province").val(ui.item.outlet_province);
			$("#outlet_city_id").val(ui.item.city_id);
			$("#outlet_province_id").val(ui.item.prov_id);
		},
		source: function(req, add){
			var outlet_city = $("#outlet_city").val();
            $.ajax({
                url: base_url + "Outlet/search_outlet_city/", 
                dataType: "json",
                type: "POST",
                data: {'outlet_city' : outlet_city},
                success: function(data){
                    if(data.response =="true"){
                        add(data.result);
                    }else{
                    	$("#outlet_city").val("");
                    	$("#outlet_province").val("");
                        add('');
                    }
                }, error: function(err){
                	console.log("Error: " + err.responseText);
                }
            });
		}
	});

	$("#save_outlet").click(function(){
		save_outlet();
	});

});

function outlet_type(){
	$.ajax({
		url : base_url + "Outlet/outlet_type",
		type : "GET",
		dataType : "JSON",
		success : function(data){
			for (var i = 0; i < data.length; i++) {
				$("#outlet_type").append("<option value='"+data[i].id+"'>"+data[i].outlet_type	+"</option>");
			}
		}, error: function(err){
			console.log(err.responseText);
		}
	});

}


function save_outlet(){
      var outlet_code = $('#outlet_no').val();
      var outlet_name = $('#outlet_name').val();
      var outlet_location = $('#outlet_location').val();
      var outlet_city = $('#outlet_city').val();
      var outlet_province = $('#outlet_province').val();
      var outlet_type = $('#outlet_type').val();
      var outlet_monthly_quota = $('#outlet_quota').val();
      var outlet_status = $('#outlet_status').val();
      if(jQuery.trim(outlet_code).length <= 0 || jQuery.trim(outlet_name).length <= 0 || jQuery.trim(outlet_location).length <= 0 
        || jQuery.trim(outlet_city).length <= 0 || jQuery.trim(outlet_province).length <= 0 
        || jQuery.trim(outlet_type).length <= 0 || jQuery.trim(outlet_monthly_quota).length <= 0 
        || jQuery.trim(outlet_status).length <= 0) {
            swal("Please fill up required fields.", "", "error")
            return false            
      }
      var outlet_hdr = {
            outlet_code : outlet_code,
            outlet_name : outlet_name,
            outlet_location : outlet_location,
            outlet_city : outlet_city,
            outlet_province : outlet_province,
            outlet_type : outlet_type,
            outlet_monthly_quota : outlet_monthly_quota,
            outlet_status : outlet_status, 
      } 

      var data = {outlet_hdr:outlet_hdr};
      //return false;
      $.ajax({

            data : data
            , type: "POST"
            , url: base_url + "Outlet/save_outlet"
            , dataType: 'json'
            , crossOrigin: false     
            , success: function(result) {
              swal({
                title : "Successfully Insert",
                type : "success",
                timer: 2000
              }, function(){
                location.reload();
              });
            }, error: function(err) {
                console.log("Error : " + err.responseText);
            }
      });  
};