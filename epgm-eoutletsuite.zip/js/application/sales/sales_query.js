$(document).ready(function(){

	search_query();

	var app_func = $("#app_func").val();

	if (app_func == "3"){
		$("#status").show();
		$("#lbl_status").show();
	}else{
		$("#status").hide();
		$("#lbl_status").hide();
	}

	$("#btn_search").click(function(){
		search_query();
	});


});

function pad(num, size) {
    var s = num+"";
    while (s.length < size) s = "0" + s;
    return s;
}

function search_query(){
	var keyword = $("#keyword").val();
	var status = $("#status").val();
	var app_func = $("#app_func").val();

	$.ajax({
		data : {"keyword" : keyword, "status" : status, "type" : app_func},
		url : base_url + "Sales/sales_query",
		type : "POST",
		dataType : "JSON",
		success : function(result){
			$("#div_query_tbl").html(result);
		}, error: function(err){
			console.log(err.responseText);
		}
	});	

}

function view_query(id){

	$("#modal_query").modal("show");
	$("#mod_discount_sales").number(true,2);
	$("#mod_tot_amount").number(true,2);
	$("#mod_tot_vat").number(true,2);
	$("#mod_net_vat").number(true,2);
	$.ajax({
		data : {"id" : id},
		url : base_url + "Sales/select_id",
		type : "POST",
		dataType : "JSON",
		success : function (result){
			var data = result.header;
			$("#div_query_items").html(result.detail);
			$("#mod_cust_code").val(data[0].cust_code);
			$("#mod_cust_name").val(data[0].cust_name);
			$("#mod_trans_no").val(data[0].trans_no);
			$("#mod_discount_sales").val(data[0].sales_discount);
			$("#mod_tot_amount").val(data[0].total_amount);
			$("#mod_tot_vat").val(data[0].vat_amount);
			$("#mod_net_vat").val(data[0].net_vat);
		}, error : function(err){
			console.log(err.responseText);
		}
	});
}

function view_cancel(id,trans_no){

	swal({
		title: "Are you sure do you want to Cancel Transaction #"+pad(trans_no, 5)+" ?",
		type: "warning",
		showCancelButton: true,
		confirmButtonColor: '#DD6B55',
		confirmButtonText: 'Confirm',
		closeOnConfirm: false,
		closeOnCancel: false,
		timer: 2000
	},function(isConfirm){
		if (isConfirm){
			$.ajax({
				data : {"id" : id},
				url : base_url + "Sales/cancel_trans",
				type : "POST",
				dataType : "JSON",
				success : function (result){
					swal("Successfully Cancelled", "", "success");
					search_query();
				}, error : function(err){
					console.log(err.responseText);
				}				
			});
		}else{
		  	swal("Cancelled", "", "error");
		    e.preventDefault();
		}
	});


}

function edit_sales(id){
	$("body").empty();
	$("body").load(base_url + "menu/edit_menu/1/0/2/"+id);
}