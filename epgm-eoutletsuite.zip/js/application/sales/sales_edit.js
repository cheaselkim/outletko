$(document).ready(function(){

	get_transaction($("#trans_id").val());

	$("#save_edit_trans").click(function(){
		var trans_id = $('#trans_id').val();
		save_trans(trans_id);
	});


})

function get_transaction(id){
	console.log(id);
	$.ajax({
		data : {"id" : id},
		url : base_url + "Sales/get_transaction",
		type : "POST",
		dataType : "JSON",
		success : function(data){
			//For Header
			$("#trans_id").val(id);
			$("#cust_id").val(data.trans_hdr[0]['customer_id']);
			$("#cust_code").val(data.trans_hdr[0]['cust_code']);
			$("#cust_name").val(data.trans_hdr[0]['cust_name']);
			$("#sales_trans_no").text(data.trans_hdr[0]['trans_no']);
			$("#grand_total").val(data.trans_hdr[0]['total_amount']);
			$("#sales_discount").val(data.trans_hdr[0]['sales_discount']);
			//For Payment
			$("#payment_date").val(data.trans_payment[0]['payment_date']);
			$("#payment_type").val(data.trans_payment[0]['payment_type_id']);
			$("#bank_name").val(data.trans_payment[0]['bank_id']);
			$("#check_no").val(data.trans_payment[0]['check_card_no']);
			$("#check_date").val(data.trans_payment[0]['check_date']);
			$("#currency").val(data.trans_payment[0]['curr_id']);
			$("#payment_amount").val(data.trans_payment[0]['amount']);
			//For Details
			var i = 0;
			for(var x=0; x<data.trans_dtl.length; x++) {	
				i++;
				$("#tbl-products").append("<tr class='item_row_table'><td class='tbl_prod_no'>"+ i +
					"</td><td class='tbl_prod_name'>"+ data.trans_dtl[x]['product_name'] +
					"</td><td class='tbl_qty'>"+ data.trans_dtl[x]['qty'] +
					"</td><td class='tbl_stock_uom'>"+ data.trans_dtl[x]['unit_desc'] +
					"</td><td class='tbl_reg_price'>"+ data.trans_dtl[x]['reg_selling_price'] +
					"</td><td class='tbl_sel_price'>"+ data.trans_dtl[x]['selling_price'] +
					"</td><td class='tbl_total_price'>"+ data.trans_dtl[x]['total_price'] +
					"</td><td class='tbl_volume_discount' hidden>"+ data.trans_dtl[x]['volume_discount'] +
					"</td><td class='tbl_total_selling_price' hidden>"+ data.trans_dtl[x]['total_selling_price'] +
					"</td><td class='tbl_share_per' hidden>"+ data.trans_dtl[x]['share'] +
					"</td><td class='tbl_share_amount' hidden>"+ data.trans_dtl[x]['share_amount'] +
					"</td><td class='tbl_total_amount' hidden>"+ data.trans_dtl[x]['total_amount'] +
					"</td><td class='text-center text-red'>"+ "<i class='fa fa-minus-circle remove_item_table' style='color:red' id='remove_item_table'></i>" +
					"</td><td class='tbl_prod_id' hidden>"+ data.trans_dtl[x]['product_id'] +
					"</td></tr>");
			}

			
			
		}, error: function(err){
			console.log(err.responseText);
		}
	});
}

function save_trans(trans_id){
      //var agent_id =  $('#pr_no_modal').val();
      //var trans_id = $('#trans_id').val();
      var agent_id = '1'
      var cust_id =  $('#cust_id').val();
      var sales_discount =  $('#sales_discount').val();
      var grand_total =  $('#grand_total').val();
      var payment_date = $('#payment_date').val();
      var payment_type_id = $('#payment_type').val();
      //var bank_id = $('#bank_id').val();
      var bank_id = "1";
      var check_card_no = $('#check_no').val();
      var check_date = $('#check_date').val();
      var curr_id = $('#currency').val();
      var amount = $('#payment_amount').val();

      var dtl_data = [];
      var sales_hdr = {
            customer_id : cust_id,
            agent_id : "01",
            sales_discount : sales_discount,
            total_amount : grand_total
      } 

      if(jQuery.trim(payment_date).length <= 0 || jQuery.trim(amount).length <= 0) {
            alert('Please fill up required fields.');
            return false            
      }

      $('#tbl-products tr').each(function (row, tr){
                var sub = {
                    'product_id' : $(tr).find('td:eq(13)').text(),
                    'qty' : $(tr).find('td:eq(2) ').text(),
                    'selling_price' : $(tr).find('td:eq(5) ').text(),
                    'total_price' : $(tr).find('td:eq(6) ').text(),
                    'volume_discount' : $(tr).find('td:eq(7) ').text(),
                    'total_selling_price' :$(tr).find('td:eq(8) ').text(),
                    'share' :$(tr).find('td:eq(9) ').text(),
                    'share_amount' :$(tr).find('td:eq(10) ').text(),
                    'total_amount' :$(tr).find('td:eq(11) ').text()
                } 
                dtl_data.push(sub);            
       });

      var payment_data = {
            payment_date : payment_date,
            payment_type_id : payment_type_id,
            bank_id : bank_id,
            check_card_no : check_card_no,
            check_date : check_date,
            curr_id : curr_id,
            amount : amount
      }
      
      dtl_data.shift();
      var data = {sales_hdr:sales_hdr, sales_dtl: dtl_data,payment_dtl:payment_data, hdr_id: trans_id};
      //return false;
      $.ajax({

            data : data
            , type: "POST"
            , url: base_url + "Sales/edit_transaction"
            , dataType: 'json'
            , crossOrigin: false     
            , success: function(result) {
                alert('Successfuly Save.');
                location.reload();
            }, error: function(err) {
                console.log(err.responseText);
            }
      });  
};