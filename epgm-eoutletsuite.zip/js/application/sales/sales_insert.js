$(document).ready(function(){

	$("#stock_qty").number(true,2);
	$("#reg_price").number(true,2);
	$("#sel_price").number(true, 2);
	$("#qty").number(true, 2);
	$("#total_price").number(true,2);
	$("#volume_discount").number(true, 2);
	$("#total_selling_price").number(true,2);
	$("#share_per").number(true,2);
	$("#share_amount").number(true,2);
	$("#pay_total_amount").number(true,2);
	$("#payment_amount").number(true,2);
	$("#sales_discount").number(true,2);
	$("#grand_total").number(true,2);

	$("#check_date").attr("readonly", true);
	$("#bank_name").prop("disabled", true);
	$("#check_no").attr("readonly", true);			

	max_transno();
	currency();
	payment_type();
	bank_list();
	customer();

	$("#save_trans").click(function(){
		save_trans();
	});

	$("#cust_code").keyup(function(){
		if ($(this).val() == ""){
			$("#cust_name").val("");
		}
	});

	$("#cust_name").keyup(function(){
		if ($(this).val() == ""){
			$("#cust_code").val("");
		}
	});

	$("#cust_code").autocomplete({
		focus: function(event, ui){
			$("#cust_name").val(ui.item.cust_name);
			$("#cust_code").data("id", ui.item.id);
		},
		select: function(event, ui){
			$("#cust_name").val(ui.item.cust_name);
			$("#cust_code").data("id", ui.item.id);
		},
		source: function(req, add){
			var cust_code = $("#cust_code").val();
            $.ajax({
                url: base_url + "Sales/search_customer/"+1, 
                dataType: "json",
                type: "POST",
                data: {'customer' : cust_code},
                success: function(data){
                	console.log(data.response);
                    if(data.response =="true"){
                        add(data.result);
                    }else{
                        add('');
                    }
                }, error: function(err){
                	console.log("Error: " + err.responseText);
                }
            });
		}
	});

	$("#cust_name").autocomplete({
		focus: function(event, ui){
			$("#cust_code").val(ui.item.cust_code);
			$("#cust_code").data("id", ui.item.id);
		},
		select: function(event, ui){
			$("#cust_code").val(ui.item.cust_code);
			$("#cust_code").data("id", ui.item.id);
		},
		source: function(req, add){
			var cust_name = $("#cust_name").val();
            $.ajax({
                url: base_url + "Sales/search_customer/"+2, 
                dataType: "json",
                type: "POST",
                data: {'customer' : cust_name},
                success: function(data){
                    if(data.response =="true"){
                        add(data.result);
                    }else{
                        add('');
                    }
                }, error: function(err){
                	console.log("Error: " + err.responseText);
                }
            });
		}
	});

	$("#btn_select_item").click(function(){
		var item_cat = $("#item_category").val();
		var item_keyword = $("#item_keyword").val();
		search_item(item_cat, item_keyword);
	});

	$("#payment_type").change(function(){
			$("#check_date").val("");
			$("#bank_name").val("");
			$("#check_no").val("");
		if ($.trim($("#payment_type option:selected").text().toUpperCase()) != "CASH"){
			$("#check_date").attr("readonly", false);
			$("#bank_name").prop("disabled", false);
			$("#check_no").attr("readonly", false);
		}else{
			$("#check_date").attr("readonly", true);
			$("#bank_name").prop("disabled", true);
			$("#check_no").attr("readonly", true);			
		}
	});

	$("#sel_price").keyup(function(){
		compute_itemprice();
	});	

	$("#qty").keyup(function(){
		compute_itemprice();
	});

	$("#volume_discount").keyup(function(){
		compute_itemprice();
	});

	$("#sales_discount").keyup(function(){
		compute_grandtotal();
	});

	$("#add_item").click(function(){
		if ($("#qty").val() != 0){
			if ($("#tbl_item_row").val() != ""){
				edit_item_table();
			}else{
				add_item_table();
			}
		}
	});

	jQuery(document).on("click", ".remove_item_table", function(){
		$(this).closest("tr").remove();		
		compute_grandtotal();
	    setTimeout(function(){
			reset_input();
	    }, 300);
	});	

	jQuery(document).on("click", ".item_row_table", function(){
		var row = $(this).closest("tr").index();
		var id = $(this).closest("tr").find(".tbl_prod_id").text();
		select_item(id);
		select_row_table(row);
	});	


})

function max_transno(){
	$.ajax({
		url : base_url + "Sales/max_transno",
		type : "GET",
		dataType : "JSON",
		success : function(data){
			$("#sales_trans_no").text(data);
		}, error: function(err){
			console.log(err.responseText);
		}
	});	
}

function currency(){

	$.ajax({
		url : base_url + "Sales/currency",
		type : "GET",
		dataType : "JSON",
		success : function(data){
			for (var i = 0; i < data.length; i++) {
				$("#currency").append("<option value='"+data[i].id+"'>"+data[i].curr_code	+"</option>");
			}
		}, error: function(err){
			console.log(err.responseText);
		}
	});

}

function payment_type(){
	$.ajax({
		url : base_url + "Sales/payment_type",
		type : "GET",
		dataType : "JSON",
		success : function(data){
			for (var i = 0; i < data.length; i++) {
				$("#payment_type").append("<option value='"+data[i].id+"'>"+data[i].type_desc+"</option>");
			}
		}, error : function(err){
			console.log(err.responseText);
		}
	});
}

function bank_list(){

	$.ajax({
		url : base_url + "Sales/bank_list",
		type : "GET",
		dataType : "JSON",
		success : function(data){
			for (var i = 0; i < data.length; i++) {
				$("#bank_name").append("<option value='"+data[i].id+"'>"+data[i].bank_code+"</option>");
			}
		}, error : function(err){	
			console.log(err.responseText);
		}
	});
}

function customer (){
	cust_code = $("#cust_code").val();
	$.ajax({
	    url: base_url + "sales/search_customer/"+1, 
	    dataType: "json",
	    type: "POST",
	    data: {'customer' : cust_code},
	    success: function(data){
	        if(data.response =="true"){
				$("#cust_name").val(data.result[0].cust_name);
				$("#cust_code").data("id", data.result[0].id);
	        }else{
	        }
	    }, error: function(err){
	    	console.log("Error: " + err.responseText);
	    }
	});	
}

function search_item(item_cat, item_keyword){

	$.ajax({
		data : {"item_cat" : item_cat, "item_search" : "item_keyword"},
		url : base_url + "Sales/search_item",
		type : "POST",
		dataType : "JSON",
		success: function(result){
			$("#div-tbl-items").html(result);
		}, error: function(err){
			console.log(err.responseText);
		}
	});

}

function select_item(id){
	$("#prod_id").val(id);
	$.ajax({
		data : {"id" : id},
		url : base_url + "Sales/select_item",
		type : "POST",
		dataType : "JSON",
		success : function(data){
			$("#select_item_modal").modal("hide");
			$("#prod_no").val(data.prod_name);
			$("#prod_name").val(data.prod_no);
			$("#stock_qty").val(data.qty);
			$("#stock_uom").val(data.uom);
			$("#reg_price").val(data.price);
			$("#image-box").css("background-image", "url('"+base_url+"images/products/a.png')");
			$("#image-box").css("background-size", "150px 150px");
			$("#image-box").css("background-repeat", "no-repeat");
			$("#image-box").css("background-position", "center");
		}, error: function(err){
			console.log(err.responseText);
		}
	});	
}

function compute_itemprice(){

	var reg_price = $("#reg_price").val();
	var sel_price = $("#sel_price").val();
	var qty = $("#qty").val();
	var volume_discount = $("#volume_discount").val();
	var share_per = $("#share_per").val();

	var item_price = "";
	var total_price = "";
	var total_selling_price = "";
	var share_amount = "";
	var total_item_price = "";

	if (Number(sel_price) != 0){
		item_price = sel_price;
	}else{
		item_price = reg_price;
	}

	total_price = item_price * qty;
	total_selling_price = total_price - volume_discount;
	share_amount = total_selling_price * (share_per / 100);
	total_item_price = total_selling_price - share_amount;

	if ($("#prod_no").val() != ""){
		$("#total_price").val(total_price);
		$("#total_selling_price").val(total_selling_price);
		$("#share_amount").val(share_amount);
		$("#pay_total_amount").val(total_item_price);		
	}else{
		$("#sel_price").val("0");
		$("#qty").val("0");
		$("#volume_discount").val("0");
	}

}

function compute_grandtotal(){

	var total_selling_price = 0;
	var total_amount = 0;
	var sales_discount = $("#sales_discount").val();
	
	$("#tbl-products tbody tr").each(function(row, tr){
		total_selling_price += Number(str_to_num($(tr).find(".tbl_total_selling_price").text()));
		total_amount += Number($(tr).find(".tbl_total_amount").text()); 
	});	

	var grand_total = total_selling_price - sales_discount;

	$("#grand_total").val(grand_total);
}

function add_item_table(){
	$("#tbl-products tbody").append("<tr class='item_row_table'><td class='tbl_prod_no'>"+ $("#prod_no").val() +
		"</td><td class='tbl_prod_name'>"+ $("#prod_name").val() +
		"</td><td class='tbl_qty'>"+ $.number($("#qty").val(), 2) +
		"</td><td class='tbl_stock_uom'>"+ $("#stock_uom").val() +
		"</td><td class='tbl_reg_price'>"+ $.number($("#reg_price").val(), 2) +
		"</td><td class='tbl_sel_price'>"+ $.number($("#sel_price").val(), 2) +
		"</td><td class='tbl_total_price' hidden>"+ $.number($("#total_price").val(), 2) +
		"</td><td class='tbl_volume_discount'  hidden>"+ $("#volume_discount").val() +
		"</td><td class='tbl_total_selling_price'  >"+ $.number($("#total_selling_price").val(), 2) +
		"</td><td class='tbl_share_per' hidden>"+ $("#share_per").val() +
		"</td><td class='tbl_share_amount' hidden>"+ $("#share_amount").val() +
		"</td><td class='tbl_total_amount' hidden>"+ $("#pay_total_amount").val() +
		"</td><td class='text-center text-red remove_item'>"+ "<i class='fa fa-minus-circle remove_item_table' style='color:red;cursor:pointer;' id='remove_item_table'></i>" +
		"</td><td class='tbl_prod_id' hidden>"+ $("#prod_id").val() +
		"</td></tr>");

	compute_grandtotal();
	reset_input();
}

function select_row_table(row){
	var table = "#tbl-products tbody tr:eq("+row+")";

	$("#sel_price").val($(table).find(".tbl_sel_price").text());
	$("#qty").val($(table).find(".tbl_qty").text());
	$("#total_price").val($(table).find(".tbl_total_price").text());
	$("#volume_discount").val($(table).find(".tbl_volume_discount").text());
	$("#total_selling_price").val($(table).find(".tbl_total_selling_price").text());
	$("#share_amount").val($(table).find(".tbl_share_amount").text());
	$("#pay_total_amount").val($(table).find(".tbl_total_amount").text());
	$("#tbl_item_row").val(row);
}

function edit_item_table(){

	var row = $("#tbl_item_row").val();
	var table = "#tbl-products tbody tr:eq("+row+")";

	$(table).find(".tbl_prod_no").text($("#prod_no").val());
	$(table).find(".tbl_prod_name").text($("#prod_name").val());
	$(table).find(".tbl_qty").text($("#qty").val());
	$(table).find(".tbl_stock_uom").text($("#stock_uom").val());
	$(table).find(".tbl_reg_price").text($("#reg_price").val());
	$(table).find(".tbl_sel_price").text($("#sel_price").val());
	$(table).find(".tbl_total_price").text($("#total_price").val());
	$(table).find(".tbl_volume_discount").text($("#volume_discount").val());
	$(table).find(".tbl_total_selling_price").text($("#total_selling_price").val());
	$(table).find(".tbl_share_per").text($("#share_per").val());
	$(table).find(".tbl_share_amount").text($("#share_amount").val());
	$(table).find(".tbl_total_amount").text($("#pay_total_amount").val());
	$(table).find(".tbl_prod_id").text($("#prod_id").val());

	$("#tbl_item_row").val("");
	compute_grandtotal();
	reset_input();
}

function reset_input(){
	$("#prod_id").val("");
	$("#prod_no").val("");
	$("#prod_name").val("");
	$("#stock_qty").val("");
	$("#stock_uom").val("");
	$("#reg_price").val("");
	$("#sel_price").val("");
	$("#qty").val("");
	$("#total_price").val("");
	$("#volume_discount").val("");
	$("#total_selling_price").val("");
	$("#share_amount").val("");
	$("#pay_total_amount").val("");
	$("#image-box").css("background", "white");
}

function save_trans(){
      //var agent_id =  $('#pr_no_modal').val();
      var agent_id = '1'
      var cust_id =  $('#cust_code').data("id");
      var sales_discount =  $('#sales_discount').val();
      var grand_total =  $('#grand_total').val();
      var payment_date = $('#payment_date').val();
      var payment_type_id = $('#payment_type').val();
      var trans_no = $("#sales_trans_no").text();
      //var bank_id = $('#bank_id').val();
      var bank_id = "1";
      var check_card_no = $('#check_no').val();
      var check_date = $('#check_date').val();
      var curr_id = $('#currency').val();
      var amount = $('#payment_amount').val();

      var dtl_data = [];
      var sales_hdr = {
            customer_id : cust_id,
            agent_id : "01",
            trans_no : trans_no,
            sales_discount : sales_discount,
            total_amount : grand_total
      } 

      $('#tbl-products tr').each(function (row, tr){
                var sub = {
                    'product_id' : $(tr).find('td:eq(13)').text(),
                    'qty' : $(tr).find('td:eq(2) ').text(),
                    'selling_price' : $(tr).find('td:eq(5) ').text(),
                    'total_price' : $(tr).find('td:eq(6) ').text(),
                    'volume_discount' : $(tr).find('td:eq(7) ').text(),
                    'total_selling_price' :$(tr).find('td:eq(8) ').text(),
                    'share' :$(tr).find('td:eq(9) ').text(),
                    'share_amount' :$(tr).find('td:eq(10) ').text(),
                    'total_amount' :$(tr).find('td:eq(11) ').text(),
                } 
                dtl_data.push(sub);            
       });

      var payment_data = {
      		  payment_date : payment_date,
            payment_type_id : payment_type_id,
            bank_id : bank_id,
            check_card_no : check_card_no,
            check_date : check_date,
            curr_id : curr_id,
            amount : amount
      }
      
      dtl_data.shift();
      var data = {sales_hdr:sales_hdr, sales_dtl: dtl_data, payment_dtl:payment_data};
      $.ajax({
            data : data
            , type: "POST"
            , url: base_url + "Sales/save_transaction"
            , dataType: 'JSON'
            , crossOrigin: false     
            , success: function(result) {
            	modal_trans_data();
				// swal({
				// 	title: "Successfully Insert",
				// 	type: "success",
				// 	timer: 2000
				// }, function(){
				// 	location.reload();
				// });
            }, error: function(err) {
                console.log("ERROR : " + err.responseText);
            }
      });  
}

function modal_trans_data(){

	$("#mod_trans_no").text($("#sales_trans_no").text());
	$("#mod_payment_type").text($("#payment_type").val());
	$("#mod_total_sales").text((Number($("#sales_discount").val()) + Number($("#grand_total").val())));
	$("#mod_discount").text($("#sales_discount").val());
	$("#mod_grand_total").text($("#grand_total").val());
	$("#mod_amount_paid").text($("#payment_amount").val());
	$("#mod_change").text(($("#payment_amount").val() - $("#grand_total").val()));
	$("#mod_partner").text($("#partner").val());
	$("#mod_share").text($("#grand_total").val() * $("#share_per").val());

	$("#mod_share").number(true,2);
	$("#mod_total_sales").number(true,2);
	$("#mod_discount").number(true,2);
	$("#mod_grand_total").number(true,2);
	$("#mod_change").number(true,2);
	$("#mod_amount_paid").number(true,2);

}

function preview_data(){
	$("#mod_prev_trans_no").text($("#sales_trans_no").text());
	$("#mod_prev_cust_code").text($("#cust_code").val());
	$("#mod_prev_cust_name").text($("#cust_name").val());
	$("#mod_prev_discount").text($("#sales_discount").val());
	$("#mod_prev_grand_total").text($("#grand_total").val());
	$("#tbl-products").clone().appendTo("#div-tbl-prev-items");
	$("#div-tbl-prev-items").find(".remove_item").remove();
	$("#div-tbl-prev-items").find(".remove_hdr").remove();
	$("#tbl-products thead th:nth-child(9)").css("width", "22%");
	$("#tbl-products tbody td:nth-child(9)").css("width", "22%");

	$("#mod_prev_discount").number(true,2);
	$("#mod_prev_grand_total").number(true,2);
}