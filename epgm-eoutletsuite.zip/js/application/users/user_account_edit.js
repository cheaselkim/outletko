$(document).ready(function(){
	get_data();

	$("#save").click(function(){
		save();
	});


});

function get_data(){
	$.ajax({
		type : "GET",
		dataType : "JSON",
		url : base_url + "User/get_user_account",
		success : function(result){
			$("#last_name").val(result[0].last_name);
			$("#first_name").val(result[0].first_name);
			$("#middle_name").val(result[0].middle_name);
			$("#email").val(result[0].email);
			$("#status").val(result[0].status);
			$("#sales_force_type").val(result[0].sales_force_type);
			$("#nick_name").val(result[0].nickname);
			$("#account_id").val(result[0].account_id);
			$("#position").val(result[0].position);
			$("#date_start").val(result[0].date_start);
			$("#outlet").val(result[0].outlet_code);
			$("#share").val(result[0].share);
			$("#salary").val(result[0].salary_allowance);
			$("#monthly_quota").val(result[0].monthly_quota);
		}, error: function(err){
			console.log(err.responseText);
		}
	});
}

function save(){

	var last_name = $("#last_name").val();
	var first_name = $("#first_name").val();
	var middle_name = $("#middle_name").val();
	var email = $("#email").val();
	var nickname = $("#nick_name").val();

	if(jQuery.trim(last_name).length <= 0 || jQuery.trim(first_name).length <= 0 || jQuery.trim(email).length <= 0) {
		    swal("Please fill up required fields.", "", "error");
		    return false;      
	}

	var data_sales = {
		last_name : last_name,
		first_name : first_name,
		middle_name : middle_name,
		email : email,
		nickname : nickname,
	}

	var data_user = {
		last_name : last_name, 
		first_name : first_name,
		middle_name : middle_name,
		email : email
	}

	$.ajax({
		data : {data_sales : data_sales, data_user : data_user},
		type : "POST",
		dataType : "JSON",
		url : base_url + "User/update_user_account",
		success : function(result){
			if (result == "1"){
				swal({
					type : "success",
					title : "Successfully save.",
					timer : 2000
				}, function(){
					location.reload();
				});
			}
		}, error : function(err){
			console.log(err.responseText);
		}
	});

}