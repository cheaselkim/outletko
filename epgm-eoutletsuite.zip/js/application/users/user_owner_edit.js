$(document).ready(function(){

	get_data();

	$("#save").click(function(){
		save();
	});

})

function get_data(){
	$.ajax({
		type : "GET",
		dataType : "JSON",
		url : base_url + "User/get_user_owner",
		success: function(result){
			$("#last_name").val(result[0].last_name);
			$("#first_name").val(result[0].first_name);
			$("#middle_name").val(result[0].middle_name);
			$("#email").val(result[0].email);
			$("#mobile_no").val(result[0].mobile_no);
			$("#phone_no").val(result[0].telephone_no);
			$("#address_no").val(result[0].address);
			$("#account_name").val(result[0].account_name);
			$("#account_status").val(result[0].status);
			$("#currency").val(result[0].curr_code);
			$("#business_type").val(result[0].business_desc);
			$("#subscription_type").val(result[0].subscription_desc);
			$("#subscription_date").val(result[0].subscription_date);
			$("#renewal_date").val(result[0].renewal_date);
			$("#recruited_by").val(result[0].recruited_by);
			$("#no_outlet").val(result[0].outlet_no);
			$("#vat").val(result[0].vat);
		}, error : function(err){
			console.log(err.responseText);
		}
	});
}

function save(){

	var last_name = $("#last_name").val().toUpperCase();
	var first_name = $("#first_name").val().toUpperCase();
	var middle_name = $("#middle_name").val().toUpperCase();
	var email = $("#email").val();
	var mobile_no = $("#mobile_no").val();
	var phone_no = $("#phone_no").val();
	var address = $("#address_no").val();
	var account_name = $("#account_name").val().toUpperCase();

	if(jQuery.trim(last_name).length <= 0 || jQuery.trim(first_name).length <= 0 || jQuery.trim(middle_name).length <= 0  
		|| jQuery.trim(email).length <= 0 || jQuery.trim(mobile_no).length <= 0 || jQuery.trim(phone_no).length <= 0 
		|| jQuery.trim(address).length <= 0   || jQuery.trim(account_name).length <= 0) {
		    swal("Please fill up required fields.", "", "error");
		    return false;      
	}

	var data_owner = {
		last_name : last_name,
		first_name : first_name,
		middle_name : middle_name,
		email : email,
		mobile_no : mobile_no,
		telephone_no : phone_no,
		address : address,
		account_name : account_name
	}

	var data_user = {
		first_name : first_name,
		last_name : last_name,
		middle_name : middle_name,
		email : email
	}

	$.ajax({
		data : {data_owner : data_owner, data_user : data_user},
		type : "POST",
		url : base_url + "User/update_owner",
		dataType : "JSON",
		success : function(result){
			if (result == "1"){
				swal({
					type : "success",
					title : "Successfully save.",
					timer : 2000
				}, function(){
					location.reload();
				})
			}else{
				console.log(result);
			}
		}, error : function(err){
			console.log(err.responseText);
		}
	})

}