$(document).ready(function(){

  var id = $("#sales_force_id").val();
  $("#monthly_quota").number(true, 2);
  $("#share").number(true, 2);
  $("#salary").number(true, 2);
  get_outlet();
  sales_force_type();
  
  get_sales_force_dtl(id)

  $("#save").click(function(){
    save_data();
  });

});

function get_outlet(){
  $.ajax({
    url : base_url + "Sales_force/get_outlet",
    type : "GET",
    dataType : "JSON",
    success : function(data){
      for (var i = 0; i < data.length; i++) {
        $("#outlet").append("<option value='"+data[i].id+"'>"+data[i].outlet_name  +"</option>");
      }
    }, error: function(err){
      console.log(err.responseText);
    }
  });
}

function sales_force_type(){
  $.ajax({
    url : base_url + "Sales_force/sales_force_type",
    type : "GET",
    dataType : "JSON",
    success : function(data){
      for (var i = 0; i < data.length; i++) {
        $("#sales_force_type").append("<option value='"+data[i].id+"'>"+data[i].desc  +"</option>");
      }
    }, error: function(err){
      console.log(err.responseText);
    }
  });  
}

function get_sales_force_dtl(id){
  $.ajax({
    data : {"id" : id},
    url : base_url + "Sales_force/get_sales_force_dtl",
    type : "POST",
    dataType : "JSON",
    success : function(data){
      $('#last_name').val(data.sales_force_dtl[0]['last_name']);
      $('#status').val(data.sales_force_dtl[0]['active']);
      $('#first_name').val(data.sales_force_dtl[0]['first_name']);
      $('#nick_name').val(data.sales_force_dtl[0]['nickname']);
      $('#mid_name').val(data.sales_force_dtl[0]['middle_name']);
      $('#position').val(data.sales_force_dtl[0]['position']);
      $('#date_start').val(data.sales_force_dtl[0]['date_start']);
      $('#monthly_quota').val(data.sales_force_dtl[0]['monthly_quota']);
      $('#hierarchy').val(data.sales_force_dtl[0]['hierarchy']);
      $('#share_type').val(data.sales_force_dtl[0]['type_share']);
      $('#salary').val(data.sales_force_dtl[0]['salary_allowance']);
      $('#outlet').val(data.sales_force_dtl[0]['outlet']);
      $('#share').val(data.sales_force_dtl[0]['share']);
    }, error: function(err){
      console.log(err.responseText);
    }
  });
}

function save_data(){
      var supp_code = $('#supp_code').val();
      var supp_name = $('#supp_name').val();
      var supp_type = $('#supp_type').val();
      var supp_status = $('#supp_status').val();
      var supp_address = $('#supp_address').val();
      var supp_city_id = $('#supp_city_id').val();
      var supp_province_id = $('#supp_province_id').val();
      var supp_country = $('#supp_country').val();
      var supp_zip_code = $('#supp_zip_code').val();
      var factory_add = $('#factory_add').val();
      var supp_region = $('#supp_region').val();
      var business_nature = $('#nat_bus').val();
      var organization_form = $('#form_org').val();
      var classification = $('#classif').val();
      var contact_person = $('#contact_person').val();
      var contact_no = $('#contact_no').val();
      var email_add = $('#email_add').val();
      var website = $('#website').val();
      var facebook = $('#facebook').val();
      var fax = $('#fax').val();
      var date_org = $('#date_org').val();
      var id = $("#supplier_id").val();


      if(jQuery.trim(supp_code).length <= 0 || jQuery.trim(supp_name).length <= 0 || jQuery.trim(supp_address).length <= 0 
        || jQuery.trim(organization_form).length <= 0 || jQuery.trim(classification).length <= 0 
        || jQuery.trim(business_nature).length <= 0 || jQuery.trim(contact_person).length <= 0 
        || jQuery.trim(contact_no).length <= 0 || jQuery.trim(date_org).length <= 0) {
            swal("Please fill up required fields.", "", "error")
            return false            
      }
      var supplier_hdr = {
            supp_code : supp_code,
            supp_name : supp_name,
            supp_type : supp_type,
            supp_status : supp_status,
            supp_address : supp_address,
            supp_city_id : supp_city_id,
            supp_province_id : supp_province_id,
            supp_country : supp_country, 
            supp_zip_code : supp_zip_code, 
            factory_add : factory_add, 
            contact_person : contact_person, 
            contact_no : contact_no, 
            email_add : email_add, 
            website : website, 
            fax : fax, 
            facebook: facebook,
            classification:classification,
            business_nature : business_nature, 
            organization_form : organization_form,
            supp_region : supp_region, 
            date_organized : date_org, 
      }

      var data = {supplier_hdr:supplier_hdr,id:id};
      console.log(data);
      //return false;
      $.ajax({

            data : data
            , type: "POST"
            , url: base_url + "Sales_force/update"
            , dataType: 'json'
            , crossOrigin: false     
            , success: function(result) {
              swal({
                title : "Successfully Insert",
                type : "success",
                timer: 2000
              }, function(){
                location.reload();
              });
            }, error: function(err) {
                console.log(err.responseText);
            }
      });  
};

