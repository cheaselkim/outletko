$(document).ready(function(){

	$("#monthly_quota").number(true, 2);
  $("#share").number(true, 2);
  $("#salary").number(true, 2);
  get_outlet();
  sales_force_type();
  

  $("#outlet").change(function(){
    account_id();
  });

	$("#save").click(function(){
		save_data();
	});

});

function get_outlet(){
  $.ajax({
    url : base_url + "Sales_force/get_outlet",
    type : "GET",
    dataType : "JSON",
    success : function(data){
      for (var i = 0; i < data.length; i++) {
        $("#outlet").append("<option value='"+data[i].id+"'>"+data[i].outlet_name  +"</option>");
      }
      account_id();
    }, error: function(err){
      console.log(err.responseText);
    }
  });
}

function sales_force_type(){
  $.ajax({
    url : base_url + "Sales_force/sales_force_type",
    type : "GET",
    dataType : "JSON",
    success : function(data){
      for (var i = 0; i < data.length; i++) {
        $("#sales_force_type").append("<option value='"+data[i].id+"'>"+data[i].desc  +"</option>");
      }
    }, error: function(err){
      console.log(err.responseText);
    }
  });  
}

function account_id(){
  var outlet = $("#outlet").val();
  $.ajax({
    data : {outlet : outlet},
    type : "POST",
    dataType : "JSON",
    url : base_url + "Sales_force/account_id",
    success : function(result){
      $("#account_id").val(result.account_id);
    }, error : function(err){
      console.log(err.responseText);
    }
  });  
}

function save_data(){
      var last_name = $('#last_name').val();
      var status = $('#status').val();
      var first_name = $('#first_name').val();
      var nick_name = $('#nick_name').val();
      var mid_name = $('#mid_name').val();
      var position = $('#position').val();
      var date_start = $('#date_start').val();
      var monthly_quota = $('#monthly_quota').val();
      var hierarchy = $('#hierarchy').val();
      var share_type = $('#share_type').val();
      var salary = $('#salary').val();
      var outlet = $('#outlet').val();
      var share = $('#share').val();
      var email = $("#email").val();
      var username = $("#nickname").val();
      var type = $("#sales_force_type").val();
      var account_id = $("#account_id").val();

      if(jQuery.trim(last_name).length <= 0 || jQuery.trim(first_name).length <= 0 
        || jQuery.trim(email).length <= 0 || jQuery.trim(share).length <= 0 ) {
            swal("Please fill up required fields.", "", "error")
            return false            
      }
      var data_hdr = {
        last_name : last_name,
        active : status,
        first_name : first_name,
        nickname : nick_name,
        middle_name : mid_name,
        position : position,
        date_start : date_start,
        monthly_quota : monthly_quota,
        hierarchy : hierarchy,
        type_share : share_type,
        salary_allowance : salary,
        outlet : outlet,
        share : share, 
        type : type
      } 

      var data_users = {
        last_name : last_name,
        first_name : first_name,
        middle_name : mid_name,
        status : status,
        username : username,
        account_id : account_id,
        email : email,
        all_access : "0",
        otp : "1"
      }

      var data = {data_hdr:data_hdr, data_users : data_users};
      //return false;
      $.ajax({

            data : data
            , type: "POST"
            , url: base_url + "Sales_force/save_sales_force"
            , dataType: 'json'
            , crossOrigin: false     
            , success: function(result) {
              swal({
                title : "Successfully save",
                text : "Account ID : " + account_id + " Password : " + result.string,
                type : "success",
                timer: 5000
              }, function(){
                location.reload();
              });
            }, error: function(err) {
                console.log(err.responseText);
            }
      });  
};