$(document).ready(function(){

	company();
	outlet();

	$("#save").click(function(){
		save();
	});	

	$("#cancel").click(function(){
		window.open(base_url + "", "_self");
	});


});

function company(){
	$.ajax({
		type : "GET",
		dataType : "JSON",
		url : base_url + "Product_brand/company",
		success: function(data){
			$("#prod_brand_comp").val(data);
		}, error: function(err){
			console.log(err.responseText);
		}
	});
}

function outlet(){
	$.ajax({
		type : "GET",
		dataType : "JSON",
		url : base_url + "Product_brand/outlet",
		success: function(data){
			for (var i = 0; i < data.length; i++) {
				$("#prod_brand_outlet").append("<option value='"+data[i].id+"'>"+data[i].outlet_name+"</option>");
			}
		}, error: function(err){
			console.log(err.responseText);
		}
	});
}

function save(){

	var outlet = $("#prod_brand_outlet").val();
	var brand_desc = $("#prod_brand_desc").val();

	if (brand_desc == ""){
		swal({
			title : "Please input all required fields",
			type : "warning"
		})
	}else{
		$.ajax({
			data : {outlet : outlet, brand_desc : brand_desc},
			type : "POST",
			dataType : "JSON",
			url : base_url + "Product_brand/insert_product_brand",
			crossOrigin: false,
			success : function(result){
				if (result == true){
					swal({
						title : "Successfully Saved",
						type : "success",
						timer: 2000
					}, function(){
						location.reload();
					})
				}else{
					console.log(result);
				}
			}, error : function(err){
				console.log(err.responseText);
			}
		});
	}

}