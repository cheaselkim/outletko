$(document).ready(function(){

    
    var id = $("#product_no").data('id');
    get_product_dtl(id)
    var unserialized_files = "";

    $("#update_product").click(function(){
      save_product();
    });

    function get_product_dtl(id){
        $.ajax({
            data : {"id" : id},
            url : base_url + "Product/get_product_dtl",
            type : "POST",
            dataType : "JSON",
            success : function(data){
                $('#product_no').val(data.product_dtl[0]['product_no']);
                $('#product_type').val(data.product_dtl[0]['type_id']);
                $('#product_name').val(data.product_dtl[0]['product_name']);
                $('#product_name').attr('data-code', data.product_dtl[0]['product_code']);
                $('#product_specs').val(data.product_dtl[0]['product_specs']);
                $('#product_brand').val(data.product_dtl[0]['brand_id']);
                $('#product_model').val(data.product_dtl[0]['model_id']);
                $('#product_category').val(data.product_dtl[0]['category_id']);
                $('#product_color').val(data.product_dtl[0]['color_id']);
                $('#product_size').val(data.product_dtl[0]['size_id']);
                $('#product_class').val(data.product_dtl[0]['class_id']);
                $('#product_level').val(data.product_dtl[0]['reorder_level_id']);
                $('#product_stock_unit').val(data.product_dtl[0]['stock_unit_id']);
                //$('#product_issue_unit').val(data.product_dtl[0]['outlet_status']);
                $('#selling_price').val(data.product_dtl[0]['reg_selling_price']);
                //$('#imgInp').val(data.unserialized_files);
                unserialized_files = data.unserialized_files;
                var href_url = base_url +'images/products/'+unserialized_files[0];
                $("#img-upload").attr("src", href_url);

            }, error: function(err){
                console.log("error : " + err.responseText);
            }
        });
    }

    function save_product(){

          var product_no = $('#product_no').val();
          var product_type = $('#product_type').val();
          var product_name = $('#product_name').val();
          var product_specs = $('#product_specs').val();
          var imgInp = $('#imgInp').val();
          var product_code = $('#product_name').data('code')
          var product_brand = $('#product_brand').val();
          var product_model = $('#product_model').val();
          var product_category = $('#product_category').val();
          var product_color = $('#product_color').val();
          var product_size = $('#product_size').val();
          var product_class = $('#product_class').val();
          var product_level = $('#product_level').val();
          var reg_selling_price = $('#selling_price').val();
          var product_stock_unit = $('#product_stock_unit').val();
          //var product_issue_unit = $('#product_issue_unit').val();
           var check_img = $('#imgInp');

          if(jQuery.trim(product_no).length <= 0 || jQuery.trim(product_type).length <= 0 || jQuery.trim(product_name).length <= 0 
            || jQuery.trim(product_specs).length <= 0 || jQuery.trim(product_color).length <= 0 
            || jQuery.trim(product_size).length <= 0 || jQuery.trim(product_stock_unit).length <= 0 
            || jQuery.trim(reg_selling_price).length <= 0) {
              swal({
                  type : "error",
                  title : "Please fill up required fields."
              })
                return false 
          }

          if(check_img.get(0).files.length <= 0) {
          //alert("walang laman");
          }else {
            var file_size = $('#imgInp').prop('files')[0].size/1024/1024; // in MB
            if (file_size > 1) {
              swal({
                  type : "error",
                  title : "File size exceeds 1 MB"
              })
              //alert('This file size is: ' + $('#imgInp').prop('files')[0].size/1024/1024 + "MB");
              return false;
            } else {
            }
          }

          var product_hdr = {
                product_no : product_no,
                product_name : product_name,
                product_specs : product_specs,
                brand_id : product_brand,
                color_id : product_color,
                //outlet_id : outlet_type,
                model_id : product_model,
                size_id : product_size, 
                category_id : product_category, 
                reorder_level : product_level, 
                stock_unit_id : product_stock_unit, 
                type_id : product_type, 
                reg_selling_price : reg_selling_price, 
                product_code : product_code, 
                class_id : product_class, 
          } 

          var data = {product_hdr:product_hdr, product_no :product_no};
          console.log(unserialized_files);
          if(check_img.get(0).files.length <= 0) {
          }else {
             image_update($('#imgInp').prop('files')[0],product_no,unserialized_files);
          }


          //return false;
          $.ajax({

                data : data
                , type: "POST"
                , url: base_url +"Product/update_product"
                , dataType: 'json'
                , crossOrigin: false     
                , success: function(result) {
                  swal({
                    type : "success",
                    title : "Successfully save."
                  })                   
                }, error: function(err) {
                    console.log(err.responseText);
                }
          });  
    };


    function image_update(img,product_no,unserialized_files){
      var form_data = new FormData(); 
          var files = $('#imgInp')[0].files;
          for(var count = 0; count<files.length; count++) {
          var name = files[count].name;
          form_data.append("files[]", files[count]);
          }        
          form_data.append('product_no', product_no); 
          for(var x = 0; x<unserialized_files.length; x++) {
            form_data.append('curr_img[]', unserialized_files[x]);
          } 

            console.log(form_data);
           //return false   
          $.ajax({
              data : form_data 
              ,type : "POST"
              , url: base_url + "Product/update_img_file"
              , dataType : "json" 
              , crossOrigin : false
              , contentType: false
              , processData: false
              , beforeSend : function() {
                  $("#save").prop("disabled", true);
                  $("#submit").prop("disabled", true);
                     
              }
              , success : function(result) {
                console.log("result " + result.status );
                  if(result.status == "success") {

                      $("#save").removeAttr('disabled');
                      $("#submit").removeAttr('disabled');

                  }else {
                      console.log(result.status);
                  }

              }, failure : function(msg) {
                  console.log("Error connecting to server...");
              }, error: function(status) {
                        
              }, xhr: function(){
                  var xhr = $.ajaxSettings.xhr() ;
                  xhr.onprogress = function(evt){ 
                      $("body").css("cursor", "wait"); 
                  };  
                  xhr.onloadend = function(evt){ 
                      $("body").css("cursor", "default"); 
                  };      
                  return xhr ;
              }

          }); 
    }

    
})





