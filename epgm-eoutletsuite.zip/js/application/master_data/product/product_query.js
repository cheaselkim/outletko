$(document).ready(function(){
    
  index();
  product_type();

  $('#product_type').change(function() {
        var type = $(this).val();
        var status = $('#outlet_status').val();
        index(type);
    });

    $('#search').click(function() {
      var type = "";
      var status = "";
      var term = $('#search_box').val();
      index(type,term);
    });

  $("#search_box").autocomplete({
      minLength: 0,
      source: base_url + "Product/search_field/",
      focus: function( event, ui ) {
        return false;
      },
      select: function( event, ui ) {
        $(this).val(ui.item.term);
        return false; 
      }
    })
    .autocomplete( "instance" )._renderItem = function( ul, item ) {
        return $( "<li>" )
        .append( "<div>" + item.term + "</div>" )
        .appendTo( ul );
    };   



});

function product_type(){
    $.ajax({
        url : base_url + "Product/product_type",
        type : "GET",
        dataType : "JSON",
        success : function(data){
            for (var i = 0; i < data.length; i++) {
                $("#product_type").append("<option value='"+data[i].id+"'>"+data[i].prod_type_desc   +"</option>");
            }
        }, error: function(err){
            console.log(err.responseText);
        }
    });   
}

function index(type="",term=""){
  var app_func = $("#product_func").val();
  $.ajax({
    data: {type : type,term:term, app_func : app_func}, 
        type: "POST", 
    url : base_url + "Product/product_list",
    dataType : "JSON",
    success : function(result){
      $("#query-table").html(result);
    }, error: function(err){
      console.log(err.responseText);
    }
  });
}

function view_product(id){

  $("#modal_query").modal("show");

  $.ajax({
    data : {"id" : id},
    url : base_url + "Product/select_id",
    type : "POST",
    dataType : "JSON",
    success : function (result){
      $("#modal_query").modal("show");
    }, error : function(err){
      console.log(err.responseText);
    }
  });
}

function delete_product(id,key){
  console.log(key);
  var trans_no = $("#tbl-product tbody tr:eq("+(key)+")").find("td:eq(1)").text();
  swal({
    title: "Are you sure do you want to Delete "+trans_no+" ?",
    type: "warning",
    showCancelButton: true,
    confirmButtonColor: '#DD6B55',
    confirmButtonText: 'Confirm',
    closeOnConfirm: false,
    closeOnCancel: false,
    timer: 3000
  },function(isConfirm){
    if (isConfirm){
      $.ajax({
        data : {"id" : id},
        url : base_url + "Product/delete_product",
        type : "POST",
        dataType : "JSON",
        success : function (result){
          index();
          swal("Successfully Delete", "", "success");
        }, error : function(err){
          console.log(err.responseText);
        }       
      });
    }else{
        swal("Cancelled", "", "error");
    }
  });


}

function edit_product(id){
  $("body").empty();
  $("body").load(base_url + "menu/edit_menu/4/5/2/"+id);
}