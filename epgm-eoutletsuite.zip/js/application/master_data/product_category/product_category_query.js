$(document).ready(function(){

	outlet();
	query_data();

	$("#search").click(function(){
		query_data();
	});

});

function outlet(){
	$.ajax({
		type : "GET",
		dataType : "JSON",
		url : base_url + "Product_category/outlet",
		success: function(data){
			for (var i = 0; i < data.length; i++) {
				$("#prod_cat_outlet").append("<option value='"+data[i].id+"'>"+data[i].outlet_name+"</option>");
			}
		}, error: function(err){
			console.log(err.responseText);
		}
	});
}

function query_data(){
	var app_func = $("#app_func").val();
	var prod_cat_outlet = $("#prod_cat_outlet").val();
	var prod_cat_desc = $("#prod_cat_desc").val();

	$.ajax({
		data : {app_func : app_func, outlet : prod_cat_outlet, category_desc : prod_cat_desc},
		type : "POST",
		dataType : "JSON",
		url : base_url + "Product_category/query_product_category",
		success: function(result){
			$("#div-query").html(result);
		}, error: function(err){
			console.log(err.responseText);
		}
	});

}

function delete_prod_cat(id,key){
	var value = $("#tbl-data tbody tr:eq("+(key)+")").find("td:eq(2)").text();
	swal({
		title: "Are you sure do you want to Delete Product Category : "+ value +" ?",
		type: "warning",
		showCancelButton: true,
		confirmButtonColor: '#DD6B55',
		confirmButtonText: 'Confirm',
		closeOnConfirm: false,
		closeOnCancel: false,
		timer: 3000
		},function(isConfirm){
			if (isConfirm){
			  	$.ajax({
			    	data : {"id" : id},
			    	url : base_url + "Product_category/delete_prod_category",
			    	type : "POST",
			    	dataType : "JSON",
			    	success : function (result){
			      		query_data();
				      swal("Successfully Delete", "", "success");
				    }, error : function(err){
				    	console.log(err.responseText);
			    	}       
				});
			}else{
			    swal("Cancelled", "", "error");
			}
	});
}

function edit_prod_cat(id){
	$("body").empty();
	$("body").load(base_url + "menu/edit_menu/4/10/2/"+id);
}