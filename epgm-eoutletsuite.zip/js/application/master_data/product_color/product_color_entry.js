$(document).ready(function(){

	company();
	outlet();

	$("#save").click(function(){
		save();
	});	

	$("#cancel").click(function(){
		window.open(base_url + "", "_self");
	});

});

function company(){
	$.ajax({
		type : "GET",
		dataType : "JSON",
		url : base_url + "Product_color/company",
		success: function(data){
			$("#prod_color_comp").val(data);
		}, error: function(err){
			console.log(err.responseText);
		}
	});
}

function outlet(){
	$.ajax({
		type : "GET",
		dataType : "JSON",
		url : base_url + "Product_color/outlet",
		success: function(data){
			for (var i = 0; i < data.length; i++) {
				$("#prod_color_outlet").append("<option value='"+data[i].id+"'>"+data[i].outlet_name+"</option>");
			}
		}, error: function(err){
			console.log(err.responseText);
		}
	});
}

function save(){

	var outlet = $("#prod_color_outlet").val();
	var color_desc = $("#prod_color_desc").val();

	if (color_desc == ""){
		swal({
			title : "Please input all required fields",
			type : "warning"
		})
	}else{
		$.ajax({
			data : {outlet : outlet, color_desc : color_desc},
			type : "POST",
			dataType : "JSON",
			url : base_url + "Product_color/insert_product_color",
			crossOrigin: false,
			success : function(result){
				if (result == true){
					swal({
						title : "Successfully Saved",
						type : "success",
						timer: 2000
					}, function(){
						location.reload();
					})
				}else{
					console.log(result);
				}
			}, error : function(err){
				console.log(err.responseText);
			}
		});
	}

}