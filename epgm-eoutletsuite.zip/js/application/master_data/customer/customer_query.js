$(document).ready(function(){
    
  index();
  //outlet_type();

  var app_func = $("#outlet_func").val();
 $('#search').click(function() {
    var term = $('#search_box').val();
    index(term);
  });

  $("#search_box").autocomplete({
    minLength: 0,
    source: base_url + "Customer/search_field/",
    focus: function( event, ui ) {
      return false;
    },
    select: function( event, ui ) {
      $(this).val(ui.item.term);
      return false; 
    }
  })
  .autocomplete( "instance" )._renderItem = function( ul, item ) {
    return $( "<li>" )
    .append( "<div>" + item.term + "</div>" )
    .appendTo( ul );
  };     


});

function index(term=""){
  var app_func = $("#customer_func").val();
  $.ajax({
    data: {term:term, app_func : app_func}, 
    type: "POST", 
    url : base_url +  "Customer/customer_list",
    dataType : "JSON",
    success : function(result){
      $("#query-table").html(result);
    }, error: function(err){
      console.log(err.responseText);
    }
  });
}

function view_customer(id){

  $("#modal_query").modal("show");

  $.ajax({
    data : {"id" : id},
    url : base_url + "Customer/select_id",
    type : "POST",
    dataType : "JSON",
    success : function (result){
      $("#modal_query").modal("show");
    }, error : function(err){
      console.log(err.responseText);
    }
  });
}

function delete_customer(id,key){
  console.log(key);
  var trans_no = $("#tbl-customer tbody tr:eq("+(key)+")").find("td:eq(0)").text();
  swal({
    title: "Are you sure do you want to Delete "+trans_no+" ?",
    type: "warning",
    showCancelButton: true,
    confirmButtonColor: '#DD6B55',
    confirmButtonText: 'Confirm',
    closeOnConfirm: false,
    closeOnCancel: false,
    timer: 3000
  },function(isConfirm){
    if (isConfirm){
      $.ajax({
        data : {"id" : id},
        url : base_url + "Customer/delete_customer",
        type : "POST",
        dataType : "JSON",
        success : function (result){
          index();
          swal("Successfully Delete", "", "success");
        }, error : function(err){
          console.log(err.responseText);
        }       
      });
    }else{
        swal("Cancelled", "", "error");
    }
  });


}

function edit_customer(id){
  $("body").empty();
  $("body").load(base_url + "menu/edit_menu/4/6/2/"+id);
}