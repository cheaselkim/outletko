$(document).ready(function(){

	get_issue($("#issue_no").data('id'));

	$("#save").click(function(){
    data_saving($("#issue_no").data('id'));
  });

  $("#enter_item").click(function(){
        if ($("#qty").val() != 0 && $("#cost").val() != 0){
                add_item_table();
        }else{
            alert("Fill up required fields!")
        }
  }); 

  jQuery(document).on("click", ".remove_item_table", function(){
      $(this).closest("tr").remove(); 
  }); 

  $("#recipient_code").keyup(function(){
        if ($(this).val() == ""){
            $("#recipient_name").val("");
        }
    });

    $("#recipient_name").keyup(function(){
        if ($(this).val() == ""){
            $("#recipient_code").val("");
        }
    });

    $("#recipient_code").autocomplete({
        focus: function(event, ui){
            $("#recipient_name").val(ui.item.recipient_name);
        },
        select: function(event, ui){
            $("#recipient_name").val(ui.item.recipient_name);
            $("#recipient_code").attr('data-id',ui.item.id);
        },
        source: function(req, add){
            var recipient_code = $("#recipient_code").val();
            $.ajax({
                url: base_url + "Inventory_issue/search_recipient/"+1, 
                dataType: "json",
                type: "POST",
                data: {'recipient' : recipient_code},
                success: function(data){
                    console.log(data.response);
                    if(data.response =="true"){
                        add(data.result);
                    }else{
                        add('');
                    }
                }, error: function(err){
                    console.log("Error: " + err.responseText);
                }
            });
        }
    });  

    $("#recipient_name").autocomplete({
        focus: function(event, ui){
            $("#recipient_code").val(ui.item.recipient_code);
        },
        select: function(event, ui){
            $("#recipient_code").val(ui.item.recipient_code);
            $("#recipient_code").attr('data-id',ui.item.id);
        },
        source: function(req, add){
            var recipient = $("#recipient_name").val();
            $.ajax({
                url: base_url + "Inventory_issue/search_recipient/"+2, 
                dataType: "json",
                type: "POST",
                data: {'recipient' : recipient},
                success: function(data){
                    console.log(data.response);
                    if(data.response =="true"){
                        add(data.result);
                    }else{
                        add('');
                    }
                }, error: function(err){
                    console.log("Error: " + err.responseText);
                }
            });
        }
    }); 


    //AUTOCOMPLETE FOR PRODUCT
    $("#prod_no").keyup(function(){
        if ($(this).val() == ""){
            $("#prod_name").val("");
        }
    });

    $("#prod_name").keyup(function(){
        if ($(this).val() == ""){
            $("#prod_no").val("");
        }
    });

    $("#prod_no").autocomplete({
        focus: function(event, ui){
            $("#prod_name").val(ui.item.prod_name);
            $("#product_specs").val(ui.item.prod_specs);
            $("#product_type").val(ui.item.prod_type);
            $("#product_brand").val(ui.item.brand);
            $("#product_model").val(ui.item.model);
            $("#product_category").val(ui.item.category);
            $("#product_color").val(ui.item.color);
            $("#product_class").val(ui.item.class);
            $("#product_size").val(ui.item.size);
            $("#prod_no").attr('data-unit',ui.item.unit);
        },
        select: function(event, ui){
            $("#prod_name").val(ui.item.prod_name);
            $("#product_type").val(ui.item.prod_type);
            $("#product_specs").val(ui.item.prod_specs);
            $("#product_brand").val(ui.item.brand);
            $("#product_model").val(ui.item.model);
            $("#product_category").val(ui.item.category);
            $("#product_color").val(ui.item.color);
            $("#product_class").val(ui.item.class);
            $("#product_size").val(ui.item.size);
            $("#prod_no").attr('data-unit',ui.item.unit);
            var unserialized_files = ui.item.image
            var href_url ='http://192.168.97.172:8015/eoutletsuitev2/images/products/'+unserialized_files[0];
            $("#img-upload").attr("src", href_url);

        },
        source: function(req, add){
            var prod_no = $("#prod_no").val();
            $.ajax({
                url: base_url + "Inventory_issue/search_item/"+1, 
                dataType: "json",
                type: "POST",
                data: {'prod' : prod_no},
                success: function(data){
                    console.log(data.response);
                    if(data.response =="true"){
                        add(data.result);
                    }else{
                        add('');
                    }
                }, error: function(err){
                    console.log("Error: " + err.responseText);
                }
            });
        }
    });

    $("#prod_name").autocomplete({
        focus: function(event, ui){
            $("#prod_no").val(ui.item.prod_no);
            $("#product_type").val(ui.item.prod_type);
            $("#product_specs").val(ui.item.prod_specs);
            $("#product_brand").val(ui.item.brand);
            $("#product_model").val(ui.item.model);
            $("#product_category").val(ui.item.category);
            $("#product_color").val(ui.item.color);
            $("#product_class").val(ui.item.class);
            $("#product_size").val(ui.item.size);
            $("#prod_no").attr('data-unit',ui.item.unit);
        },
        select: function(event, ui){
            $("#prod_no").val(ui.item.prod_no);
            $("#product_type").val(ui.item.prod_type);
            $("#product_specs").val(ui.item.prod_specs);
            $("#product_brand").val(ui.item.brand);
            $("#product_model").val(ui.item.model);
            $("#product_category").val(ui.item.category);
            $("#product_color").val(ui.item.color);
            $("#product_class").val(ui.item.class);
            $("#product_size").val(ui.item.size);
            $("#prod_no").attr('data-unit',ui.item.unit);
            var unserialized_files = ui.item.image
            var href_url ='http://192.168.97.172:8015/eoutletsuitev2/images/products/'+unserialized_files[0];
            $("#img-upload").attr("src", href_url);

        },
        source: function(req, add){
            var prod_name = $("#prod_name").val();
            $.ajax({
                url: base_url + "Inventory_issue/search_item/"+2, 
                dataType: "json",
                type: "POST",
                data: {'prod' : prod_name},
                success: function(data){
                    console.log(data.response);
                    if(data.response =="true"){
                        add(data.result);
                    }else{
                        add('');
                    }
                }, error: function(err){
                    console.log("Error: " + err.responseText);
                }
            });
        }
    });


})

function get_issue(id){
	$.ajax({
		data : {"id" : id},
		url : base_url + "Inventory_issue/get_issue",
		type : "POST",
		dataType : "JSON",
		success : function(data){
          console.log(data.trans_hdr[0]['tran_type']);
			//For Header
			$("#trans_id").val(id);
			$("#issue_no").val(data.trans_hdr[0]['inv_no']);
			$("#issue_date").val(data.trans_hdr[0]['inv_date']);
			$("#trans_type").val(data.trans_hdr[0]['tran_type']);
			$("#recipient_code").val(data.trans_hdr[0]['recipient_code']);
			$("#recipient_name").val(data.trans_hdr[0]['recipient_name']);  
            $("#recipient_code").attr('data-id',data.trans_hdr[0]['recipient_id']);
            $("#trans_no").val(data.trans_hdr[0]['ref_trans_no']);
            $("#trans_date").val(data.trans_hdr[0]['ref_trans_date']);
            $("#purpose").val(data.trans_hdr[0]['remarks']);
            get_outlet_name($('#issue_outlet').data('id'));
			
			//For Details
			var i = 0;
			for(var x=0; x<data.trans_dtl.length; x++) {	
				i++;
				$("#tbl-products tbody").append("<tr class='item_row_table'><td class='tbl_prod_no'>"+ data.trans_dtl[x]['product_id'] +
                "</td><td class='tbl_prod_name'>"+ data.trans_dtl[x]['product_name'] +
                "</td><td class='tbl_unit'>"+ data.trans_dtl[x]['unit'] +
                "</td><td class='tbl_onhand'>"+ 
                "</td><td class='tbl_qty'>"+ $.number(data.trans_dtl[x]['qty'], 2) +
                "</td><td class='tbl_currency'>PHP"+
				"</td><td class='text-center text-red'>"+ 
                "<i class='fa fa-minus-circle remove_item_table' style='color:red' id='remove_item_table'></i>" +
				"</td></tr>");
			}

			
			
		}, error: function(err){
			console.log(err.responseText);
		}
	});
}

function data_saving(id){
      var issue_no =  $('#issue_no').val();
      var issue_date =  $('#issue_date').val();
      var trans_type =  $('#trans_type').val();
      var recipient_code = $('#recipient_code').data('id');
      var recipient_name = $('#recipient_name').val();
      var trans_no = $('#trans_no').val();
      var purpose = $('#purpose').val();
      var issue_outlet = $('#issue_outlet').data('id');
      var trans_date = $('#trans_date').val();
      var sum = 0;
        $(".tbl_qty").each(function () {
            var num = $(this).text().replace(/,/g, "");
            if ($(this).text().length != 0) {
                sum += parseFloat(num);
            }
        });
      

      var dtl_data = [];
      var issue_hdr = {
            issue_no : issue_no,
            issue_date : issue_date,
            trans_type : trans_type,
            recipient_id : recipient_code,
            total_qty : $.number(sum.toFixed(2),2),
            ref_trans_no : trans_no,
            ref_trans_date : trans_date,
            purpose : purpose,
            issue_outlet : issue_outlet,
            status : "3"
      }  

      if(jQuery.trim(issue_no).length <= 0 || jQuery.trim(issue_date).length <= 0 || 
        jQuery.trim(trans_type).length <= 0 || jQuery.trim(recipient_code).length <= 0
        || jQuery.trim(recipient_name).length <= 0 || jQuery.trim(trans_no).length <= 0
        || jQuery.trim(trans_date).length <= 0) {
            alert('Please fill up required fields.');
            return false            
      }
      var total_tr = $('#tbl-products > tbody > tr').length;
      if (total_tr<=0) {
            alert('Add items');
            return false ;  
      }
      $('#tbl-products tr').each(function (row, tr){
                var sub = {
                    'product_id' : $(tr).find('td:eq(0)').text(),
                    'qty' : $(tr).find('td:eq(4) ').text()
                } 
                dtl_data.push(sub);            
       });

      
      dtl_data.shift();
      var data = {issue_hdr:issue_hdr, issue_dtl: dtl_data,hdr_id:id};
      console.log(data);
      //return false;
      $.ajax({

            data : data
            , type: "POST"
            , url: base_url + "Inventory_issue/update_data"
            , dataType: 'json'
            , crossOrigin: false     
            , success: function(result) {
                alert('Successfuly Save.');
                location.reload();
            }, error: function(err) {
                console.log(err.responseText);
            }
      });  
};

function add_item_table(){
    var qty = $("#qty").val();
    $("#tbl-products tbody").append("<tr class='item_row_table'><td class='tbl_prod_no'>"+ $("#prod_no").val() +
        "</td><td class='tbl_prod_name'>"+ $("#prod_name").val() +
        "</td><td class='tbl_unit'>PCS"+ 
        "</td><td class='tbl_onhand'>"+ 
        "</td><td class='tbl_qty'>"+ $.number($("#qty").val(), 2) +
        "</td><td class='tbl_currency'>Php"+
        "</td><td class='text-center text-red remove_item'>"+ "<i class='fa fa-minus-circle remove_item_table' style='color:red;cursor:pointer;' id='remove_item_table'></i>" +
        "</td></tr>");
    reset_input();
}


function reset_input(){
    $("#prod_no").val("");
    $("#prod_name").val("");
    $("#product_specs").val("");
    $("#product_type").val("");
    $("#product_brand").val("");
    $("#product_model").val("");
    $("#product_category").val("");
    $("#product_color").val("");
    $("#product_class").val("");
    $("#product_size").val("");
    $("#qty").val("00");
    $("#cost").val("00");
    $("#img-upload").attr("src", "");

    $(".prod_entry").collapse('hide');
}

function get_outlet_name(id){
    $.ajax({
        url: base_url + "Inventory_issue/get_outlet_name/", 
        dataType: "json",
        type: "GET",
        success: function(data){
            $("#issue_outlet").val(data[0].outlet_name);
        }, error: function(err){
            console.log("Error: " + err.responseText);
        }
    });
}