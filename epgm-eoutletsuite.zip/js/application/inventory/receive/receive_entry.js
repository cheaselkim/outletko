$(document).ready( function() {

    $(".btn-enter").hide();
    $(".btn-exit").hide();
    $("#qty").number(true, 0);
    $("#cost").number(true, 2);
    $("#net_vat").number(true, 2);
    $("#tot_w_vat").number(true, 2);
    $("#tot_w_o_vat").number(true, 2);

    currency();

    $(document).on('change', '.btn-file :file', function() {
    var input = $(this),
        label = input.val().replace(/\\/g, '/').replace(/.*\//, '');
    input.trigger('fileselect', [label]);
    });

    $('.btn-file :file').on('fileselect', function(event, label) {
        
        var input = $(this).parents('.input-group').find('.text-img'),
            log = label;
        
        if( input.length ) {
            input.text(log);
        } else {
            if( log ) alert(log);
        }
    
    });
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            
            reader.onload = function (e) {
                $('#img-upload').attr('src', e.target.result);
            }
            
            reader.readAsDataURL(input.files[0]);
        }
    }

    $("#imgInp").change(function(){
        readURL(this);
    });

    $(".btn-add").click(function(){
        if ($(".prod_entry").is(":visible") == true){
            $(".btn-enter").hide();
            $(".btn-exit").hide();
            $(".prod_entry").collapse('hide');
        }else{
            $(".btn-enter").show();
            $(".btn-exit").show();
            $(".prod_entry").collapse('show');            
        }

    });

    $(".btn-exit").click(function(){
        reset_input()
        $(".btn-enter").hide();
        $(".btn-exit").hide();
        $(".prod_entry").collapse('hide');
    }); 

    $("#enter_item").click(function(){
        if ($("#qty").val() != 0 && $("#cost").val() != 0){
            if ($("#tbl_item_row").val() != ""){
                edit_item_table();
            }else{
                add_item_table();
            }
        }else{
            swal({
                type : "error",
                title : "Fill up required fields!"
            });
        }
    }); 

    jQuery(document).on("click", ".remove_item_table", function(){
        $(this).closest("tr").remove(); 
        setTimeout(
          function() 
          {
            console.log("reset");
            reset_input();
          }, 400);
    }); 

    //AUTOCOMPLETE FOR RECIPIENT
    $("#outlet_code").keyup(function(){
        if ($(this).val() == ""){
            $("#outlet_name").val("");
        }
    });

    $("#outlet_name").keyup(function(){
        if ($(this).val() == ""){
            $("#outlet_name").val("");
        }
    });

    $("#outlet_code").autocomplete({
        focus: function(event, ui){
            $("#outlet_name").val(ui.item.outlet_name);
        },
        select: function(event, ui){
            $("#outlet_name").val(ui.item.outlet_name);
            $("#outlet_code").attr('data-type_1',ui.item.type1);
            $("#outlet_code").attr('data-id',ui.item.id);
        },
        source: function(req, add){
            var outlet_code = $("#outlet_code").val();
            console.log(outlet_code);
            $.ajax({
                url: base_url + "/inventory_receive/search_outlet/"+ 1 , 
                dataType: "json",
                type: "POST",
                data: {'outlet' : outlet_code},
                success: function(data){
                    if(data.response =="true"){
                        add(data.result);
                    }else{
                        add('');
                    }
                }, error: function(request, status, error){
                    console.log(error);
                    console.log("Error: " + request.responseText);
                }
            });
        }
    });  

    $("#outlet_name").autocomplete({
        focus: function(event, ui){
            $("#outlet_code").val(ui.item.outlet_code);
        },
        select: function(event, ui){
            $("#outlet_code").val(ui.item.outlet_code);
            $("#outlet_code").attr('data-type_1',ui.item.type1);
            $("#outlet_code").attr('data-id',ui.item.id);
        },
        source: function(req, add){
            var outlet_name = $("#outlet_name").val();
            $.ajax({
                url: base_url + "inventory_receive/search_outlet/"+2, 
                dataType: "json",
                type: "POST",
                data: {'outlet' : outlet_name},
                success: function(data){
                    console.log(data.response);
                    if(data.response =="true"){
                        add(data.result);
                    }else{
                        add('');
                    }
                }, error: function(err){
                    console.log("Error: " + err.responseText);
                }
            });
        }
    });   


    //AUTOCOMPLETE FOR PRODUCT
    $("#prod_no").keyup(function(){
        if ($(this).val() == ""){
            $("#prod_name").val("");
        }
    });

    $("#prod_name").keyup(function(){
        if ($(this).val() == ""){
            $("#prod_no").val("");
        }
    });

    $("#prod_no").autocomplete({
        focus: function(event, ui){
            $("#prod_name").val(ui.item.prod_name);
            $("#prod_unit").val(ui.item.prod_unit);
            $("#prod_no").data("id", ui.item.prod_id);
        },
        select: function(event, ui){
            $("#prod_name").val(ui.item.prod_name);
            $("#prod_no").data("id", ui.item.prod_id);
            $("#prod_unit").val(ui.item.prod_unit);
        },
        source: function(req, add){
            var prod_no = $("#prod_no").val();
            $.ajax({
                url: base_url + "inventory_receive/search_item/"+1, 
                dataType: "json",
                type: "POST",
                data: {'prod' : prod_no},
                success: function(data){
                    console.log(data.response);
                    if(data.response =="true"){
                        add(data.result);
                    }else{
                        add('');
                    }
                }, error: function(err){
                    console.log("Error: " + err.responseText);
                }
            });
        }
    });

    $("#prod_name").autocomplete({
        focus: function(event, ui){
            $("#prod_no").val(ui.item.prod_no);
            $("#prod_no").data("id", ui.item.prod_id);
            $("#prod_unit").val(ui.item.prod_unit);
        },
        select: function(event, ui){
            $("#prod_no").val(ui.item.prod_no);
            $("#prod_unit").val(ui.item.prod_unit);
            $("#prod_no").data("id", ui.item.prod_id);
        },
        source: function(req, add){
            var prod_name = $("#prod_name").val();
            $.ajax({
                url: base_url + "inventory_receive/search_item/"+2, 
                dataType: "json",
                type: "POST",
                data: {'prod' : prod_name},
                success: function(data){
                    console.log(data.response);
                    if(data.response =="true"){
                        add(data.result);
                    }else{
                        add('');
                    }
                }, error: function(err){
                    console.log("Error: " + err.responseText);
                }
            });
        }
    });

    jQuery(document).on("click", ".item_row_table", function(){
        var row = $(this).closest("tr").index();
        var id = $(this).closest("tr").find(".tbl_prod_id").text();
        select_row_table(row);
    }); 

    $("#trans_type").change(function(){
        get_product_transfer();
    });

    $("#cost").keyup(function(){
        compute_vat();
    });

    $("#save").click(function(){
        check_required_fields();
    });

});

function currency(){
    $.ajax({
        type : "GET",
        dataType : "JSON",
        url : base_url + "inventory_receive/currency",
        success : function(data){
            for (var i = 0; i < data.length; i++) {
                $("#currency").append("<option value='"+data[i].id+"'>"+data[i].curr_code   +"</option>");
            }
        }, error : function(err){
            console.log(err.responseText);
        }
    });
}

function add_item_table(){
    var qty = $("#qty").val();
    var cost = $("#cost").val();
    var prod = qty * cost;
    $("#tbl-products tbody").append("<tr class='item_row_table'>" + 
        "<td style='width: 2.5%;' class='tbl_prod_no text-left'>"+ $("#prod_no").val() +
        "</td><td style='width: 7%;' class='tbl_prod_name text-left'>"+ $("#prod_name").val() +
        "</td><td style='width: 1%;' class='tbl_qty text-left'>"+ $.number($("#qty").val(), 2) +
        "</td><td style='width: 1%;' class='tbl_unit text-left'>"+ $("#prod_unit").val() +
        "</td><td style='width: 1%;' class='tbl_curr text-left' data-id = '"+ $("#currency :selected").val() +"'>"+ $("#currency :selected").text() +
        "</td><td style='width: 1%;' class='tbl_purchase text-left'>"+ $.number($("#cost").val(), 2) +
        "</td><td style='width: 1%;' class='tbl_vat text-center' data-id = '"+ $("#vat :selected").val() +"'>"+ $("#vat :selected").text() +
        "</td><td style='width: 2%;' class='tbl_total_price text-left'>"+ $.number(prod, 2) +
        "</td><td style='width: 1%;' class='tbl_net_vat text-left' hidden>"+ $.number($("#net_vat").val(), 2) +
        "</td><td style='width: 1%;' class='tbl_w_vat text-center' hidden>"+ $.number($("#tot_w_vat").val(), 2) +
        "</td><td style='width: 2%;' class='tbl_w_o_vat text-left' hidden>"+ $.number($("#tot_w_o_vat").val(), 2) +
        "</td><td style='width: 1%;' class='text-center text-red remove_item'>"+ "<i class='fa fa-minus-circle remove_item_table' style='color:red;cursor:pointer;' id='remove_item_table'></i>" +
        "</td><td style='width: 2%;' class='tbl_prod_id text-left' hidden>"+ $("#prod_no").data("id") +
        "</td></tr>");
    reset_input();
}

function select_row_table(row){
    var table = "#tbl-products tbody tr:eq("+row+")";
    $("#tbl_item_row").val(row);
    $("#prod_no").val($(table).find(".tbl_prod_no").text());
    $("#prod_name").val($(table).find(".tbl_prod_name").text());
    $("#qty").val($(table).find(".tbl_qty").text());
    $("#prod_unit").val($(table).find(".tbl_unit").text());
    $("#currency").val($(table).find(".tbl_curr").data("id"));
    $("#cost").val($(table).find(".tbl_purchase").text());
    $("#vat").val($(table).find(".tbl_vat").data("id"));
    $("#total_price").val($(table).find(".tbl_total_price").text());
    $("#net_vat").val($(table).find(".tbl_net_vat").text());
    $("#tot_w_vat").val($(table).find(".tbl_total_price").text());
    $("#tot_w_o_vat").val($(table).find(".tbl_w_o_vat").text());
    
    $(".prod_entry").collapse('show');
    $(".btn-exit").show();
    $(".btn-enter").show();
}

function edit_item_table(){
    var row = $("#tbl_item_row").val();
    var table = "#tbl-products tbody tr:eq("+row+")";
    $(table).find(".tbl_prod_no").text($("#prod_no").val());
    $(table).find(".tbl_prod_name").text($("#prod_name").val());
    $(table).find(".tbl_qty").text($.number($("#qty").val(), 2));
    $(table).find(".tbl_unit").text($("#prod_unit").val());
    $(table).find(".tbl_curr").text($("#currency :selected").text());
    $(table).find(".tbl_curr").data("id", $("#currency").val());
    $(table).find(".tbl_purchase").text($.number($("#cost").val(), 2));
    $(table).find(".tbl_vat").text($("#vat :selected").text());
    $(table).find(".tbl_vat").data("id", $("#vat").val());
    $(table).find(".tbl_total_price").text($.number($("#tot_w_vat").val(), 2));
    $(table).find(".tbl_net_vat").text($("#net_vat").val());
    $(table).find(".tbl_w_vat").text($("#tot_w_vat").val());
    $(table).find(".tbl_w_o_vat").text($("#tot_w_o_vat").val());
    $("#tbl_item_row").val("");
    reset_input();
}

function reset_input(){
    $(".prod_entry").find(":input").val("");
    $(".btn-exit").hide();
    $(".btn-enter").hide();
    $(".prod_entry").collapse('hide');
}

function get_product_transfer(){
    var tran_type = $("#trans_type").val();
    var trans_no = $("#trans_no").val();

    if (tran_type == "2"){

        swal({
          title: "Please Input Product Transfer No",
          type: "input",
          showCancelButton: true,
          closeOnConfirm: false,
          animation: "slide-from-top",
          inputPlaceholder: "Product Transfer No.....",
          showLoaderOnConfirm: true
        },
        function(inputValue){
          if (inputValue === false) return false;
          if (inputValue === "") {
            swal.showInputError("Please input Product Transfer No");
            return false
          }else{
            $.ajax({
                data : {trans_no : inputValue},
                url : base_url + "inventory_receive/get_product_transfer",
                type : "POST",
                dataType : "JSON"
                ,success : function(result){                    
                    $("#outlet_name").val(result.hdr[0].outlet_name);
                    $("#outlet_code").val(result.hdr[0].outlet_code);
                    $("#outlet_code").attr('data-type_1',result.hdr[0].recipient_type);
                    $("#outlet_code").attr('data-id',result.hdr[0].recipient_id);
                    $("#trans_no").val(result.hdr[0].inv_no);
                    $("#trans_date").val(result.hdr[0].inv_date);

                    $("#outlet_code").attr("readonly", true);
                    $("#outlet_name").attr("readonly", true);
                    $("#trans_no").attr("readonly", true);
                    $("#trans_date").attr("readonly", true);

                    var dtl = result.dtl;

                    for (var i = 0; i < dtl.length; i++) {
                        $("#tbl-products tbody").append("<tr class='item_row_table'>"+
                            "<td style='width: 2.5%;' class='tbl_prod_no text-left'>"+ dtl[i].product_no +
                            "</td><td style='width: 7%;' class='tbl_prod_name text-left'>"+ dtl[i].product_no +
                            "</td><td style='width: 1%;' class='tbl_qty text-left'>"+ dtl[i].product_no +
                            "</td><td style='width: 1%;' class='tbl_unit text-left'>"+ dtl[i].product_no +
                            "</td><td style='width: 1%;' class='tbl_curr text-left'>"+ dtl[i].product_no +
                            "</td><td style='width: 1%;' class='tbl_purchase text-left'>"+ dtl[i].product_no +
                            "</td><td style='width: 1%;' class='tbl_vat text-center'>"+ dtl[i].product_no +
                            "</td><td style='width: 2%;' class='tbl_total_price text-left'>"+ dtl[i].product_no +
                            "</td><td style='width: 1%;' class='tbl_net_vat text-left' hidden>"+ dtl[i].product_no +
                            "</td><td style='width: 1%;' class='tbl_w_vat text-center' hidden>"+ dtl[i].product_no +
                            "</td><td style='width: 2%;' class='tbl_w_o_vat text-left' hidden>"+ dtl[i].product_no +
                            "</td><td style='width: 1%;' class='text-center text-red remove_item'>"+ "<i class='fa fa-minus-circle remove_item_table' style='color:red;cursor:pointer;' id='remove_item_table'></i>" +
                            "</td></tr>");
                    }                    

                    swal.close();
                }, error : function(err){
                    console.log(err.responseText);
                }
            });
          }
        });
    }

}

function compute_vat(){
    var unit_price = $("#cost").val();
    var vat = $("#vat").val();
    var total_amount = Number($("#cost").val() * $("#qty").val());
    var total_vat = 0;
    var total_net_vat = 0;

    console.log(vat);

    if (vat == "1"){
        total_vat = total_amount * 0.12;
        total_net_vat = total_amount - total_vat;
    }

    $("#net_vat").val(total_vat);
    $("#tot_w_vat").val(total_amount);
    $("#tot_w_o_vat").val(total_net_vat);

}

function check_required_fields(){
      var receive_no =  $('#receive_no').val();
      var receive_date =  $('#receive_date').val();
      var trans_type =  $('#trans_type').val();
      var outlet_code = $('#outlet_code').data('id');
      var outlet_name = $('#outlet_name').val();
      var outlet_type = $('#outlet_code').data('type_1');
      var trans_no = $('#trans_no').val();
      var trans_date = $('#trans_date').val();
      var total_tr = $('#tbl-products > tbody > tr').length;

    if(jQuery.trim(receive_no).length <= 0 || jQuery.trim(receive_date).length <= 0 || 
        jQuery.trim(trans_type).length <= 0 || jQuery.trim(outlet_code).length <= 0
        || jQuery.trim(outlet_name).length <= 0 || jQuery.trim(trans_no).length <= 0
        || jQuery.trim(trans_date).length <= 0 || total_tr <= 0) {
            swal({
                type : 'warning',
                title : 'Please fill up required fields.',
                timer : 2000
            });
            return false            
    }else{
        $.ajax({
            data : {"receive_no" : receive_no},
            type : "POST",
            dataType : "JSON",
            url : base_url + "inventory_receive/select_inventory_receive",
            success : function(result){
                if (result.length > 0){
                    swal({
                        type : "error",
                        timer : 2000,
                        title : "Receive No is already exists"
                    })
                }else{
                    data_saving();
                }
            }, error : function(err){
                console.log(err.responseText);
            }
        });
    }
}

function data_saving(){
      var receive_no =  $('#receive_no').val();
      var receive_date =  $('#receive_date').val();
      var trans_type =  $('#trans_type').val();
      var outlet_code = $('#outlet_code').data('id');
      var outlet_name = $('#outlet_name').val();
      var outlet_type = $('#outlet_code').data('type_1');
      var trans_no = $('#trans_no').val();
      var trans_date = $('#trans_date').val();
      var sum = 0;
        $(".tbl_qty").each(function () {
            var num = $(this).text().replace(/,/g, "");
            if ($(this).text().length != 0) {
                sum += parseFloat(num);
            }
        });
        

      var dtl_data = [];
      var receive_hdr = {
            inv_type : "1",
            inv_no : receive_no,
            inv_date : receive_date,
            tran_type : trans_type,
            recipient_id : outlet_code,
            recipient_type : outlet_type,
            ref_trans_no : trans_no,
            ref_trans_date : trans_date,
            status : "1"
      } 

      if(jQuery.trim(receive_no).length <= 0 || jQuery.trim(receive_date).length <= 0 || 
        jQuery.trim(trans_type).length <= 0 || jQuery.trim(outlet_code).length <= 0
        || jQuery.trim(outlet_name).length <= 0) {
            swal({
                type : 'warning',
                title : 'Please fill up required fields.',
                timer : 2000
            });
            return false            
      }
      var total_tr = $('#tbl-products > tbody > tr').length;
      if (total_tr<=0) {
            swal({
                type : 'warning',
                title : 'Add items',
                timer : 2000
            });
            return false ;  
      }

      var vat_cost = 0;
      var vat = "";


      $('#tbl-products tr').each(function (row, tr){
            vat = $(tr).find('.tbl_vat').data("id");         
                if (vat == "1"){
                    vat_cost = (str_to_num($(tr).find('.tbl_purchase').text()) / 12);
                }else{
                    vat_cost = 0;
                }

                var sub = {
                    'prod_id' : $(tr).find('.tbl_prod_id').text(),
                    'qty' : str_to_num($(tr).find('.tbl_qty').text()),
                    'cost' : str_to_num($(tr).find('.tbl_purchase').text()),
                    'vat' : $(tr).find('.tbl_qty').data("id"),
                    'vat_cost' : vat_cost ,
                    'currency' : $(tr).find('.tbl_curr').data("id"),
                    'total_price' : str_to_num($(tr).find('.tbl_total_price').text()),
                    'net_vat' : str_to_num($(tr).find('.tbl_net_vat').text()),
                    'w_vat' : str_to_num($(tr).find('.tbl_w_vat').text()),
                    'w_o_vat' : str_to_num($(tr).find('.tbl_w_o_vat').text())
                } 
                dtl_data.push(sub);            
       });

      
      dtl_data.shift();
      var data = {receive_hdr:receive_hdr, receive_dtl: dtl_data};
      $.ajax({
            data : data
            , type: "POST"
            , url: base_url + "inventory_receive/save_data"
            , dataType: 'json'
            , crossOrigin: false     
            , success: function(result) {
                swal({
                    type : "success",
                    timer : 2000,
                    title : "Successfully Save"
                }, function(){
                    location.reload();
                });
            }, error: function(err) {
                console.log(err.responseText);
            }
      });  
};
