$(document).ready(function(){

	get_receive($("#receive_no").data('id'),$("#outlet_code").data('type_1'));

	$("#save").click(function(){
    data_saving($("#receive_no").data('id'));
  });

  $("#enter_item").click(function(){
        if ($("#qty").val() != 0 && $("#cost").val() != 0){
            if ($("#tbl_item_row").val() != ""){
                edit_item_table();
            }else{
                add_item_table();
            }
        }else{
            alert("Fill up required fields!")
        }
  }); 

  jQuery(document).on("click", ".remove_item_table", function(){
      $(this).closest("tr").remove(); 
  }); 

  $("#outlet_code").keyup(function(){
      if ($(this).val() == ""){
          $("#outlet_name").val("");
      }
  });

  $("#outlet_name").keyup(function(){
        if ($(this).val() == ""){
            $("#outlet_name").val("");
        }
  });


  $("#outlet_code").autocomplete({
        focus: function(event, ui){
            $("#outlet_name").val(ui.item.outlet_name);
        },
        select: function(event, ui){
            $("#outlet_name").val(ui.item.outlet_name);
            $("#outlet_code").attr('data-type_1',ui.item.type1);
            $("#outlet_code").attr('data-id',ui.item.id);
        },
        source: function(req, add){
            var outlet_code = $("#outlet_code").val();
            $.ajax({
                url: base_url + "Inventory_receive/search_outlet/"+1, 
                dataType: "json",
                type: "POST",
                data: {'outlet' : outlet_code},
                success: function(data){
                    console.log(data.response);
                    if(data.response =="true"){
                        add(data.result);
                    }else{
                        add('');
                    }
                }, error: function(err){
                    console.log("Error: " + err.responseText);
                }
            });
        }
  });  

  $("#outlet_name").autocomplete({
        focus: function(event, ui){
            $("#outlet_code").val(ui.item.outlet_code);
        },
        select: function(event, ui){
            $("#outlet_code").val(ui.item.outlet_code);
            $("#outlet_code").attr('data-type_1',ui.item.type1);
            $("#outlet_code").attr('data-id',ui.item.id);
        },
        source: function(req, add){
            var outlet_name = $("#outlet_name").val();
            $.ajax({
                url: base_url + "Inventory_receive/search_outlet/"+2, 
                dataType: "json",
                type: "POST",
                data: {'outlet' : outlet_name},
                success: function(data){
                    console.log(data.response);
                    if(data.response =="true"){
                        add(data.result);
                    }else{
                        add('');
                    }
                }, error: function(err){
                    console.log("Error: " + err.responseText);
                }
            });
        }
  });   

  $("#prod_no").keyup(function(){
        if ($(this).val() == ""){
            $("#prod_name").val("");
        }
  });

  $("#prod_name").keyup(function(){
        if ($(this).val() == ""){
            $("#prod_no").val("");
        }
  });

  $("#prod_no").autocomplete({
        focus: function(event, ui){
            $("#prod_name").val(ui.item.prod_name);
            $("#product_specs").val(ui.item.prod_specs);
            $("#product_type").val(ui.item.prod_type);
            $("#product_brand").val(ui.item.brand);
            $("#product_model").val(ui.item.model);
            $("#product_category").val(ui.item.category);
            $("#product_color").val(ui.item.color);
            $("#product_class").val(ui.item.class);
            $("#product_size").val(ui.item.size);
            $("#prod_no").attr('data-unit',ui.item.unit);
        },
        select: function(event, ui){
            $("#prod_name").val(ui.item.prod_name);
            $("#product_type").val(ui.item.prod_type);
            $("#product_specs").val(ui.item.prod_specs);
            $("#product_brand").val(ui.item.brand);
            $("#product_model").val(ui.item.model);
            $("#product_category").val(ui.item.category);
            $("#product_color").val(ui.item.color);
            $("#product_class").val(ui.item.class);
            $("#product_size").val(ui.item.size);
            $("#prod_no").attr('data-unit',ui.item.unit);
            var unserialized_files = ui.item.image
            var href_url ='http://192.168.97.172:8015/eoutletsuitev2/images/products/'+unserialized_files[0];
            $("#img-upload").attr("src", href_url);

        },
        source: function(req, add){
            var prod_no = $("#prod_no").val();
            $.ajax({
                url: base_url + "Inventory_receive/search_item/"+1, 
                dataType: "json",
                type: "POST",
                data: {'prod' : prod_no},
                success: function(data){
                    console.log(data.response);
                    if(data.response =="true"){
                        add(data.result);
                    }else{
                        add('');
                    }
                }, error: function(err){
                    console.log("Error: " + err.responseText);
                }
            });
        }
  });

  $("#prod_name").autocomplete({
        focus: function(event, ui){
            $("#prod_no").val(ui.item.prod_no);
            $("#product_type").val(ui.item.prod_type);
            $("#product_specs").val(ui.item.prod_specs);
            $("#product_brand").val(ui.item.brand);
            $("#product_model").val(ui.item.model);
            $("#product_category").val(ui.item.category);
            $("#product_color").val(ui.item.color);
            $("#product_class").val(ui.item.class);
            $("#product_size").val(ui.item.size);
            $("#prod_no").attr('data-unit',ui.item.unit);
        },
        select: function(event, ui){
            $("#prod_no").val(ui.item.prod_no);
            $("#product_type").val(ui.item.prod_type);
            $("#product_specs").val(ui.item.prod_specs);
            $("#product_brand").val(ui.item.brand);
            $("#product_model").val(ui.item.model);
            $("#product_category").val(ui.item.category);
            $("#product_color").val(ui.item.color);
            $("#product_class").val(ui.item.class);
            $("#product_size").val(ui.item.size);
            $("#prod_no").attr('data-unit',ui.item.unit);
            var unserialized_files = ui.item.image
            var href_url ='http://192.168.97.172:8015/eoutletsuitev2/images/products/'+unserialized_files[0];
            $("#img-upload").attr("src", href_url);

        },
        source: function(req, add){
            var prod_name = $("#prod_name").val();
            $.ajax({
                url: base_url + "Inventory_receive/search_item/"+2, 
                dataType: "json",
                type: "POST",
                data: {'prod' : prod_name},
                success: function(data){
                    console.log(data.response);
                    if(data.response =="true"){
                        add(data.result);
                    }else{
                        add('');
                    }
                }, error: function(err){
                    console.log("Error: " + err.responseText);
                }
            });
        }
  });


})

function get_receive(id,type){
	$.ajax({
		data : {"id" : id,"type" : type},
		url : base_url + "Inventory_receive/get_receive",
		type : "POST",
		dataType : "JSON",
		success : function(data){
            console.log(data);
			//For Header
			$("#trans_id").val(id);
			$("#receive_no").val(data.trans_hdr[0]['inv_no']);
			$("#receive_date").val(data.trans_hdr[0]['inv_date']);
			$("#trans_type").val(data.trans_hdr[0]['tran_type']);
			$("#outlet_code").val(data.trans_hdr[0]['supplier_code2']);
			$("#outlet_name").val(data.trans_hdr[0]['supplier_name']);
            $("#outlet_code").attr('data-type_1',data.trans_hdr[0]['supplier_type']);
            $("#outlet_code").attr('data-id',data.trans_hdr[0]['supplier_code']);
            $("#trans_no").val(data.trans_hdr[0]['ref_trans_no']);
            $("#trans_date").val(data.trans_hdr[0]['ref_trans_date']);
			
			//For Details
			var i = 0;
			for(var x=0; x<data.trans_dtl.length; x++) {	
				i++;
				$("#tbl-products tbody").append("<tr class='item_row_table'><td class='tbl_prod_no'>"+ data.trans_dtl[x]['product_id'] +
          "</td><td class='tbl_prod_name'>"+ data.trans_dtl[x]['product_name'] +
          "</td><td class='tbl_qty'>"+ $.number(data.trans_dtl[x]['qty'], 2) +
          "</td><td class='tbl_purchase'>"+ $.number(data.trans_dtl[x]['cost'], 2) +
          "</td><td class='tbl_total_price'>"+ $.number(data.trans_dtl[x]['total_price'], 2) +
					"</td><td class='text-center text-red'>"+ "<i class='fa fa-minus-circle remove_item_table' style='color:red' id='remove_item_table'></i>" +
					
					"</td></tr>");
			}

			
			
		}, error: function(err){
			console.log(err.responseText);
		}
	});
}

function data_saving(id){
      var receive_no =  $('#receive_no').val();
      var receive_date =  $('#receive_date').val();
      var trans_type =  $('#trans_type').val();
      var outlet_code = $('#outlet_code').data('id');
      var outlet_name = $('#outlet_name').val();
      var outlet_type = $('#outlet_code').data('type_1');
      var trans_no = $('#trans_no').val();
      var trans_date = $('#trans_date').val();
      var sum = 0;
        $(".tbl_qty").each(function () {
            var num = $(this).text().replace(/,/g, "");
            if ($(this).text().length != 0) {
                sum += parseFloat(num);
            }
        });
      

      var dtl_data = [];
      var receive_hdr = {
            receive_no : receive_no,
            receive_date : receive_date,
            trans_type : trans_type,
            supplier_code : outlet_code,
            supplier_type : outlet_type,
            total_qty : $.number(sum.toFixed(2),2),
            ref_trans_no : trans_no,
            ref_trans_date : trans_date,
            status : "3"
      } 

      if(jQuery.trim(receive_no).length <= 0 || jQuery.trim(receive_date).length <= 0 || 
        jQuery.trim(trans_type).length <= 0 || jQuery.trim(outlet_code).length <= 0
        || jQuery.trim(outlet_name).length <= 0 || jQuery.trim(trans_no).length <= 0
        || jQuery.trim(trans_date).length <= 0) {
            alert('Please fill up required fields.');
            return false            
      }
      var total_tr = $('#tbl-products > tbody > tr').length;
      if (total_tr<=0) {
            alert('Add items');
            return false ;  
      }
      $('#tbl-products tr').each(function (row, tr){
                var sub = {
                    'product_id' : $(tr).find('td:eq(0)').text(),
                    'qty' : $(tr).find('td:eq(2) ').text(),
                    'purchase_cost' : $(tr).find('td:eq(3) ').text(),
                    'total_price' : $(tr).find('td:eq(4) ').text()
                } 
                dtl_data.push(sub);            
       });

      
      dtl_data.shift();
      var data = {receive_hdr:receive_hdr, receive_dtl: dtl_data,hdr_id:id};
      console.log(data);
      //return false;
      $.ajax({

            data : data
            , type: "POST"
            , url: base_url + "Inventory_receive/update_data"
            , dataType: 'json'
            , crossOrigin: false     
            , success: function(result) {
                alert('Successfuly Save.');
                location.reload();
            }, error: function(err) {
                console.log(err.responseText);
            }
      });  
};

function add_item_table(){
    var qty = $("#qty").val();
    var cost = $("#cost").val();
    var prod = qty * cost;
    $("#tbl-products tbody").append("<tr class='item_row_table'><td class='tbl_prod_no'>"+ $("#prod_no").val() +
        "</td><td class='tbl_prod_name'>"+ $("#prod_name").val() +
        "</td><td class='tbl_qty'>"+ $.number($("#qty").val(), 2) +
        "</td><td class='tbl_purchase'>"+ $.number($("#cost").val(), 2) +
        "</td><td class='tbl_total_price'>"+ prod +
        "</td><td class='text-center text-red remove_item'>"+ "<i class='fa fa-minus-circle remove_item_table' style='color:red;cursor:pointer;' id='remove_item_table'></i>" +
        "</td></tr>");

    
    reset_input();
}

function edit_item_table(){
    var row = $("#tbl_item_row").val();
    var table = "#tbl-products tbody tr:eq("+row+")";
    $(table).find(".tbl_prod_no").text($("#prod_no").val());
    $(table).find(".tbl_prod_name").text($("#prod_name").val());
    $(table).find(".tbl_qty").text($("#qty").val());
    $(table).find(".tbl_purchase").text($("#sel_price").val());
    $(table).find(".tbl_total_price").text($("#total_price").val());
    $("#tbl_item_row").val("");
    reset_input();
}

function reset_input(){
    $("#prod_no").val("");
    $("#prod_name").val("");
    $("#product_specs").val("");
    $("#product_type").val("");
    $("#product_brand").val("");
    $("#product_model").val("");
    $("#product_category").val("");
    $("#product_color").val("");
    $("#product_class").val("");
    $("#product_size").val("");
    $("#qty").val("00");
    $("#cost").val("00");
    $("#img-upload").attr("src", "");

    $(".prod_entry").collapse('hide');
}