$(document).ready(function(){

    $(".btn-enter").hide();
    $(".btn-exit").hide();
    $("#qty").number(true, 2);
    $("#prod_price").number(true, 2);
    $("#prod_total_price").number(true, 2);

	$("#recipient_code").autocomplete({
		focus: function(event, ui){
			$("#recipient_name").val(ui.item.recipient_name);
			$("#recipient_type").val(ui.item.recipient_type);
			$("#recipient_id").val(ui.item.recipient_id);
		},
		select: function(event, ui){
			$("#recipient_name").val(ui.item.recipient_name);
			$("#recipient_type").val(ui.item.recipient_type);
			$("#recipient_id").val(ui.item.recipient_id);
		},
		source: function(req, add){
			var recipient = $("#recipient_code").val();
            $.ajax({
                url: base_url + "inventory_transfer/search_recipient/"+1, 
                dataType: "json",
                type: "POST",
                data: {'recipient' : recipient},
                success: function(data){
                    if(data.response =="true"){
                        add(data.result);
                    }else{
                        add('');
                    }
                }, error: function(err){
                	console.log("Error: " + err.responseText);
                }
            });
		}
	});

	$("#recipient_name").autocomplete({
		focus: function(event, ui){
			$("#recipient_code").val(ui.item.recipient_code);
			$("#recipient_type").val(ui.item.recipient_type);
			$("#recipient_id").val(ui.item.recipient_id);
		},
		select: function(event, ui){
			$("#recipient_code").val(ui.item.recipient_code);
			$("#recipient_type").val(ui.item.recipient_type);
			$("#recipient_id").val(ui.item.recipient_id);
		},
		source: function(req, add){
			var recipient = $("#recipient_name").val();
            $.ajax({
                url: base_url + "inventory_transfer/search_recipient/"+2, 
                dataType: "json",
                type: "POST",
                data: {'recipient' : recipient},
                success: function(data){
                    if(data.response =="true"){
                        add(data.result);
                    }else{
                        add('no data');
                        add('');
                    }
                }, error: function(err){
                	console.log("Error: " + err.responseText);
                }
            });
		}
	});

	$("#prod_no").autocomplete({
		focus: function(event, ui){
            $("#prod_name").val(ui.item.prod_name);
            $("#prod_unit").val(ui.item.prod_unit);
            $("#prod_price").val(ui.item.prod_price);
            $("#prod_curr").val(ui.item.prod_curr);
            $("#prod_no").data("id", ui.item.prod_id);
		},
		select: function(event, ui){
            $("#prod_name").val(ui.item.prod_name);
            $("#prod_unit").val(ui.item.prod_unit);
            $("#prod_price").val(ui.item.prod_price);
            $("#prod_curr").val(ui.item.prod_curr);
            $("#prod_no").data("id", ui.item.prod_id);
		},
		source: function(req, add){
			var product = $("#prod_no").val();
            $.ajax({
                url: base_url + "inventory_transfer/search_products/"+1, 
                dataType: "json",
                type: "POST",
                data: {'product' : product},
                success: function(data){
                    if(data.response =="true"){
                        add(data.result);
                    }else{
                        add('');
                    }
                }, error: function(err){
                	console.log("Error: " + err.responseText);
                }
            });
		}
	});

	$("#prod_name").autocomplete({
		focus: function(event, ui){
            $("#prod_no").val(ui.item.prod_no);
            $("#prod_unit").val(ui.item.prod_unit);
            $("#prod_price").val(ui.item.prod_price);
            $("#prod_curr").val(ui.item.prod_curr);
            $("#prod_no").data("id", ui.item.prod_id);
		},
		select: function(event, ui){
            $("#prod_no").val(ui.item.prod_no);
            $("#prod_unit").val(ui.item.prod_unit);
            $("#prod_price").val(ui.item.prod_price);
            $("#prod_curr").val(ui.item.prod_curr);
            $("#prod_no").data("id", ui.item.prod_id);
		},
		source: function(req, add){
			var product = $("#prod_name").val();
            $.ajax({
                url: base_url + "inventory_transfer/search_products/"+2, 
                dataType: "json",
                type: "POST",
                data: {'product' : product},
                success: function(data){
                    if(data.response =="true"){
                        add(data.result);
                    }else{
                        add('');
                    }
                }, error: function(err){
                	console.log("Error: " + err.responseText);
                }
            });
		}
	});

    $(".btn-add").click(function(){
        if ($(".prod_entry").is(":visible") == true){
            $(".btn-enter").hide();
            $(".btn-exit").hide();
            $(".prod_entry").collapse('hide');
        }else{
            $(".btn-enter").show();
            $(".btn-exit").show();
            $(".prod_entry").collapse('show');            
        }
    });

    $(".btn-exit").click(function(){
        $(".btn-enter").hide();
        $(".btn-exit").hide();
        $(".prod_entry").collapse('hide');
        reset_item_input();
    }); 

	$("#enter_item").click(function(){
		if ($("#qty").val() != 0){
			if ($("#tbl_item_row").val() != ""){
				edit_item_table();
			}else{
				add_item_table();
			}
		}else{
			swal({
				type : "warning",
				title : "Please input transfer qty",
				timer : 1000
			})
		}
	});

	jQuery(document).on("click", ".remove_item_table", function(){
		$(this).closest("tr").remove();		
	});	

	jQuery(document).on("click", ".item_row_table", function(){
		var row = $(this).closest("tr").index();
		var id = $(this).closest("tr").find(".tbl_prod_id").text();
		$("#tbl_item_row").val(row);
		select_row_table(row);
		find_onhand_qty(id);
	});	

    $("#qty").keyup(function(){
        compute_total();
    }); 

	$("#save").click(function(){
		check_required_fields();
	});

});

function compute_total(){
    var qty = $("#qty").val();
    var price = $("#prod_price").val();

    var total = Number(qty) * Number(price);

    $("#prod_total_price").val(total);
}

function add_item_table(){
    var qty = $("#qty").val();
    $("#tbl-products tbody").append("<tr class='item_row_table'>"+
        "<td class='tbl_prod_no text-left' style='width: 1.5%;'>" + $("#prod_no").val() +
        "</td><td class='tbl_prod_name text-left' style='width: 3%;'>" + $("#prod_name").val() +
        "</td><td class='tbl_qty text-left' style='width: 1.5%;'>" + $.number($("#qty").val(), 2) +
        "</td><td class='tbl_unit text-left' style='width: 1%;'>" + $("#prod_unit").val() + 
        "</td><td class='tbl_currency text-left' style='width: 1.1%;'>" + $("#prod_curr").val() +
        "</td><td class='tbl_price text-left' style='width: 1.5%;'>"+ $.number($("#prod_price").val(),2) + 
        "</td><td class='tbl_total_price text-left' style='width: 2%;'>"+ $.number($("#prod_total_price").val(),2) + 
        "</td><td class='tbl_prod_id text-left' hidden>"+ $("#prod_no").data("id") + 
        "</td><td class='text-center text-red remove_item' style='width: 1%;'>"+ "<i class='fa fa-minus-circle remove_item_table' style='color:red;cursor:pointer;' id='remove_item_table'></i>" +
        "</td></tr>");
    reset_item_input();
}

function select_row_table(row){
	var table = "#tbl-products tbody tr:eq("+row+")";
	$("#prod_no").val($(table).find(".tbl_prod_no").text());
	$("#prod_name").val($(table).find(".tbl_prod_name").text());
	$("#qty").val($(table).find(".tbl_qty").text());
	$("#prod_unit").val($(table).find(".tbl_unit").text());
	$("#prod_curr").val($(table).find(".tbl_currency").text());
	$("#prod_price").val($(table).find(".tbl_price").text());
	$("#prod_total_price").val($(table).find(".tbl_total_price").text());
	
	$(".btn-exit").show();
	$(".btn-enter").show();
    $(".prod_entry").collapse('show');
}

function find_onhand_qty(id){

}

function edit_item_table(){

	var row = $("#tbl_item_row").val();
	var table = "#tbl-products tbody tr:eq("+row+")";

	$(table).find(".tbl_prod_no").text($("#prod_no").val());
	$(table).find(".tbl_prod_name").text($("#prod_name").val());
	$(table).find(".tbl_unit").text($("#prod_unit").val());
	$(table).find(".tbl_qty").text($.number($("#qty").val(),2));
	$(table).find(".tbl_currency").text($("#prod_curr").val());
	$(table).find(".tbl_price").text($.number($("#prod_price").val(), 2));
	$(table).find(".tbl_total_price").text($.number(($("#prod_price").val() * $("#qty").val()), 2));
	$(table).find(".tbl_prod_id").text($("#prod_no").data("id"));

	reset_item_input();
}

function reset_item_input(){
	$(".prod_entry").find(":input").val("");
	$("#tbl_item_row").val("");
	$(".btn-exit").hide();
	$(".btn-enter").hide();
    $(".prod_entry").collapse('hide');
}

function check_required_fields(){

	var trans_no = $("#transfer_no").val();
	var trans_date  = $("#transfer_date").val();
	var recipient_code = $("#recipient_code").val();
	var recipient_name = $("#recipient_name").val();
	var ref_trans_no = $("#ref_trans_no").val();
	var ref_trans_date = $("#ref_trans_date").val();
	var purpose = $("#purpose").val();
	var rows = $('#tbl-products > tbody > tr').length;

	if (trans_no == "" || trans_date == "" || recipient_code == "" || recipient_name == "" || purpose == "" || rows == 0){
		swal({
			type : "warning",
			title : "Please input all required fields",
		})
	}else{
        $.ajax({
            url: base_url + "inventory_transfer/select_transfer_no/", 
            dataType: "json",
            type: "POST",
            data: {'transfer_no' : trans_no},
            success: function(result){
            	console.log(result.length);
            	if (result.length != 0){
            		swal({
            			type : "error",
            			timer : 2000,
            			title : "Transfer no is already exists"
            		})
            	}else{
            		insert();
            	}
            }, error: function(err){
            	console.log("Error: " + err.responseText);
            }
        });

	}

}

function insert(){
	var trans_no = $("#transfer_no").val();
	var trans_date  = $("#transfer_date").val();
	var trans_type = $("#transaction_type").val();
	var recipient_id = $("#recipient_id").val();
	var recipient_type = $("#recipient_type").val();
	var ref_trans_no = $("#ref_trans_no").val();
	var ref_trans_date = $("#ref_trans_date").val();
	var purpose = $("#purpose").val();
	
	var transfer_dtl = new Array();
	var transfer_hdr = {
		trans_no : trans_no,
		trans_date : trans_date,
		trans_type : trans_type,
		recipient_type : recipient_type,
		recipient_id : recipient_id, 
		ref_trans_no : ref_trans_no,
		ref_trans_date : ref_trans_date,
		purpose : purpose

	}

	$('#tbl-products tbody tr').each(function (row, tr){
	        var sub = {
	            'prod_id' : $(tr).find('.tbl_prod_id').text(),
	            'qty' : str_to_num($(tr).find('.tbl_qty').text()),
                'cost' : str_to_num($(tr).find('.tbl_price').text()),
                'total_cost' : str_to_num($(tr).find('.tbl_total_price').text())
	        } 
	        transfer_dtl.push(sub);            
	});	

	$.ajax({
		data : {"transfer_hdr" : transfer_hdr, "transfer_dtl" : transfer_dtl, "transfer_no" : trans_no},
		type : "POST",
		dataType : "JSON",
		url : base_url + "inventory_transfer/insert_inventory_transfer",
		success : function(result){
			console.log(result);
			if (result == 1){
				swal({
					type : "success",
					timer : 2000,
					title : "Successfully Added"
				});
			}else {
				// swal({
				// 	type : "success",
				// 	timer : 2000,
				// 	title : "Transfer No is already exists"
				// })
			} 
		}, error : function(err){
			console.log(err.responseText);
		}
	});

}