$(document).ready(function(){

	query_data();

	$("#search").click(function(){
		query_data();
	});

});

function query_data(){
	var keyword = $("#keyword").val();
	var app_func = $("#app_func").val();

	$.ajax({
		data : {keyword : keyword, app_func : app_func},
		type : "POST",
		dataType : "JSON",
		url : base_url + "Inventory_return/query_inventory_return",
		success: function(result){
			$("#div-query").html(result);
		}, error: function(err){
			console.log(err.responseText);
		}
	});

}

function cancel_return(id,key){
	var value = $("#tbl-data tbody tr:eq("+(key)+")").find("td:eq(0)").text();
	swal({
		title: "Are you sure do you want to Cancel Return#: "+ value +" ?",
		type: "warning",
		showCancelButton: true,
		confirmButtonColor: '#DD6B55',
		confirmButtonText: 'Confirm',
		closeOnConfirm: false,
		closeOnCancel: false,
		timer: 3000
		},function(isConfirm){
			if (isConfirm){
			  	$.ajax({
			    	data : {"id" : id},
			    	url : base_url + "Inventory_return/cancel_return",
			    	type : "POST",
			    	dataType : "JSON",
			    	success : function (result){
			      		query_data();
				      swal("Successfully Cancel", "", "success");
				    }, error : function(err){
				    	console.log(err.responseText);
			    	}       
				});
			}else{
			    swal("Cancelled", "", "error");
			}
	});
}

function edit_return(id){
	$("body").empty();
	$("body").load(base_url + "menu/edit_menu/3/4/2/"+id);
}