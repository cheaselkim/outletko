<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_registry_model extends CI_Model {

	public function __construct(){
		parent::__construct();
			$this->load->database();
			$result = $this->login_model->check_session();
			if ($result != true){
				redirect("/");
			} 
	}

	public function business_type(){
		$result = $this->db->query("SELECT * FROM business_type")->result();
		return $result;
	}

	public function subscription_type(){
		$result = $this->db->query("SELECT * FROM subscription_type")->result();
		return $result;
	}

	public function currency(){
		$result = $this->db->query("SELECT * FROM currency ORDER BY FIELD(curr_code, 'CNY', 'USD', 'PHP') DESC LIMIT 3")->result();
		return $result;
	}

	public function insert_account($user_app){
        $this->db->insert("account_application", $user_app);
        return ($this->db->affected_rows() > 0) ? $this->db->insert_id() : 0;		
	}

	public function insert_users($users){
        $this->db->insert("users", $users);
        return ($this->db->affected_rows() > 0) ? 1 : 0;				
	}

	public function account_id(){
		$result = $this->db->query("SELECT (MAX(account_id)) as account_id FROM account_application WHERE YEAR(date_insert) = '".date('Y')."'")->row();
		return str_pad((substr($result->account_id, -4) + 1), 4, '0', STR_PAD_LEFT); 		
	}

}
