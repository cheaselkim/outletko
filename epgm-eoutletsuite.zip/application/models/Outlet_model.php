<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Outlet_model extends CI_Model {

    public function __construct(){
        parent::__construct();
            $this->load->database();
                $result = $this->login_model->check_session();
                if ($result != true){
                    redirect("/");
                }
    }

    public function outlet_type(){
        $query = $this->db->query("SELECT * FROM outlet_type")->result();
        return $query;
    }

    public function search_outlet_city($outlet_city){
        $query = $this->db->query("SELECT 
            province_desc,
            city_desc,
             `city`.`province_id` AS prov_id,
             `city`.`id` AS city_id
            FROM province 
            INNER JOIN city ON
            `city`.`province_id` = `province`.`id`
            WHERE city_desc LIKE ?
            ORDER BY city_desc, province_desc
            LIMIT 10", array($outlet_city.'%'))->result();
        return $query;
    }

    public function save_outlet($outlet_hdr) {
        $this->db->insert('outlet', $outlet_hdr);
        return ($this->db->affected_rows() > 0) ? true : false;
    }

    public function outlet_list($type,$status,$term){
        
        if($type!=""){
            $str1 = "and `outlet`.`outlet_type` = '".$type."'";
        }else{
            $str1="";
        }

        if($status!=""){
            $str2 = "and outlet_status = '".$status."'";
        }else{
            $str2="";
        }

        if($term!=""){
            $str3 = "and (outlet_code like '%".$term."%' or outlet_name like '%".$term."%')";
        }else{
            $str3="";
        }


        $comp_id = $this->session->userdata('comp_id');
        $query = $this->db->query("SELECT * FROM outlet 
            LEFT JOIN outlet_type ON 
            `outlet_type`.`id` = `outlet`.`outlet_type` 
            WHERE `outlet`.`comp_id` = '".$comp_id."' ".$str1." ".$str2." ".$str3." ")->result();
        return $query;
    }

    public function get_outlet_dtl($id){
        $query = $this->db->query("SELECT
            `outlet`.*
            , `city`.`city_desc`
            , `province`.`province_desc`
            , `outlet_type`.`outlet_type` AS `outlet_type_desc`
            , `status`.`status` AS `status_desc`
        FROM
            `outlet`
            LEFT JOIN `city` 
                ON (`outlet`.`outlet_city` = `city`.`id`)
            LEFT JOIN `province` 
                ON (`outlet`.`outlet_province` = `province`.`id`)
            LEFT JOIN `outlet_type` 
                ON (`outlet`.`outlet_type` = `outlet_type`.`id`)
            LEFT JOIN `status` 
                ON (`outlet`.`outlet_status` = `status`.`id`)
            WHERE `outlet`.`id` = '".$id."' ")->result();
        return $query;
    }

    public function search_field() {
        $hint = $this->input->get('term');
        $comp_id = $this->session->userdata('comp_id');
        $query = $this->db->query("SELECT outlet_code as term, outlet_name as term FROM outlet where comp_id = '".$comp_id."' and (outlet_code like '%".$hint."%' or outlet_name like '%".$hint."%') ");
        return $query;
    }

    public function update_outlet($outlet_hdr,$outlet_id) {
        $this->db->where('outlet_code',$outlet_id);
        $this->db->update('outlet',$outlet_hdr);
    }

    public function delete_outlet($id){
        $query = $this->db->query("DELETE FROM outlet WHERE id = ?", array($id));
        return ($this->db->affected_rows() > 0) ? true : false;
    }

}
