<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sales_model extends CI_Model {

  public function __construct(){
    parent::__construct();
    $this->load->database();
      $result = $this->login_model->check_session();
      if ($result != true){
        redirect("/");
      }
  }

  public function max_transno(){
    $query = $this->db->query("SELECT LPAD((MAX(trans_no) + 1), 5, '0') AS max_transno FROM sales_transaction_hdr WHERE outlet_id = ?", array($this->session->userdata('outlet_id')))->row();
    return $query->max_transno;
  }

  public function currency(){
    $query = $this->db->query("SELECT id, curr_code FROM currency ORDER BY FIELD(curr_code, 'CNY', 'USD', 'PHP') DESC LIMIT 3")->result();         
    return $query;
  }

  public function payment_type(){
    $query = $this->db->query("SELECT * FROM payment_type WHERE comp_id = ?", $this->session->userdata("comp_id"))->result();
    return $query;
  }

  public function bank_list(){
    $query = $this->db->query("SELECT id, bank_code FROM bank_list WHERE comp_id = ?", $this->session->userdata("comp_id"))->result();
    return $query;
  }

  public function search_custcode($cust_code){
    $query = $this->db->query("SELECT cust_code, cust_name, id FROM customer WHERE comp_id IN ? AND outlet_id IN ? AND cust_code LIKE ?", array(array($this->session->userdata("comp_id"), "0"), array($this->session->userdata("outlet_id"), "0"), '%'.$cust_code.'%'))->result();
    return $query;
  }

  public function search_custname($cust_name){
    $query = $this->db->query("SELECT cust_code, cust_name, id FROM customer WHERE comp_id IN ? AND outlet_id IN ? AND cust_name LIKE ?", array(array($this->session->userdata("comp_id"), "0"), array($this->session->userdata("outlet_id"), "0"), '%'.$cust_name.'%'))->result();
    return $query;
  }


  public function search_item($item_cat, $item_keyword){
    $sql = "";
    $item_search = "";

    $sql .= "SELECT 
      `products`.`id`,
      `products`.`product_no`,
      `products`.`product_name`,
      `product_category`.`category_desc`,
      `inventory`.`inventory_qty`,
      `product_unit`.`unit_desc`,
      `products`.`reg_selling_price`
      FROM `products`
      INNER JOIN `inventory` ON
      `products`.`id` = `inventory`.`product_id`
      INNER JOIN `product_unit` ON
      `product_unit`.`id` = `products`.`stock_unit_id`
      INNER JOIN `product_category` ON
      `products`.`category_id` = `product_category`.`id`
      WHERE `products`.`comp_id` = ? AND 
      (CASE WHEN (`products`.`outlet_id` = '0') THEN `products`.`outlet_id` = '0' ELSE `products`.`outlet_id` = '1' END)";

    if (!empty($item_keyword)){
      $sql .= "AND product_name LIKE '%".$item_keyword."%'";
      $item_search = $item_keyword;
    }else{
      $sql .= "AND `products`.`category_id` = '".$item_cat."'";
      $item_search = $item_cat;
    }

    $result = $this->db->query($sql, array($this->session->userdata("comp_id")))->result();

    return $result;
  }  

  public function select_item($prod_id){

    $sql = "SELECT 
      `products`.`id`,
      `products`.`product_no`,
      `products`.`product_name`,
      `inventory`.`inventory_qty`,
      `product_unit`.`unit_desc`,
      `products`.`reg_selling_price`,
      `products`.`image_loc`
      FROM `products`
      INNER JOIN `inventory` ON
      `products`.`id` = `inventory`.`product_id`
      INNER JOIN `product_unit` ON
      `product_unit`.`id` = `products`.`stock_unit_id`
      WHERE `products`.`id` = ? ";

    $result = $this->db->query($sql, $prod_id)->result();
    return $result;
  }

  public function sales_query($keyword, $status){

    $sql = "SELECT 
    `customer`.`cust_name`, 
    `sales_transaction_hdr`.* 
    FROM sales_transaction_hdr 
    INNER JOIN customer ON 
    `customer`.`id` = `sales_transaction_hdr`.`customer_id`
    WHERE `sales_transaction_hdr`.`comp_id` = '".$this->session->userdata("comp_id")."' AND ((`customer`.`cust_name` LIKE '%".$keyword."%' or `sales_transaction_hdr`.`trans_no` LIKE '%".$keyword."%') AND status = '".$status."')";
    // $result = $this->db->query($sql, array($this->session->userdata("comp_id"), $keyword, $keyword, $status))->result();
    $result = $this->db->query($sql)->result();
    return $result;
  }

  public function get_transaction_hdr($id){
    $query = $this->db->query("SELECT  
    `sales_transaction_hdr`.*,
    `customer`.`cust_code`,
    `customer`.`cust_name`
    FROM sales_transaction_hdr
    INNER JOIN customer ON 
    `customer`.`id` = `sales_transaction_hdr`.`customer_id`
    WHERE `sales_transaction_hdr`.`id` = '".$id."' ")->result();
    return $query;
  }

  public function get_transaction_dtl($id){
    $query = $this->db->query(" SELECT * FROM sales_transaction_dtl 
    LEFT JOIN products ON `products`.product_no = `sales_transaction_dtl`.product_id
    LEFT JOIN product_unit ON `product_unit`. id = `products`.stock_unit_id
     WHERE sales_hdr_id = '".$id."' ");
    return $query;
  }

  public function get_transaction_payment($id){
    $query = $this->db->query("SELECT * from payment_transaction where sales_hdr_id = '".$id."' ")->result();
    return $query;
  }

  // SAVING OF TRANSACTION
  public function save_transaction_hdr($sales_hdr) {
        $this->db->insert('sales_transaction_hdr', $sales_hdr);
        return ($this->db->affected_rows() == 1) ? $this->db->insert_id() : false;
  }

  public function save_transaction_dtl($data,$hdr_id) {
        foreach($data as $key){
            $sub_dtl[] = array(
                    'sales_hdr_id' =>  $hdr_id,
                    'product_id'   =>  $key['product_id'],
                    'qty'          =>  $key['qty'],
                    'selling_price'=>  $key['selling_price'],
                    'total_price'  =>  $key['total_price'],
                    'volume_discount'  =>  $key['volume_discount'],
                    'total_selling_price'  =>  $key['total_selling_price'],
                    'share'  =>  $key['share'],
                    'share_amount'  =>  $key['share_amount'],
                    'total_amount'  =>  $key['total_amount']
            );
        }

        $this->db->insert_batch('sales_transaction_dtl',$sub_dtl);
        return ($this->db->affected_rows() > 0) ? true : false;
  }

  public function save_payment_dtl($data) {
        $this->db->insert('payment_transaction', $data);
        return ($this->db->affected_rows() > 0) ? true : false;
  }

  // ANOTHER WAY OF SAVING
  public function save_transaction($sales_hdr,$sales_dtl,$payment_dtl) {
        
        $db->trans_begin();
        $this->db->insert('sales_transaction_hdr2', $sales_hdr);
        $hdr_id = $this->db->insert_id() ;

        foreach($data as $key){
            $sub_dtl[] = array(
                    'sales_hdr_id' =>  $hdr_id,
                    'product_id'   =>  $key['product_id'],
                    'qty'          =>  $key['qty'],
                    'selling_price'=>  $key['selling_price'],
                    'total_price'  =>  $key['total_price'],
                    'volume_discount'  =>  $key['volume_discount'],
                    'total_selling_price'  =>  $key['total_selling_price'],
                    'share'  =>  $key['share'],
                    'share_amount'  =>  $key['share_amount'],
                    'total_amount'  =>  $key['total_amount']
            );
        }
        $this->db->insert_batch('sales_transaction_dtl',$sub_dtl);

        $data = array(
                    'sales_hdr_id'   => $hdr_id,
                    'payment_date'   => $payment_dtl['payment_date'],
                    'payment_type_id'=> $payment_dtl['payment_type_id'],
                    'bank_id'        => $payment_dtl['bank_id'],
                    'check_card_no'  => $payment_dtl['check_card_no'],
                    'check_date'     => $payment_dtl['check_date'],
                    'curr_id'        => $payment_dtl['curr_id'],
                    'amount'         => $payment_dtl['amount']
                );
        $this->db->insert('payment_transaction', $data);

        if($db->trans_status() === FALSE){
            $db_error = "";
            $db_error = $this->db->error();
            $db->trans_rollback();
            return $db_error;
        }else{  
             $db->trans_commit();
           return true;
        }   
  }

  //  UPDATING OF TRANSACTION
  public function edit_transaction_hdr($sales_hdr,$hdr_id) {
        $this->db->where('id',$hdr_id);
        $this->db->update('sales_transaction_hdr',$sales_hdr);
  }

  public function edit_transaction_dtl($data,$hdr_id) {
        foreach($data as $key){
            $sub_dtl[] = array(
                    'sales_hdr_id' =>  $hdr_id,
                    'product_id'   =>  $key['product_id'],
                    'qty'          =>  $key['qty'],
                    'selling_price'=>  $key['selling_price'],
                    'total_price'  =>  $key['total_price'],
                    'volume_discount'  =>  $key['volume_discount'],
                    'total_selling_price'  =>  $key['total_selling_price'],
                    'share'  =>  $key['share'],
                    'share_amount'  =>  $key['share_amount'],
                    'total_amount'  =>  $key['total_amount']
            );
        }
        $this->db->where('sales_hdr_id',$hdr_id);
        $this->db->delete('sales_transaction_dtl');
        $this->db->insert_batch('sales_transaction_dtl',$sub_dtl);
        return ($this->db->affected_rows() > 0) ? true : false;
  }

  public function edit_payment_dtl($data,$hdr_id) {
         $this->db->where('id',$hdr_id);
        $this->db->update('payment_transaction',$data);
        return ($this->db->affected_rows() > 0) ? true : false;
  }

  public function cancel_trans($id){
    $this->db->where("id", $id);
    $this->db->set("status", "0");
    $this->db->update("sales_transaction_hdr");
    return ($this->db->affected_rows() > 0) ? true : false;
  }

}
