<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sales_force_model extends CI_Model {

    public function __construct(){
        parent::__construct();
            $this->load->database();
                $result = $this->login_model->check_session();
                if ($result != true){
                    redirect("/");
                }
    }

    public function get_outlet($comp_id){
        $query = $this->db->query("SELECT * FROM outlet where comp_id ='".$comp_id."'")->result();
        return $query;
    }

    public function sales_force_type(){
        $query = $this->db->query("SELECT * FROM sales_force_type")->result();
        return $query;
    }

    public function account_id($outlet){
        $result = $this->db->query("SELECT (MAX(account_id)) AS account_id FROM sales_force WHERE YEAR(date_created) = ? AND outlet = ? ", array(date("Y"), $outlet))->row();
        return ((substr($result->account_id,0, 3)).str_pad($outlet, 2, '0', STR_PAD_LEFT).str_pad((substr($result->account_id, -3) + 1), 3, '0', STR_PAD_LEFT)); 
    }

    public function insert_users($users){
        $this->db->insert("users", $users);
        return ($this->db->affected_rows() > 0) ? $this->db->insert_id() : 0;                
    }

    public function save_sales_force($data_hdr) {
        $this->db->insert('sales_force', $data_hdr);
        return ($this->db->affected_rows() > 0) ? true : false;
    }

    public function sales_force_list($term){

        if($term !=""){
            $str3 = "and (CONCAT(first_name,' ',last_name) like '%".$term."%')";
        }else{
            $str3="";
        }
        $comp_id = $this->session->userdata('comp_id');
        $query = $this->db->query("SELECT *,`sales_force`.id as table_id, CONCAT(first_name,' ',last_name) as name FROM sales_force  
            LEFT JOIN outlet ON 
            `outlet`.`id` = `sales_force`.`outlet`
            WHERE `sales_force`.`comp_id` = '".$comp_id."'  ".$str3." 
            ORDER BY `sales_force`.`outlet`, first_name")->result();
        return $query;
    }

    public function get_sales_force_dtl($id){
        $query = $this->db->query("SELECT * from sales_force 
            where id = '".$id."' ")->result();
        return $query;
    }

    public function search_field() {
        $hint = $this->input->get('term');
        $comp_id = $this->session->userdata('comp_id');
        $query = $this->db->query("SELECT  CONCAT(first_name,' ',last_name) as term FROM sales_force where comp_id = '".$comp_id."' and first_name like '%".$hint."%' || last_name like '%".$hint."%'");
        return $query;
    }

    public function update_sales_force($sales_force_hdr,$sales_force_id) {
        $this->db->where('id',$sales_force_id);
        $this->db->update('sales_force',$sales_force_hdr);
    }

    public function delete_sales_force($id){
        $query = $this->db->query("DELETE FROM sales_force WHERE id = ?", array($id));
        return ($this->db->affected_rows() > 0) ? true : false;
    }

    public function user_list(){
        $comp_id = $this->session->userdata('comp_id');
        $query = $this->db->query("SELECT id,CONCAT(first_name ,' ', last_name) as name from sales_force WHERE comp_id = '".$comp_id."'")->result();
        return $query;
    }

    public function save_user_roles($table_data) {
        foreach($table_data as $key){
            $sub_dtl[] = array(
                    
                    'user_id'   =>  $key['user_id'],
                    'module_id'=>  $key['module_id'],
                    'sub_module_id'  =>  $key['sub_module_id'],
                    'function_id'  =>  $key['function_id']
            );
        }
        $this->db->insert_batch('user_roles_trans',$sub_dtl);
        //$this->db->insert('user_roles_trans', $table_data);
        return ($this->db->affected_rows() > 0) ? true : false;
    }

}
