<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Inventory_receive_model extends CI_Model {

  public function __construct(){
    parent::__construct();
    $this->load->database();
    $result = $this->login_model->check_session();
    if ($result != true){
        redirect("/");
    }
  }

  public function search_outlet($outlet){
    $query = $this->db->query("SELECT 
        '2' AS TYPE
        ,cust_code AS CODE 
        ,id AS ID 
        ,cust_name AS NAME 
      FROM customer 
      WHERE cust_code LIKE '".$outlet."%' AND comp_id = '".$this->session->userdata('comp_id')."'
      UNION 
      SELECT 
        '1' AS TYPE
        ,outlet_code AS CODE
        ,id as ID
        ,outlet_name AS NAME 
        FROM outlet WHERE 
        outlet_code like '".$outlet."%' AND comp_id = '".$this->session->userdata('comp_id')."'
		UNION 
		SELECT 
		'3' AS TYPE
		, supp_code AS CODE
		, id AS ID
		, supp_name AS NAME
		FROM supplier
		WHERE supp_code LIKE '".$outlet."%' AND comp_id = '".$this->session->userdata('comp_id')."'
      ")->result();
    return $query;
  }

  public function search_name($outlet){
    $query = $this->db->query("SELECT 
    	'2' AS TYPE
    	,cust_code AS CODE
    	,id as ID
    	,cust_name AS NAME 
    	FROM customer 
    	WHERE cust_name like '".$outlet."%'  AND comp_id = '".$this->session->userdata('comp_id')."'
    	UNION 
    	SELECT 
    	'1' AS TYPE
    	,outlet_code AS CODE
    	,id as ID
    	,outlet_name AS NAME 
    	FROM outlet where outlet_name like '".$outlet."%' AND comp_id = '".$this->session->userdata('comp_id')."'
    	UNION 
    	SELECT 
    	'3' AS TYPE
    	, supp_code AS CODE
    	, id AS ID
    	, supp_name AS NAME
    	FROM supplier
    	WHERE supp_name LIKE '".$outlet."%' AND comp_id = '".$this->session->userdata('comp_id')."'")->result();
    return $query;
  }

  public function search_item_code($prod){
    $query = $this->db->query("SELECT * FROM products 
    LEFT JOIN product_type ON product_type.id = products.type_id
    LEFT JOIN product_brand ON product_brand.id = products.brand_id
    LEFT JOIN product_color ON product_color.id = products.color_id
    LEFT JOIN product_model ON product_model.id = products.model_id
    LEFT JOIN product_size ON product_size.id = products.size_id
    LEFT JOIN product_category ON product_category.id = products.category_id
    LEFT JOIN product_class ON product_class.id = products.class_id 
    WHERE product_no LIKE '".$prod."%'
    AND products.comp_id = '".$this->session->userdata('comp_id')."' 
    AND products.outlet_id IN (0, '".$this->session->userdata("outlet_id")."')")->result();
    return $query;
  }  

  public function search_item_name($prod){
    $query = $this->db->query("SELECT * from products
    LEFT JOIN product_type ON product_type.id = products.type_id
    LEFT JOIN product_brand ON product_brand.id = products.brand_id
    LEFT JOIN product_color ON product_color.id = products.color_id
    LEFT JOIN product_model ON product_model.id = products.model_id
    LEFT JOIN product_size ON product_size.id = products.size_id
    LEFT JOIN product_category ON product_category.id = products.category_id
    LEFT JOIN product_class ON product_class.id = products.class_id 
    WHERE product_name LIKE '".$prod."%'
    AND products.comp_id = '".$this->session->userdata('comp_id')."' 
    AND products.outlet_id IN (0, '".$this->session->userdata("outlet_id")."')")->result();
    return $query;
  } 

  public function get_product_transfer_hdr($trans_no){
  	$query = $this->db->query("SELECT
		    `inventory_hdr`.*
		    , `outlet`.`outlet_code`
		    , `outlet`.`outlet_name`
		FROM
		    `inventory_hdr`
		    LEFT JOIN `outlet` 
		        ON (`inventory_hdr`.`recipient_id` = `outlet`.`id`)
		WHERE (`inventory_hdr`.`inv_type` ='3'
		    AND `inventory_hdr`.`inv_no` ='".$trans_no."')")->result();
  	return $query;
  }

  public function get_product_transfer_dtl($id){
  	$query = $this->db->query("SELECT
	    	`products`.`product_no`
		    , `products`.`product_name`
		    , `product_unit`.`unit_code`
		    , `inventory_dtl`.`qty`
		    , `inventory_dtl`.`cost`
		    , `inventory_dtl`.`prod_id`
		    , `inventory_dtl`.`id` AS `dtl_id`
		FROM
		    `inventory_dtl`
		    INNER JOIN `products` 
		        ON (`inventory_dtl`.`prod_id` = `products`.`id`)
		    INNER JOIN `product_unit` 
		        ON (`products`.`stock_unit_id` = `product_unit`.`id`)
		    INNER JOIN `inventory_hdr` 
		        ON (`inventory_hdr`.`id` = `inventory_dtl`.`hdr_id`)
		WHERE (`inventory_hdr`.`id` ='".$id."')")->result();
  	return $query;
  }

  public function receive_list($term){
        
        if($term!=""){
            $str1 = "and (inv_no like '%".$term."%' or supp_name like '".$term."%' or cust_name like '".$term."%') or outlet_name like '".$term."%'";
        }else{
            $str1="";
        }
        $user_id = $this->session->userdata('user_id');
        $comp_id = $this->session->userdata('comp_id');
        $query = $this->db->query("SELECT *,
          (CASE WHEN (recipient_type = '1') THEN outlet.outlet_name 
          WHEN (recipient_type = '2') THEN customer.cust_name ELSE supplier.supp_name END) AS supplier_name2, 
          '0' AS total_qty,
          `inventory_hdr`.`id` AS hdr_id
          FROM inventory_hdr 
          LEFT JOIN outlet ON
          inventory_hdr.recipient_id = outlet.id
          LEFT JOIN supplier ON
          inventory_hdr.recipient_id = supplier.id
          LEFT JOIN customer ON
          inventory_hdr.recipient_id = customer.id
          INNER JOIN inventory_ref_type ON 
          `inventory_ref_type`.`id` = `inventory_hdr`.`tran_type`
            WHERE `inventory_hdr`.`status` = '1' AND `inventory_hdr`.`inv_type` = '1' AND `inventory_hdr`.`outlet_id` = '".$this->session->userdata("outlet_id")."' AND created_by = '".$user_id."' ".$str1." 
            ")->result();
        return $query;
  }

  public function search_field() {
    $hint = $this->input->get('term');
    $outlet_id = $this->session->userdata('outlet_id');
    $user_id = $this->session->userdata("user_id");
    // $query = $this->db->query("SELECT supplier_code AS term, inv_no as term FROM inventroy_hdr WHERE outlet_id = '".$outlet_id."' and (supplier_code like '%".$hint."%' or inv_no like '".$hint."%') ");
    $query = $this->db->query("SELECT 
      (CASE WHEN (recipient_type = '1') THEN outlet.outlet_name 
      WHEN (recipient_type = '2') THEN customer.cust_name ELSE supplier.supp_name END) AS term, 
      inv_no AS term 
      FROM inventory_hdr
      LEFT JOIN outlet ON
      inventory_hdr.recipient_id = outlet.id
      LEFT JOIN supplier ON
      inventory_hdr.recipient_id = supplier.id
      LEFT JOIN customer ON
      inventory_hdr.recipient_id = customer.id
      WHERE inventory_hdr.outlet_id = '".$outlet_id."' AND inventory_hdr.inv_type = '1' AND created_by = '".$user_id."' AND (supp_name LIKE '%".$hint."%' OR 
      outlet_name LIKE '%".$hint."%' OR cust_name LIKE '%".$hint."%' OR inv_no LIKE '".$hint."%')
      ");
    return $query;
  }

  public function get_receive_hdr($id,$type){
    $str="";
    $str2="";
    if($type == "1"){
      $str="LEFT JOIN outlet ON 
    `outlet`.`id` = `inventory_hdr`.`recipient_id`";
    $str2="`outlet`.outlet_name as supplier_name,`outlet`.outlet_code as supplier_code2";
    }elseif($type == "2"){
      $str="LEFT JOIN customer ON 
    `customer`.`id` = `inventory_hdr`.`recipient_id`";
     $str2="`customer`.cust_name as supplier_name,`customer`.cust_code as supplier_code2";
    }
    $query = $this->db->query("SELECT  
    `inventory_hdr`.*, 
    (CASE WHEN (`inventory_hdr`.`recipient_type` = '1') THEN `outlet`.outlet_name ELSE `customer`.cust_name END) AS supplier_name,
    (CASE WHEN (`inventory_hdr`.`recipient_type` = '1') THEN `outlet`.outlet_code ELSE `customer`.cust_code END) AS supplier_code2
    FROM inventory_hdr 
    LEFT JOIN outlet ON 
    `outlet`.`id` = `inventory_hdr`.`recipient_id`
    LEFT JOIN customer ON 
    `customer`.`id` = `inventory_hdr`.`recipient_id`
    WHERE `inventory_hdr`.`id` = '".$id."'")->result();
    return $query;
  }

  public function get_receive_dtl($id){
    $query = $this->db->query(" SELECT `inventory_dtl`.*,`products`.product_name,`product_unit`. unit_desc FROM inventory_dtl 
    LEFT JOIN products ON `products`.product_no = `inventory_dtl`.prod_id
    LEFT JOIN product_unit ON `product_unit`. id = `products`.stock_unit_id
     WHERE hdr_id = '".$id."' ");
    return $query;
  }
  // SAVING OF TRANSACTION
  public function save_hdr($receive_hdr) {
        $this->db->insert('inventory_hdr', $receive_hdr);
        return ($this->db->affected_rows() == 1) ? $this->db->insert_id() : false;
  }

  public function save_dtl($data,$hdr_id) {
        foreach($data as $key){
            $sub_dtl[] = array(
                    'hdr_id' =>  $hdr_id,
                    'prod_id'=>  $key['prod_id'],
                    'qty'    =>  $key['qty'],
                    'cost'   =>  $key['cost']
            );
        }
        $this->db->insert_batch('inventory_dtl',$sub_dtl);
        return ($this->db->affected_rows() > 0) ? true : false;
  }
   //UPDATING OF TRANSACTION
  public function edit_receive_hdr($receive_hdr,$hdr_id) {
        $this->db->where('id',$hdr_id);
        $this->db->update('inventory_hdr',$receive_hdr);
  }

  public function edit_receive_dtl($data,$hdr_id) {
        foreach($data as $key){
            $sub_dtl[] = array(
                    'receive_hdr_id' =>$hdr_id,
                    'product_id'   =>  $key['product_id'],
                    'qty'          =>  $key['qty'],
                    'cost'=>  $key['purchase_cost']
            );
        }
        $this->db->where('hdr_id',$hdr_id);
        $this->db->delete('inventory_dtl');
        $this->db->insert_batch('inventory_dtl',$sub_dtl);
        return ($this->db->affected_rows() > 0) ? true : false;
  }

  public function cancel_receive($id){
    $this->db->set("status", "0");
    $this->db->where("id", $id);
    $this->db->update("inventory_hdr");
    return ($this->db->affected_rows() > 0) ? true : false;
  }


}
