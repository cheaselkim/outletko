<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Supplier_model extends CI_Model {

    public function __construct(){
        parent::__construct();
            $this->load->database();
                $result = $this->login_model->check_session();
                if ($result != true){
                    redirect("/");
                }
    }

    public function supplier_type(){
        $query = $this->db->query("SELECT * FROM supplier_type")->result();
        return $query;
    }

    public function business_nature(){
        $query = $this->db->query("SELECT * FROM supplier_business_nature")->result();
        return $query;
    }

    public function get_classification(){
        $query = $this->db->query("SELECT * FROM supplier_classification")->result();
        return $query;
    }

    public function get_organization(){
        $query = $this->db->query("SELECT * FROM supplier_organization")->result();
        return $query;
    }

    public function outlet(){
        $data = array();
        $query = $this->db->query("SELECT all_access FROM users WHERE id = '".$this->session->userdata('user_id')."'")->row();

        if ($query->all_access == "1"){
            $result = $this->db->query("SELECT * FROM outlet WHERE comp_id = '".$this->session->userdata('comp_id')."'")->result();
        }else{
            $result = $this->db->query("SELECT
                `outlet`.`id`
                , `outlet`.`outlet_code`
                , `outlet`.`outlet_name`
            FROM
                `user_outlet`
                INNER JOIN `outlet` 
                    ON (`user_outlet`.`outlet_id` = `outlet`.`id`)
            WHERE (`user_outlet`.`user_id` = '".$this->session->userdata('user_id')."');")->result();
        }

        $data['all_access'] = $query->all_access;
        $data['result'] = $result;
        return $data;
    }

    public function search_supp_city($supp_city){
        $query = $this->db->query("SELECT 
            province_desc,
            city_desc,
             `city`.`province_id` AS prov_id,
             `city`.`id` AS city_id
            FROM province 
            INNER JOIN city ON
            `city`.`province_id` = `province`.`id`
            WHERE city_desc LIKE ?
            ORDER BY city_desc, province_desc
            LIMIT 10", array($supp_city.'%'))->result();
        return $query;
    }

    public function save_supplier($supplier_hdr) {
        $this->db->insert('supplier', $supplier_hdr);
        return ($this->db->affected_rows() > 0) ? true : false;
    }

    public function supplier_list($term){

        if($term!=""){
            $str3 = "and (supp_code like '%".$term."%' or supp_name like '%".$term."%')";
        }else{
            $str3="";
        }
        $comp_id = $this->session->userdata('comp_id');
        $query = $this->db->query("SELECT *,`supplier`.id as table_id FROM supplier 
            LEFT JOIN supplier_business_nature ON 
            `supplier_business_nature`.`id` = `supplier`.`business_nature` 
            LEFT JOIN supplier_classification ON 
            `supplier_classification`.`id` = `supplier`.`classification`
            LEFT JOIN supplier_organization ON 
            `supplier_organization`.`id` = `supplier`.`organization_form`
            LEFT JOIN status ON 
            `status`.`id` = `supplier`.`supp_status`  
            LEFT JOIN supplier_type ON 
            `supplier_type`.`id` = `supplier`.`supp_type`
            WHERE `supplier`.`comp_id` = '".$comp_id."'  ".$str3." ")->result();
        return $query;
    }

    public function get_supplier_dtl($id){
        $query = $this->db->query("SELECT * from supplier 
            left join city on `city`.id = `supplier`.supp_city_id  
            left join province on `province`.id = `supplier`.supp_province_id 
            where `supplier`.id = '".$id."' ")->result();
        return $query;
    }

    public function search_field() {
        $hint = $this->input->get('term');
        $comp_id = $this->session->userdata('comp_id');
        $query = $this->db->query("SELECT supp_code as term, supp_name as term FROM supplier where comp_id = '".$comp_id."' and (supp_code like '%".$hint."%' or supp_name like '%".$hint."%') ");
        return $query;
    }

    public function update_supplier($supplier_hdr,$supplier_id) {
        $this->db->where('id',$supplier_id);
        $this->db->update('supplier',$supplier_hdr);
    }

    public function delete_supplier($id){
        $query = $this->db->query("DELETE FROM supplier WHERE id = ?", array($id));
        return ($this->db->affected_rows() > 0) ? true : false;
    }

}
