<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Password_model extends CI_Model {

	public function __construct(){
		parent::__construct();
		$this->load->database();
	}

	public function find_email($email,$randomPass){
		$query = $this->db->query("SELECT id FROM users WHERE email = ?", array($email));
		$result = $query->row();

		$this->db->set("otp", "1");
		$this->db->set("password", password_hash($randomPass, PASSWORD_DEFAULT));
		$this->db->where("id", $result->id);
		$this->db->update("users");

		return $query->num_rows();
	}

	public function change_password($password){
		$this->db->set("otp", "0");
		$this->db->set("password", password_hash($password, PASSWORD_DEFAULT));
		$this->db->where("id", $this->session->userdata("user_id"));
		$this->db->update("users");
		return ($this->db->affected_rows() > 0) ? 1 : 0;
	}

}