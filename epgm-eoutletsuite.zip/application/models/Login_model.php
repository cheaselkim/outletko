<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login_model extends CI_Model {

  public function __construct(){
    parent::__construct();
    $this->load->database();
  }

  public function login(){
  	$uname = $this->security->xss_clean($this->input->post('uname'));
  	$pword = $this->security->xss_clean($this->input->post('pword'));
  	$user_array = "";

  	$query = $this->db->query("SELECT * FROM users WHERE status = '1' AND username = '".$uname."'")->result();
  	if (!empty($query)){
  		foreach ($query as $key => $value) {
  			if (password_verify($pword, $value->password)){
  				$user_array = array(
  								"user_id" => $value->id,
                  "account_id" => $value->account_id,
                  "cashier_id" => "0000",
                  "comp_id" => $value->comp_id,
  				  "user_uname" => $value->username,
  				  "user_fullname" => ($value->first_name." ".$value->last_name),
  				  "user_status" => $value->status,
                  "user_type" => $value->user_type,
                  "login" => 1,
                  "validated" => true
  							);
  			}else{
  				$user_array = "";
  			}
  		}
  		if (!empty($user_array)){
  			$this->session->set_userdata($user_array);
  			return true;
  		}else{
  			return false;
  		}
  	}else{
  		return false;
  	}
  }

  public function check_session(){
    $query = "";

    if (!empty($this->session->userdata("validated"))){
      $user_id = $this->session->userdata('user_id');
      $query = $this->db->query("SELECT * FROM users WHERE id = '".$user_id."'")->result();
    }else{
      $query = "";
    }


  	if (!empty($query)){
  		return true;
  	}else{
  		return false;
  	}

  }

  public function check_otp(){
    $query = $this->db->query("SELECT otp FROM users WHERE id = ? AND otp = ? ", array($this->session->userdata("user_id"), "1"))->num_rows();
    return $query;
  }


}
