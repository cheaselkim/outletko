<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product_model extends CI_Model {

    public function __construct(){
        parent::__construct();
            $this->load->database();
                $result = $this->login_model->check_session();
                if ($result != true){
                    redirect("/");
                }
    }

    public function product_type(){
        $query = $this->db->query("SELECT * FROM product_type
            WHERE comp_id = ? AND
            (CASE WHEN (outlet_id = '0') THEN outlet_id = '0' ELSE outlet_id = ? END)", array($this->session->userdata('comp_id'), $this->session->userdata('outlet_id')))->result();
        return $query;
    }

    public function product_brand(){
        $query = $this->db->query("SELECT * FROM product_brand
            WHERE comp_id = ? AND
            (CASE WHEN (outlet_id = '0') THEN outlet_id = '0' ELSE outlet_id = ? END)", array($this->session->userdata('comp_id'), $this->session->userdata('outlet_id')))->result();
        return $query;
    }

    public function product_model(){
        $query = $this->db->query("SELECT * FROM product_model
            WHERE comp_id = ? AND
            (CASE WHEN (outlet_id = '0') THEN outlet_id = '0' ELSE outlet_id = ? END)", array($this->session->userdata('comp_id'), $this->session->userdata('outlet_id')))->result();
        return $query;
    }

    public function product_category(){
        $query = $this->db->query("SELECT * FROM product_category
            WHERE comp_id = ? AND
            (CASE WHEN (outlet_id = '0') THEN outlet_id = '0' ELSE outlet_id = ? END)", array($this->session->userdata('comp_id'), $this->session->userdata('outlet_id')))->result();
        return $query;
    }

    public function product_color(){
        $query = $this->db->query("SELECT * FROM product_color
            WHERE comp_id = ? AND
            (CASE WHEN (outlet_id = '0') THEN outlet_id = '0' ELSE outlet_id = ? END)", array($this->session->userdata('comp_id'), $this->session->userdata('outlet_id')))->result();
        return $query;
    }

    public function product_size(){
        $query = $this->db->query("SELECT * FROM product_size
            WHERE comp_id = ? AND
            (CASE WHEN (outlet_id = '0') THEN outlet_id = '0' ELSE outlet_id = ? END)", array($this->session->userdata('comp_id'), $this->session->userdata('outlet_id')))->result();
        return $query;
    }

    public function product_class(){
        $query = $this->db->query("SELECT * FROM product_class
            WHERE comp_id = ? AND
            (CASE WHEN (outlet_id = '0') THEN outlet_id = '0' ELSE outlet_id = ? END)", array($this->session->userdata('comp_id'), $this->session->userdata('outlet_id')))->result();
        return $query;
    }

    public function product_unit(){
        $query = $this->db->query("SELECT * FROM product_unit
            WHERE comp_id = ? AND
            (CASE WHEN (outlet_id = '0') THEN outlet_id = '0' ELSE outlet_id = ? END)", array($this->session->userdata('comp_id'), $this->session->userdata('outlet_id')))->result();
        return $query;
    }

    public function product_tax(){
        $query = $this->db->query("SELECT * FROM vat")->result();
        return $query;
    }

    public function outlet(){
        $data = array();
        $query = $this->db->query("SELECT all_access FROM users WHERE id = '".$this->session->userdata('user_id')."'")->row();

        if ($query->all_access == "1"){
            $result = $this->db->query("SELECT * FROM outlet WHERE comp_id = '".$this->session->userdata('comp_id')."'")->result();
        }else{
            $result = $this->db->query("SELECT
                `outlet`.`id`
                , `outlet`.`outlet_code`
                , `outlet`.`outlet_name`
            FROM
                `user_outlet`
                INNER JOIN `outlet` 
                    ON (`user_outlet`.`outlet_id` = `outlet`.`id`)
            WHERE (`user_outlet`.`user_id` = '".$this->session->userdata('user_id')."');")->result();
        }

        $data['all_access'] = $query->all_access;
        $data['result'] = $result;
        return $data;
    }

    public function save_product($product_hdr) {
        $this->db->insert('products', $product_hdr);
        return ($this->db->affected_rows() > 0) ? true : false;
    }

    public function upload_image_file($data, $product_no){
        $status = "";
        $this->db->trans_begin();

        $this->db->where('product_no',$this->input->post('product_no'));
        $this->db->update('products',$data);     

        if($this->db->trans_status() === FALSE){
            $db_error = "";
            $db_error = $this->db->error();
            $this->db->trans_rollback();
           $status = $db_error;
        }else{  
            $this->db->trans_commit();
            $status = "success";
        }   

        return $status;
    }

    public function product_list($type,$term){
        if($type!=""){
            $str1 = "AND product_type = '".$type."'";
        }else{
            $str1="";
        }
        if($term!=""){
            $str3 = "AND (product_no LIKE '%".$term."%' or product_name LIKE '%".$term."%')";
        }else{
            $str3="";
        }


        $comp_id = $this->session->userdata('comp_id');
        $query = $this->db->query("SELECT products.*, `product_type`.`prod_type_desc` FROM products 
            LEFT JOIN product_type ON 
            `products`.type_id = `product_type`.id 
            WHERE `products`.comp_id = '".$comp_id."' 
            AND `products`.outlet_id IN ('0', '".$this->session->userdata('outlet_id')."') 
            ".$str1."  ".$str3." ")->result();
        return $query;
    }

    public function search_field() {
        $hint = $this->input->get('term');
        $comp_id = $this->session->userdata('comp_id');
        $query = $this->db->query("SELECT product_no as term, product_name as term FROM products where comp_id = '".$comp_id."' and (product_no like '%".$hint."%' or product_name like '%".$hint."%') ");
        return $query;
    }

    public function update_product($product_no,$product_hdr) {
        $this->db->where('product_no',$product_no);
        $this->db->update('products',$product_hdr);
        return ($this->db->affected_rows() > 0) ? true : false;
    }

    public function get_product_dtl($id){
    $query = $this->db->query("SELECT * from products where id = '".$id."' ")->result();
    return $query;
    }

    public function delete_product($id){
        $this->db->query("DELETE FROM products WHERE id = ?", array($id));
        return ($this->db->affected_rows() > 0) ? true : false;
    }


}
