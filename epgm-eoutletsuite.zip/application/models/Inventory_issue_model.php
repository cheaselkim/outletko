<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Inventory_issue_model extends CI_Model {

  public function __construct(){
    parent::__construct();
    $this->load->database();
      $result = $this->login_model->check_session();
      if ($result != true){
        redirect("/");
      }
  }

//AUTOCOMPLETE FOR RECIPIENT
  public function search_recipient_code($recipient){
    $query = $this->db->query("SELECT outlet_code AS CODE, id as ID,outlet_name AS NAME FROM outlet where outlet_code like '%".$recipient."%'")->result();
    return $query;
  }

  public function search_recipient_name($recipient){
    $query = $this->db->query("SELECT outlet_code AS CODE, id as ID,outlet_name AS NAME FROM outlet where outlet_name like '%".$recipient."%'")->result();
    return $query;
  }

  //AUTOCOMPLETE FOR PRODUCT
  public function search_item_code($prod){
    $query = $this->db->query("SELECT * FROM products 
    LEFT JOIN product_type ON product_type.id = products.type_id
    LEFT JOIN product_brand ON product_brand.id = products.brand_id
    LEFT JOIN product_color ON product_color.id = products.color_id
    LEFT JOIN product_model ON product_model.id = products.model_id
    LEFT JOIN product_size ON product_size.id = products.size_id
    LEFT JOIN product_category ON product_category.id = products.category_id
    LEFT JOIN product_class ON product_class.id = products.class_id where product_no like '%".$prod."%'")->result();
    return $query;
  }  

  public function search_item_name($prod){
    $query = $this->db->query("SELECT * from products
    LEFT JOIN product_type ON product_type.id = products.type_id
    LEFT JOIN product_brand ON product_brand.id = products.brand_id
    LEFT JOIN product_color ON product_color.id = products.color_id
    LEFT JOIN product_model ON product_model.id = products.model_id
    LEFT JOIN product_size ON product_size.id = products.size_id
    LEFT JOIN product_category ON product_category.id = products.category_id
    LEFT JOIN product_class ON product_class.id = products.class_id where product_name like '%".$prod."%'")->result();
    return $query;
  } 

  public function issue_list($term){
        
        if($term!=""){
            $str1 = "and (inv_no like '%".$term."%' or recipient_id like '%".$term."%')";
        }else{
            $str1="";
        }
        $user_id = $this->session->userdata('user_id');
        $comp_id = $this->session->userdata('comp_id');
        $query = $this->db->query("SELECT inventory_hdr.*, outlet_name AS recipient, '0' AS total_qty FROM inventory_hdr 
            INNER JOIN outlet ON `outlet`.id = `inventory_hdr`.recipient_id
            WHERE `inventory_hdr`.`inv_type` = '2' AND created_by = '".$user_id."' ".$str1." ")->result();
        return $query;
  }

  public function search_field() {
        $hint = $this->input->get('term');
        $outlet_id = $this->session->userdata('outlet_id');
        $query = $this->db->query("SELECT recipient_id AS term, inv_no AS term FROM inventory_hdr WHERE `inventory_hdr`.`inv_type` = '2' AND outlet_id = '".$outlet_id."' and (recipient_id like '%".$hint."%' or inv_no like '%".$hint."%') ");
        return $query;
  }

  // RETREIVING OF TRANSACTION INFORMATION
  public function get_issue_hdr($id){
    $query = $this->db->query("SELECT inventory_hdr.*, `outlet`.outlet_name AS recipient_name,`outlet`.outlet_code AS recipient_code
    FROM inventory_hdr INNER JOIN outlet ON 
    `outlet`.id = `inventory_hdr`.recipient_id
    WHERE `inventory_hdr`.id = '".$id."' ")->result();
    return $query;
  }

  public function get_issue_dtl($id){
    $query = $this->db->query(" SELECT `inventory_dtl`.*,`products`.product_name,`product_unit`. unit_desc FROM inventory_dtl 
    LEFT JOIN products ON `products`.product_no = `inventory_dtl`.prod_id
    LEFT JOIN product_unit ON `product_unit`. id = `products`.stock_unit_id
     WHERE hdr_id = '".$id."' ");
    return $query;
  }

  public function get_outlet_name($id){
    $query = $this->db->query("SELECT outlet_name FROM outlet WHERE  id = '".$this->session->userdata('outlet_id')."' ")->result();
    return $query;
  }


  // SAVING OF TRANSACTION
  public function save_hdr($issue_hdr) {
        $this->db->insert('inventory_hdr', $issue_hdr);
        return ($this->db->affected_rows() == 1) ? $this->db->insert_id() : false;
  }

  public function save_dtl($data,$hdr_id) {
        foreach($data as $key){
            $sub_dtl[] = array(
                    'hdr_id' =>  $hdr_id,
                    'prod_id'   =>  $key['prod_id'],
                    'qty'          =>  $key['qty']
            );
        }
        $this->db->insert_batch('issue_dtl',$sub_dtl);
        return ($this->db->affected_rows() > 0) ? true : false;
  }

  //  UPDATING OF TRANSACTION INFORMATION
  public function edit_issue_hdr($issue_hdr,$hdr_id) {
        $this->db->where('id',$hdr_id);
        $this->db->update('inventory_hdr',$issue_hdr);
  }

  public function edit_issue_dtl($data,$hdr_id) {
        foreach($data as $key){
            $sub_dtl[] = array(
                    'hdr_id' =>  $hdr_id,
                    'prod_id'=>  $key['product_id'],
                    'qty'    =>  $key['qty']
            );
        }
        $this->db->where('issue_hdr_id',$hdr_id);
        $this->db->delete('issue_dtl');
        $this->db->insert_batch('issue_dtl',$sub_dtl);
        return ($this->db->affected_rows() > 0) ? true : false;
  }

  //  DELETING OF TRANSACTION
	public function cancel_issue($id){
		$this->db->set("status", "0");
		$this->db->where("id", $id);
		$this->db->update("inventory_hdr");
		return ($this->db->affected_rows() > 0) ? true : false;
	}

}
