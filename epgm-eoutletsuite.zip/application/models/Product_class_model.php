<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product_class_model extends CI_Model {

    public function __construct(){
        parent::__construct();
            $this->load->database();
                $result = $this->login_model->check_session();
                if ($result != true){
                    redirect("/");
                }
    }

    public function company(){
        $result = $this->db->query("SELECT * FROM company WHERE id = ?", array($this->session->userdata("comp_id")))->row();
        return $result->comp_name;
    }

    public function outlet(){
    	$result = $this->db->query("SELECT * FROM outlet WHERE comp_id = ?", array($this->session->userdata("comp_id")))->result();
    	return $result;
    }

    public function insert_product_class($insert_array){
        $this->db->insert("product_class", $insert_array);
        return ($this->db->affected_rows() > 0) ? true : false;
    }

    public function query_product_class($class_desc,  $outlet){
        $class_desc_query = "";
        $outlet_query = "";

        if ($class_desc != ""){
            $class_desc_query = "AND class_desc LIKE %'".$class_desc."'%";
        }

        if ($outlet != 0){
            $outlet_query = "AND `product_class`.`outlet_id` = '".$outlet."'";
        }

        $query = $this->db->query("SELECT product_class.*, 
            (CASE WHEN (`product_class`.`outlet_id` = '0') THEN 'ALL' ELSE `outlet`.`outlet_code` END) AS outlet_desc
            FROM product_class
            LEFT JOIN outlet ON 
            `product_class`.`outlet_id` = `outlet`.`id`
            WHERE `product_class`.`comp_id` = '".$this->session->userdata("comp_id")."' ".$class_desc_query." ".$outlet_query." ")->result(); 
        return $query;
    }

    public function delete_prod_class($id){
        $query = $this->db->query("DELETE FROM product_class WHERE id = ?", array($id));
        return ($this->db->affected_rows() > 0) ? true : false;
    }

    public function get_transaction($id){
        $result = $this->db->query("SELECT * FROM product_class WHERE id = ?", array($id))->row();
        return $result;
    }

    public function update_product_class($update_array, $id){
        $this->db->where("id", $id);
        $this->db->update("product_class", $update_array);
        return ($this->db->affected_rows() > 0) ? true : false;
    }

}