<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model {

	public function __construct(){
		parent::__construct();
		$this->load->database();
	}

	public function check_username($username){
		$query = $this->db->query("SELECT * FROM users WHERE username = ? AND id != ?", array($username, $this->session->userdata("user_id")));
		return $query->num_rows();
	}

	public function check_password(){
		$query = $this->db->query("SELECT password FROM users WHERE id = ?", array($this->session->userdata("user_id")))->row();
        return $query->password;
	}

	public function update_user($password, $username){
		$this->db->set("username", $username);
		$this->db->set("password", password_hash($password, PASSWORD_DEFAULT));
		$this->db->where("id", $this->session->userdata("user_id"));
		$this->db->update("users");
		return ($this->db->affected_rows() > 0) ? 1 : 0;
	}

	public function get_user_owner(){
		$query = $this->db->query("SELECT
		    `account_application`.*
		    , `currency`.`curr_code`
		    , `business_type`.`desc` AS `business_desc`
		    , `subscription_type`.`desc` AS `subscription_desc`
		    , `status`.`status`
		FROM
		    `eoutletsuite`.`account_application`
		    INNER JOIN `eoutletsuite`.`currency` 
		        ON (`account_application`.`currency` = `currency`.`id`)
		    INNER JOIN `eoutletsuite`.`business_type` 
		        ON (`account_application`.`business_type` = `business_type`.`id`)
		    INNER JOIN `eoutletsuite`.`subscription_type` 
		        ON (`account_application`.`subscription_type` = `subscription_type`.`id`)
		    INNER JOIN `eoutletsuite`.`status` 
		        ON (`account_application`.`account_status` = `status`.`id`)
		        WHERE `account_application`.`id` = ?", array($this->session->userdata("comp_id")))->result();
		return $query;
	}

	public function update_owner($data_owner, $data_user){
		$data_owner['date_update_user'] = date("Y-m-d H:i:s");
		$this->db->where("id", $this->session->userdata("comp_id"));
		$this->db->update("account_application", $data_owner);

		$this->db->where("id", $this->session->userdata("user_id"));
		$this->db->update("users", $data_user);

		return ($this->db->affected_rows() > 0) ? 1 : 0;
	}

	public function get_user_account(){
		$query = $this->db->query("SELECT
		    `sales_force`.*
		    , `sales_force_type`.`desc` AS `sales_force_type`
		    , `status`.`status`
		    , `outlet`.`outlet_code`
		    , `outlet`.`outlet_name`
		FROM
		    `eoutletsuite`.`sales_force`
		    INNER JOIN `eoutletsuite`.`sales_force_type` 
		        ON (`sales_force`.`type` = `sales_force_type`.`id`)
		    INNER JOIN `eoutletsuite`.`status` 
		        ON (`sales_force`.`active` = `status`.`id`)
		    INNER JOIN `eoutletsuite`.`outlet` 
        		ON (`sales_force`.`outlet` = `outlet`.`id`)
		WHERE (`sales_force`.`user_id` = ?)", array($this->session->userdata("user_id")))->result();
		return $query;
	}

	public function update_user_account($data_sales, $data_user){
		$data_owner['date_update_user'] = date("Y-m-d H:i:s");
		$this->db->where("user_id", $this->session->userdata("user_id"));
		$this->db->update("sales_force", $data_sales);

		$this->db->where("id", $this->session->userdata("user_id"));
		$this->db->update("users", $data_user);

		return ($this->db->affected_rows() > 0) ? 1 : 0;
	}



}
