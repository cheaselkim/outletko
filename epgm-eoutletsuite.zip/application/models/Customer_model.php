<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Customer_model extends CI_Model {

    public function __construct(){
        parent::__construct();
            $this->load->database();
                $result = $this->login_model->check_session();
                if ($result != true){
                    redirect("/");
                }
    }

    public function customer_type(){
        $query = $this->db->query("SELECT * FROM customer_type")->result();
        return $query;
    }

    public function outlet(){
        $data = array();
        $query = $this->db->query("SELECT all_access FROM users WHERE id = '".$this->session->userdata('user_id')."'")->row();

        if ($query->all_access == "1"){
            $result = $this->db->query("SELECT * FROM outlet WHERE comp_id = '".$this->session->userdata('comp_id')."'")->result();
        }else{
            $result = $this->db->query("SELECT
                `outlet`.`id`
                , `outlet`.`outlet_code`
                , `outlet`.`outlet_name`
            FROM
                `user_outlet`
                INNER JOIN `outlet` 
                    ON (`user_outlet`.`outlet_id` = `outlet`.`id`)
            WHERE (`user_outlet`.`user_id` = '".$this->session->userdata('user_id')."');")->result();
        }

        $data['all_access'] = $query->all_access;
        $data['result'] = $result;
        return $data;
    }

    public function search_cust_city($cust_city){
        $query = $this->db->query("SELECT 
            province_desc,
            city_desc,
             `city`.`province_id` AS prov_id,
             `city`.`id` AS city_id
            FROM province 
            INNER JOIN city ON
            `city`.`province_id` = `province`.`id`
            WHERE city_desc LIKE ?
            ORDER BY city_desc, province_desc
            LIMIT 10", array($cust_city.'%'))->result();
        return $query;
    }

    public function save_customer($customer_hdr) {
        $this->db->insert('customer', $customer_hdr);
        return ($this->db->affected_rows() > 0) ? true : false;
    }

    public function customer_list($term){
        if($term!=""){
            $str3 = "and (outlet_code like '%".$term."%' or outlet_name like '%".$term."%')";
        }else{
            $str3="";
        }
        $comp_id = $this->session->userdata('comp_id');
        $query = $this->db->query("SELECT *,`customer`.id as table_id FROM customer 
            LEFT JOIN customer_type ON 
            `customer_type`.`id` = `customer`.`cust_type`
            WHERE `customer`.`comp_id` = '".$comp_id."' 
            AND `customer`.`outlet_id` IN ('0', '".$this->session->userdata('outlet_id')."')
            ".$str3." ")->result();
        return $query;
    }

    public function get_customer_dtl($id){
        $query = $this->db->query("SELECT * from customer left join city on `city`.id = `customer`.cust_city_id  left join province on `province`.id = `customer`.cust_province_id where `customer`.id = '".$id."' ")->result();
        return $query;
    }

    public function search_field() {
        $hint = $this->input->get('term');
        $comp_id = $this->session->userdata('comp_id');
        $query = $this->db->query("SELECT cust_no as term, cust_name as term FROM customer where comp_id = '".$comp_id."' and (cust_no like '%".$hint."%' or cust_name like '%".$hint."%') ");
        return $query;
    }

    public function update_customer($customer_hdr,$customer_id) {
        $this->db->where('id',$customer_id);
        $this->db->update('customer',$customer_hdr);
        return ($this->db->affected_rows() > 0) ? true : false;
    }

    public function delete_customer($id){
        $query = $this->db->query("DELETE FROM customer WHERE id = ?", array($id));
        return ($this->db->affected_rows() > 0) ? true : false;
    }


 
}
