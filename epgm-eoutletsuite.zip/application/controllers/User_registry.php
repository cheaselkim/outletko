<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_registry extends CI_Controller {

	public function __construct(){
	    parent::__construct();
	    	$this->load->model("user_registry_model");
	    	$this->load->model("password_model");
			$result = $this->login_model->check_session();
			if ($result != true){
				redirect("/");
			}
	}

	public function business_type(){
		$result = $this->user_registry_model->business_type();
		echo json_encode($result);
	}

	public function subscription_type(){
		$result = $this->user_registry_model->subscription_type();
		echo json_encode($result);
	}

	public function currency(){
		$result = $this->user_registry_model->currency();
		echo json_encode($result);
	}

	public function randomString($length = 6) {
		$str = "";
		$characters = array_merge(range('A','Z'), range('a','z'), range('0','9'));
		$max = count($characters) - 1;
		for ($i = 0; $i < $length; $i++) {
			$rand = mt_rand(0, $max);
			$str .= $characters[$rand];
		}
		return $str;
	}

	public function insert_account(){
		$user_app_result = 0;
		$users_result = 0;
		$email_result = 0;

		$user_app = array(
			"last_name" => strtoupper($this->input->post("last_name")),
			"middle_name" => strtoupper($this->input->post("middle_name")),
			"first_name" => strtoupper($this->input->post("first_name")),
			"email" => $this->input->post("email"),
			"mobile_no" => $this->input->post("mobile_no"),
			"telephone_no" => $this->input->post("phone_no"),
			"address" => $this->input->post("address"),
			"account_id" => $this->input->post("account_id"),
			"account_name" => strtoupper($this->input->post("account_name")),
			"account_status" => $this->input->post("account_status"),
			"business_type" => $this->input->post("business_type"),
			"subscription_type" => $this->input->post("subscription_type"),
			"subscription_date" => $this->input->post("subscription_date"),
			"renewal_date" => $this->input->post("renewal_date"),
			"recruited_by" => $this->input->post("recruited_by"),
			"outlet_no" => $this->input->post("outlet"),
			"vat" => $this->input->post("vat"),
			"currency" => $this->input->post("currency")
			);

		$user_app_result = $this->user_registry_model->insert_account($user_app);

		$users = array(
			"comp_id" => $user_app_result,
			"account_id" => $user_app_result,
			"account_type" => "1",
			"first_name" => strtoupper($this->input->post("first_name")),
			"middle_name" => strtoupper($this->input->post("middle_name")),
			"last_name" => strtoupper($this->input->post("last_name")),
			"username" => $this->input->post("account_id"),
			"email" => $this->input->post("email"),
			"user_type" => "2",
			"all_access" => "1"
		);

		$users_result = $this->user_registry_model->insert_users($users);
		$email_result = $this->send_email($this->input->post("email"), $this->input->post("account_id"));

		echo json_encode(array("user_app" => $user_app_result, "users" => $users_result, "email" => $email_result));

	}

	public function send_email($email, $account_id){
		$this->load->library("email");
		$status = 0;
		$randomString = $this->randomString();
		$result = $this->password_model->find_email($email, $randomString);

		if ($result > 0){
	        $config = array(
	                    'protocol' => 'smtp',
	                    'smtp_host' => 'ssl://smtp.gmail.com',
	                    'smtp_port' => 465,
	                    'smtp_user' => 'epgmcompany@gmail.com',
	                    'smtp_pass' => 'epgmcompany101'
	                );


	        $this->email->initialize($config)
	                    ->set_newline("\r\n")
	                    ->from('noreply@epgmcompany.com', 'eOutletSuite Application')
	                    ->to($email)
	                    ->subject('eOutletSuite Account Register')
	                    ->message("	Your Account ID : ". $account_id . "<br>".
	                    			"Your Password : ".$randomString);

	        if($this->email->send()) {
	        	$status = 1;
	        }else {
	        	$status = $this->email->print_debugger();
	        	}
	    }else{
	    	$status = 0;
	    }

	    return $status;
	}	

	public function account_id(){
		$data = array();
		$data['year'] = date("y");
		$data['account_id'] = $this->user_registry_model->account_id();
		echo json_encode($data);
	}



}