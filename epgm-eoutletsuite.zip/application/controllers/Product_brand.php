<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product_brand extends CI_Controller {

	public function __construct(){
	    parent::__construct();
	    	$this->load->model("product_brand_model");
	    	$this->load->helper("product_brand");
			$result = $this->login_model->check_session();
			if ($result != true){
				redirect("/");
			}
	}

	public function company(){
		$result = $this->product_brand_model->company();
		echo json_encode($result);
	}

	public function outlet(){
		$result = $this->product_brand_model->outlet();
		echo json_encode($result);
	}

	public function insert_product_brand(){
		$insert_array = array(
				"comp_id" => $this->session->userdata("comp_id"),
				"outlet_id" => $this->input->post("outlet"),
				"brand_desc" => $this->input->post("brand_desc")
				);

		$result = $this->product_brand_model->insert_product_brand($insert_array);
		echo json_encode($result);
	}

	public function query_product_brand(){
		$app_func = $this->input->post("app_func");
		$brand_desc = $this->input->post("brand_desc");
		$outlet = $this->input->post("outlet");
		$result = $this->product_brand_model->query_product_brand($brand_desc, $outlet);
		$tbl_result = tbl_query($result,$app_func);
		echo json_encode($tbl_result);
	}

	public function delete_prod_brand(){
		$id = $this->input->post("id");
		$result = $this->product_brand_model->delete_prod_brand($id);
		echo json_encode($result);
	}

	public function get_transaction(){
		$id = $this->input->post("id");
		$result = $this->product_brand_model->get_transaction($id);
		$data = array();
		$data['outlet'] = $result->outlet_id;
		$data['brand_desc'] = $result->brand_desc;
		echo json_encode($data);
	}

	public function update_product_brand(){
		$update_array = array(
				"outlet_id" => $this->input->post("outlet"),
				"brand_desc" => $this->input->post("brand_desc")
				);

		$result = $this->product_brand_model->update_product_brand($update_array, $this->input->post("id"));
		echo json_encode($result);

	}

}
