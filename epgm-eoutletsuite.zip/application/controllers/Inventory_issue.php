<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Inventory_issue extends CI_Controller {

	public function __construct(){
	    parent::__construct();
	      	$this->load->model("inventory_issue_model");
	      	$this->load->helper("inventory_issue");
			$result = $this->login_model->check_session();
			if ($result != true){
				redirect("/");
			}
	}

	public function search_recipient($type){
		$recipient = $this->input->post("recipient");
		$data = array();
		$data['response'] = "false";
		if ($type == "1"){
			$result = $this->inventory_issue_model->search_recipient_code($recipient);
			if (!empty($result)){
				$data['response'] = "true";
				foreach ($result as $key => $value) {
					$data['result'][] = array("label" => $value->CODE, "recipient_name" => $value->NAME, "id" => $value->ID);
				}
			}
		}else{
			$result = $this->inventory_issue_model->search_recipient_name($recipient);
			if (!empty($result)){
				$data['response'] = "true";
				foreach ($result as $key => $value) {
					$data['result'][] = array("label" => $value->NAME, "recipient_code" => $value->CODE, "id" => $value->ID);
				}
			}
		}
		echo json_encode($data);
	}

	public function search_field() {
        $result = $this->inventory_issue_model->search_field();
        $list = array();
        foreach ($result->result() as $row) {
            $list[] = array(
                'term' => $row->term
            );
        }
        $this->output->set_content_type('application/json');
        echo json_encode($list);
    }

	public function search_item($type){
		$prod = $this->input->post("prod");
		$data = array();
		$data['response'] = "false";
		if ($type == "1"){
			$result = $this->inventory_issue_model->search_item_code($prod);
			if (!empty($result)){
				$data['response'] = "true";
				foreach ($result as $key => $value) {
					$data['result'][] = array("label" => $value->product_no, 
											"prod_name" => $value->product_name,
											"prod_specs" => $value->product_specs,
											"prod_type" => $value->prod_type_desc,
											"brand" => $value->brand_desc,
											"model" => $value->model_desc,
											"color" => $value->color_desc,
											"class" => $value->class_desc,
											"category" => $value->category_desc,
											"size" => $value->size_desc,
											"unit" => $value->stock_unit_id,
											"image" => unserialize($value->image_loc));
				}
			}
		}else{
			$result = $this->inventory_issue_model->search_item_name($prod);
			if (!empty($result)){
				$data['response'] = "true";
				foreach ($result as $key => $value) {
					$data['result'][] = array("label" => $value->product_name, 
											"prod_no" => $value->product_no,
											"prod_specs" => $value->product_specs,
											"prod_type" => $value->prod_type_desc,
											"brand" => $value->brand_desc,
											"model" => $value->model_desc,
											"color" => $value->color_desc,
											"class" => $value->class_desc,
											"category" => $value->category_desc,
											"size" => $value->size_desc,
											"unit" => $value->stock_unit_id,
											"image" => unserialize($value->image_loc));
				}
			}
		}
		echo json_encode($data);
	}

	public function issue_list(){
    	$term = $this->input->post('term');
    	$function = $this->input->post("app_func");
		$result = $this->inventory_issue_model->issue_list($term);	
		$table_issue = table_issue($result,$function);
		echo json_encode($table_issue);
	}

	public function save_data() {
        $issue_hdr = $this->input->post('issue_hdr');
        $issue_dtl = $this->input->post('issue_dtl');

        $issue_hdr['outlet_id'] =  $this->session->userdata('outlet_id');
        $issue_hdr['created_by'] =  $this->session->userdata('user_id');

        // $hdr_id = $this->inventory_issue_model->save_hdr($issue_hdr);
        // $query = $this->inventory_issue_model->save_dtl($issue_dtl,$hdr_id);

        var_dump($issue_dtl);
        $query = true;

        if($query == true){
            $status = "success";
        }else{
            $status = "failed";
        }
        echo json_encode(array('status' => $status));       
    }

    public function update_data() {
		$hdr_id = $this->input->post('hdr_id');
        $issue_hdr = $this->input->post('issue_hdr');
        $issue_dtl = $this->input->post('issue_dtl');

        $this->inventory_issue_model->edit_issue_hdr($issue_hdr,$hdr_id);
        $query = $this->inventory_issue_model->edit_issue_dtl($issue_dtl,$hdr_id);
        if($query == true){
            $status = "success";
        }else{
            $status = "failed";
        }
        // $this->output->set_content_type('application/json');
        echo json_encode(array('status' => $status));       
    }

    public function get_issue(){
    	$id = $this->input->post('id');
    	$hdr_data = array();
    	$dtl_data = array();
    	$hdr_id = "";
    	$result = $this->inventory_issue_model->get_issue_hdr($id);
		$result2 = $this->inventory_issue_model->get_issue_dtl($id);
		//var_dump($result2);
		foreach ($result2->result() as $row) { 
			$dtl_data[] = array(
					'product_id' => $row->prod_id,
					'product_name' => $row->product_name,
					'unit' => $row->unit_desc,
					'qty' => $row->qty
				); 
		}
		echo json_encode(array('trans_hdr' => $result,'trans_dtl' => $dtl_data));
		// echo json_encode($id);
    }

    public function delete_issue(){
        $id = $this->input->post("id");
        $result = $this->inventory_issue_model->delete_issue($id);
        echo json_encode($result);        
    }

    public function get_outlet_name(){
    	$id = $this->input->post('id');
    	$result = $this->inventory_issue_model->get_outlet_name($id);
    	echo json_encode($result);
    }

}
