<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Menu extends CI_Controller {

	  public function __construct(){
	    parent::__construct();
	    $this->load->model("header_model");
	    $this->load->model("menu_model");
		$result = $this->login_model->check_session();
		if ($result != true){
			redirect("/");
		}
	  }

	public function menu($menu, $sub_module, $function){	

		$all_access = $this->header_model->all_access();
		if ($all_access == "1"){
			$result = 1;
		}else{
			$result = $this->menu_model->check_menu($menu, $sub_module, $function);
		}
		
		if ($result > 0){
			$data['function'] = $function;
			$data['sub_module'] = $sub_module;
			$data['user_type'] = $this->session->userdata('user_type');
			$data['menu_module'] = $menu;
			$data['account_id'] = $this->session->userdata("account_id");
			$data['edit'] = 0;
			$this->template->load($menu, $data);						
		}else{
			redirect("/logout");
		}

	}

	public function edit_menu($menu, $sub_module, $function, $id){
		$all_access = $this->header_model->all_access();

		if ($all_access == "1"){
			$result = 1;
		}else{
			$result = $this->menu_model->check_menu($menu, $sub_module, $function);
		}
				
		if ($result > 0){
			$data['function'] = $function;
			$data['sub_module'] = $sub_module;
			$data['user_type'] = $this->session->userdata('user_type');
			$data['menu_module'] = $menu;
			$data['edit'] = 1;
			$data['trans_id'] = $id;
			$data['account_id'] = $this->session->userdata("account_id");
			$this->template->load($menu, $data);						
		}else{
			redirect("/logout");
		}

	}


}
