<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Report extends CI_Controller {

	public function __construct(){
	    parent::__construct();
	    $this->load->helper("report");
	    $this->load->model("Report_model");
		$result = $this->login_model->check_session();
		if ($result != true){
			redirect("/");
		}
	}

	public function report_type (){
		$result = $this->Report_model->report_type();
		echo json_encode($result);
	}

	public function reports(){
		$report_type = $this->input->post('report_type');
		$result = $this->Report_model->reports($report_type);
		echo json_encode($result);
	}

	public function outlet(){
		$query = $this->Report_model->outlet();
		echo json_encode($query);
	}

	public function report(){
		$report = $this->input->post("report");
		$fdate = $this->input->post("fdate");
		$tdate = $this->input->post("tdate");
		$outlet = $this->input->post("outlet");
		$tbl = "";
		$result = "";

		if ($report == "1"){
			$result = $this->Report_model->sales_summary($fdate, $tdate, $outlet);
			$tbl = report_17($result);
		}else if ($report == "2"){
			$result = $this->Report_model->sales_transaction($fdate, $tdate, $outlet,"1");
			$tbl = sales_transaction($result);
		}else if ($report == "3"){
			$result = $this->Report_model->sales_transaction($fdate, $tdate, $outlet,"0");
			$tbl = sales_transaction($result);
		}else if ($report == "4"){
			$result = $this->Report_model->sales_transaction($fdate, $tdate, $outlet,"");
			$tbl = sales_transaction($result);
		}else if ($report == "5"){
		}else if ($report == "6"){
		}else if ($report == "7"){
			$result = $this->Report_model->sales_per_product($fdate, $tdate, $outlet, "1");
			$tbl = sales_per_product($result);
		}else if ($report == "8"){
			$result = $this->Report_model->sales_per_agent($fdate, $tdate, $outlet);
			$tbl = sales_per_agent($result);
		}else if ($report == "9"){
			$result = $this->Report_model->inventory_transaction($fdate, $tdate, $outlet, "1");
			$tbl = inventory_transaction($result);
		}else if ($report == "10"){
			$result = $this->Report_model->inventory_transaction($fdate, $tdate, $outlet, "2");
			$tbl = inventory_transaction($result);
		}else if ($report == "11"){
			$result = $this->Report_model->inventory_transaction($fdate, $tdate, $outlet, "3");
			$tbl = inventory_transaction($result);
		}else if ($report == "12"){
			$result = $this->Report_model->inventory_transaction($fdate, $tdate, $outlet, "4");
			$tbl = inventory_transaction($result);
		}

		echo json_encode($tbl);
	}


}