<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Inventory_receive extends CI_Controller {

	public function __construct(){
	    parent::__construct();
	      	$this->load->model("inventory_receive_model");
	      	$this->load->helper("inventory_receive");
			$result = $this->login_model->check_session();
			if ($result != true){
				redirect("/");
			}
	}

	public function search_outlet($type){
		$outlet = $this->input->post("outlet");
		$data = array();
		$data['response'] = "false";

		if ($type == "1"){
			$result = $this->inventory_receive_model->search_outlet($outlet);
			if (!empty($result)){
				$data['response'] = "true";
				foreach ($result as $key => $value) {
					$data['result'][] = array("label" => $value->CODE, "outlet_name" => $value->NAME, "type1" => $value->TYPE , "id" => $value->ID);
				}
			}
		}else{
			$result = $this->inventory_receive_model->search_name($outlet);
			if (!empty($result)){
				$data['response'] = "true";
				foreach ($result as $key => $value) {
					$data['result'][] = array("label" => $value->NAME, "outlet_code" => $value->CODE, "type1" => $value->TYPE, "id" => $value->ID);
				}
			}
		}
		echo json_encode($data);
	}

	public function search_field() {
        $result = $this->inventory_receive_model->search_field();
        $list = array();
        foreach ($result->result() as $row) {
            $list[] = array(
                'term' => $row->term
            );
        }
        $this->output->set_content_type('application/json');
        echo json_encode($list);
    }

	public function search_item($type){
		$prod = $this->input->post("prod");
		$data = array();
		$data['response'] = "false";

		if ($type == "1"){
			$result = $this->inventory_receive_model->search_item_code($prod);
			if (!empty($result)){
				$data['response'] = "true";
				foreach ($result as $key => $value) {
					$data['result'][] = array("label" => $value->product_no, 
											"prod_name" => $value->product_name,
											"prod_specs" => $value->product_specs,
											"prod_type" => $value->prod_type_desc,
											"brand" => $value->brand_desc,
											"model" => $value->model_desc,
											"color" => $value->color_desc,
											"class" => $value->class_desc,
											"category" => $value->category_desc,
											"size" => $value->size_desc,
											"unit" => $value->stock_unit_id,
											"image" => unserialize($value->image_loc));
				}
			}
		}else{
			$result = $this->inventory_receive_model->search_item_name($prod);
			if (!empty($result)){
				$data['response'] = "true";
				foreach ($result as $key => $value) {
					$data['result'][] = array("label" => $value->product_name, 
											"prod_no" => $value->product_no,
											"prod_specs" => $value->product_specs,
											"prod_type" => $value->prod_type_desc,
											"brand" => $value->brand_desc,
											"model" => $value->model_desc,
											"color" => $value->color_desc,
											"class" => $value->class_desc,
											"category" => $value->category_desc,
											"size" => $value->size_desc,
											"unit" => $value->stock_unit_id,
											"image" => unserialize($value->image_loc));
				}
			}
		}
		echo json_encode($data);
	}

	public function get_product_transfer(){
		$data = array();
		$trans_no = $this->input->post("trans_no");
		$data['hdr'] = $this->inventory_receive_model->get_product_transfer_hdr($trans_no);
		$data['dtl'] = $this->inventory_receive_model->get_product_transfer_dtl($data['hdr'][0]->id);
		echo json_encode($data);
	}

	public function receive_list(){
    	$term = $this->input->post('term');
    	$function = $this->input->post("app_func");
		$result = $this->inventory_receive_model->receive_list($term);	
		$table_receive = table_receive($result,$function);
		// $table_receive = "";
		echo json_encode($table_receive);
	}

	public function save_data() {
        $receive_hdr = $this->input->post('receive_hdr');
        $receive_dtl = $this->input->post('receive_dtl');
        $receive_hdr['outlet_id'] =  $this->session->userdata('outlet_id');
        $receive_hdr['created_by'] =  $this->session->userdata('user_id');

        $hdr_id = $this->inventory_receive_model->save_hdr($receive_hdr);
        $query = $this->inventory_receive_model->save_dtl($receive_dtl,$hdr_id);
		$this->activity_model->insert_activity("3", "1", "1");
        if($query == true){
            $status = "success";
        }else{
            $status = "failed";
        }

        $status = "success";
        echo json_encode(array('status' => $status));       
    }

    public function update_data() {
		$hdr_id = $this->input->post('hdr_id');
        $receive_hdr = $this->input->post('receive_hdr');
        $receive_dtl = $this->input->post('receive_dtl');

        $this->inventory_receive_model->edit_receive_hdr($receive_hdr,$hdr_id);
        $query = $this->inventory_receive_model->edit_receive_dtl($receive_dtl,$hdr_id);
        $this->activity_model->insert_activity("3", "1", "2");
        if($query == true){
            $status = "success";
        }else{
            $status = "failed";
        }
        // $this->output->set_content_type('application/json');
        echo json_encode(array('status' => $status));       
    }

    public function get_receive(){
    	$id = $this->input->post('id');
    	$type = $this->input->post('type');
    	$hdr_data = array();
    	$dtl_data = array();
    	$hdr_id = "";
    	$result = $this->inventory_receive_model->get_receive_hdr($id,$type);
		$result2 = $this->inventory_receive_model->get_receive_dtl($id);
		foreach ($result2->result() as $row) { 
			$dtl_data[] = array(
					'product_id' => $row->prod_id,
					'product_name' => $row->product_name,
					'qty' => $row->qty,
					'cost' => $row->cost,
					'total_price' => ($row->qty * $row->cost)
				); 
		}
		echo json_encode(array('trans_hdr' => $result,'trans_dtl' => $dtl_data));
    }

    public function cancel_receive(){
        $id = $this->input->post("id");
        $result = $this->inventory_receive_model->cancel_receive($id);
        $this->activity_model->insert_activity("3", "1", "4");
        echo json_encode($result);        
    }

}
