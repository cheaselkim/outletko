<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Outlet extends CI_Controller {

	public function __construct(){
	    parent::__construct();
            $this->load->model("activity_model");
	      	$this->load->model("outlet_model");
	      	$this->load->helper("outlet");
			$result = $this->login_model->check_session();
			if ($result != true){
				redirect("/");
			}

		/* 
			Note for function 
			1 = Insert
			2 = Edit / Update
			3 = Delete / Cancel
			4 = Query
	
			model function for history is already autoload;
			$this->activity_model->insert_activity($module, $submodule, $function);
			(if module has no submodule, submodule automatically 0);
		 */
	}

	public function outlet_type(){
		$result = $this->outlet_model->outlet_type();
		echo json_encode($result);
	}

	public function search_outlet_city(){
		$outlet_city = $this->input->post("outlet_city");
		$data = array();
		$data['response'] = "false";

		$result = $this->outlet_model->search_outlet_city($outlet_city);
		if (!empty($result)){
			$data['response'] = "true";
			foreach ($result as $key => $value) {
				$data['result'][] = array("label" => $value->city_desc, "outlet_province" => $value->province_desc, "prov_id" => $value->prov_id, "city_id" => $value->city_id);
			}
		}

		echo json_encode($data);
	}

	public function save_outlet() {
        $outlet_hdr = $this->input->post('outlet_hdr');
        $outlet_hdr['comp_id'] =  $this->session->userdata('comp_id');
        $outlet_hdr['date_created'] =  date('Y-m-d H:i:s');
        $this->activity_model->insert_activity("2", "2", "1");
        $query = $this->outlet_model->save_outlet($outlet_hdr);

        var_dump($query);
        if($query == true){
            $status = "success";
        }else{
            $status = "failed";
        }
        // $this->output->set_content_type('application/json');
        echo json_encode(array('status' => $status));       
    }

	public function search_field() {
        $result = $this->outlet_model->search_field();
        $list = array();
        foreach ($result->result() as $row) {
            $list[] = array(
                'term' => $row->term
            );
        }
        $this->output->set_content_type('application/json');
        echo json_encode($list);
    }

    public function outlet_list(){
    	$type = $this->input->post('type');
    	$status = $this->input->post('status');
    	$term = $this->input->post('term');
    	$function = $this->input->post("app_func");
		$result = $this->outlet_model->outlet_list($type,$status,$term);
		$table_outlet = table_outlet($result,$function);
		echo json_encode($table_outlet);
	}

	public function get_outlet_dtl(){
    	$id = $this->input->post('id');
    	$result = $this->outlet_model->get_outlet_dtl($id);
		echo json_encode(array('outlet_dtl' => $result));
    }

    public function edit_outlet() {
		
		$outlet_id = $this->input->post('outlet_id');
        $outlet_hdr = $this->input->post('outlet_hdr');
        $query = $this->sales_model->edit_outlet($outlet_hdr,$outlet_id);
        if($query == true){
            $status = "success";
        }else{
            $status = "failed";
        }
        $this->output->set_content_type('application/json');
        echo json_encode(array('status' => $status));       
    }

    //FOR UPDATE
    public function update_outlet() {
		$outlet_id = $this->input->post('outlet_id');
        $outlet_hdr = $this->input->post('outlet_hdr');
        $query = $this->outlet_model->update_outlet($outlet_hdr,$outlet_id);
        if($query == true){
            $status = "success";
        }else{
            $status = "failed";
        }
        $this->output->set_content_type('application/json');
        echo json_encode(array('status' => $status));       
    }

    public function delete_outlet(){
        $id = $this->input->post("id");
        $result = $this->outlet_model->delete_outlet($id);
        echo json_encode($result);        
    }

    public function select_id(){
        $id = $this->input->post("id");
        $result = $this->outlet_model->get_outlet_dtl($id);
        echo json_encode($result);
    }

}
