<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

	public function __construct(){
	    parent::__construct();
	      	$this->load->model("user_model");
			$result = $this->login_model->check_session();
			if ($result != true){
				redirect("/");
			}
	}

	public function update_user(){
		$data = array();
		$password = $this->input->post("password");
		$username = $this->input->post("username");
		$new_password = $this->input->post("new_password");

		$check_username = $this->user_model->check_username($username);
		$check_password = $this->user_model->check_password();

		if ((password_verify($password, $check_password) == true) && ($check_username < 1)){
			$data['status'] = $this->user_model->update_user($new_password,$username);
		}else{
			$data['status'] = 0;
			$data['password'] = "0";

			if ($check_username > 0){
				$data['username'] = "0";
			}else{
				$data['username'] = "1";
			}

			if (password_verify($password, $check_password) == false){
				$data['password'] = "0";
			}else{
				$data['password'] = "1";
			}
		}

		echo json_encode($data);
	}

	public function get_user_owner(){
		$result = $this->user_model->get_user_owner();
		echo json_encode($result);
	}

	public function update_owner(){
		$result = $this->user_model->update_owner($this->input->post("data_owner"), $this->input->post("data_user"));
		echo json_encode($result);
	}

	public function get_user_account(){
		$result = $this->user_model->get_user_account();
		echo json_encode($result);
	}

	public function update_user_account(){
		$result = $this->user_model->update_user_account($this->input->post("data_sales"), $this->input->post("data_user"));
		echo json_encode($result);
	}

}