<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sales_force extends CI_Controller {

	public function __construct(){
	    parent::__construct();
            $this->load->model("activity_model");
	      	$this->load->model("sales_force_model");
            $this->load->model("password_model");
	      	$this->load->helper("sales_force");
            $this->load->helper("user");
			$result = $this->login_model->check_session();
			if ($result != true){
				redirect("/");
			}
	}

    public function get_outlet(){
        $comp_id = $this->session->userdata('comp_id');
        $result = $this->sales_force_model->get_outlet($comp_id);
        echo json_encode($result);
    }

    public function account_id(){
        $data = array();
        $outlet = $this->input->post("outlet");
        $data['account_id'] = $this->sales_force_model->account_id($outlet);
        echo json_encode($data);
    }

    public function sales_force_type(){
        $result = $this->sales_force_model->sales_force_type();
        echo json_encode($result);
    }

	public function save_sales_force() {
        $data_users = $this->input->post('data_users');
        $data_hdr = $this->input->post('data_hdr');
        $data_hdr['comp_id'] =  $this->session->userdata('comp_id');
        $data_hdr['date_created'] =  date('Y-m-d H:i:s');
        $data_hdr['user_id'] = $result = $this->sales_force_model->insert_users($data_users);
        $query = $this->sales_force_model->save_sales_force($data_hdr);        
        $randomString = $this->randomString();
        $status = $this->send_email($data_users['email'], $data_users['account_id'], $randomString);

        if($query == true){
            $this->activity_model->insert_activity("5", "0", "1");
            $status = "success";
        }else{
            $status = "failed";
        }
        echo json_encode(array('status' => $status, 'string' => $randomString));       
    }

    public function randomString($length = 6) {
        $str = "";
        $characters = array_merge(range('A','Z'), range('a','z'), range('0','9'));
        $max = count($characters) - 1;
        for ($i = 0; $i < $length; $i++) {
            $rand = mt_rand(0, $max);
            $str .= $characters[$rand];
        }
        return $str;
    }

    public function send_email($email, $account_id, $randomString){

        $this->load->library("email");
        $status = 0;

        $result = $this->password_model->find_email($email, $randomString);

        if ($result > 0){
            $config = array(
                        'protocol' => 'smtp',
                        'smtp_host' => 'ssl://smtp.gmail.com',
                        'smtp_port' => 465,
                        'smtp_user' => 'epgmcompany@gmail.com',
                        'smtp_pass' => 'epgmcompany101'
                    );


            $this->email->initialize($config)
                        ->set_newline("\r\n")
                        ->from('noreply@epgmcompany.com', 'eOutletSuite Application')
                        ->to($email)
                        ->subject('eOutletSuite Account Register')
                        ->message(" Your Account ID : ". $account_id . " ".
                                    "Your Password : ".$randomString);

            if($this->email->send()) {
                $status = 1;
            }else {
                $status = $this->email->print_debugger();
                }
        }else{
            $status = 0;
        }
        return $status;
    }


	public function search_field() {
        $result = $this->sales_force_model->search_field();
        $list = array();
        foreach ($result->result() as $row) {
            $list[] = array(
                'term' => $row->term
            );
        }
        $this->output->set_content_type('application/json');
        echo json_encode($list);
    }

    public function sales_force_list(){
    	$term = $this->input->post('term');
    	$function = $this->input->post("app_func");
		$result = $this->sales_force_model->sales_force_list($term);
		$table_sales_force = table_sales_force($result,$function);
		echo json_encode($table_sales_force);
	}

	public function get_sales_force_dtl(){
    	$id = $this->input->post('id');
    	$result = $this->sales_force_model->get_sales_force_dtl($id);
		echo json_encode(array('sales_force_dtl' => $result));
    }

    //FOR UPDATE
    public function update_sales_force() {
		$sales_force_id = $this->input->post('id');
        $sales_force_hdr = $this->input->post('sales_force_hdr');
        $this->activity_model->insert_activity("4", "7", "2");
        $query = $this->sales_force_model->update_sales_force($sales_forcer_hdr,$sales_force_id);
        if($query == true){
            $status = "success";
        }else{
            $status = "failed";
        }
        $this->output->set_content_type('application/json');
        echo json_encode(array('status' => $status));       
    }

    public function delete_sales_force(){
        $id = $this->input->post("id");
        $result = $this->sales_force_model->delete_sales_force($id);
        echo json_encode($result);        
    }

    public function user_list(){
        $result = $this->sales_force_model->user_list();
        $table_user = table_user($result);
        echo json_encode($table_user);
    }

    public function save_user_roles() {
        $table_data = $this->input->post('table_data');
        $this->activity_model->insert_activity("5", "0", "6");
        $query = $this->sales_force_model->save_user_roles($table_data);
        if($query == true){
            $status = "success";
        }else{
            $status = "failed";
        }
        // $this->output->set_content_type('application/json');
        echo json_encode(array('status' => $status));       
    }

}
