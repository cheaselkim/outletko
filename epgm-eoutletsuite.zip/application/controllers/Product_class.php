<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product_class extends CI_Controller {

	public function __construct(){
	    parent::__construct();
	    	$this->load->model("product_class_model");
	    	$this->load->helper("product_class");
			$result = $this->login_model->check_session();
			if ($result != true){
				redirect("/");
			}
	}

	public function company(){
		$result = $this->product_class_model->company();
		echo json_encode($result);
	}

	public function outlet(){
		$result = $this->product_class_model->outlet();
		echo json_encode($result);
	}

	public function insert_product_class(){
		$insert_array = array(
				"comp_id" => $this->session->userdata("comp_id"),
				"outlet_id" => $this->input->post("outlet"),
				"class_desc" => $this->input->post("class_desc")
				);

		$result = $this->product_class_model->insert_product_class($insert_array);
		echo json_encode($result);
	}

	public function query_product_class(){
		$app_func = $this->input->post("app_func");
		$class_desc = $this->input->post("class_desc");
		$outlet = $this->input->post("outlet");
		$result = $this->product_class_model->query_product_class($class_desc, $outlet);
		$tbl_result = tbl_query($result,$app_func);
		echo json_encode($tbl_result);
	}

	public function delete_prod_class(){
		$id = $this->input->post("id");
		$result = $this->product_class_model->delete_prod_class($id);
		echo json_encode($result);
	}

	public function get_transaction(){
		$id = $this->input->post("id");
		$result = $this->product_class_model->get_transaction($id);
		$data = array();
		$data['outlet'] = $result->outlet_id;
		$data['class_desc'] = $result->class_desc;
		echo json_encode($data);
	}

	public function update_product_class(){
		$update_array = array(
				"outlet_id" => $this->input->post("outlet"),
				"class_desc" => $this->input->post("class_desc")
				);

		$result = $this->product_class_model->update_product_class($update_array, $this->input->post("id"));
		echo json_encode($result);

	}

}
