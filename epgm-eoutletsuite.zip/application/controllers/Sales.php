<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sales extends CI_Controller {

	public function __construct(){
	    parent::__construct();
	      	$this->load->model("sales_model");
	      	$this->load->helper("table_sales");
			$result = $this->login_model->check_session();
			if ($result != true){
				redirect("/");
			}
	}

	public function max_transno(){
		$result = $this->sales_model->max_transno();
		echo json_encode($result);
	}

	public function currency(){
		$result = $this->sales_model->currency();
		echo json_encode($result);
	}

	public function payment_type(){
		$result = $this->sales_model->payment_type();
		echo json_encode($result);
	}

	public function bank_list(){
		$result = $this->sales_model->bank_list();
		echo json_encode($result);
	}

	public function search_customer($type){
		$customer = $this->input->post("customer");
		$data = array();
		$data['response'] = "false";

		if ($type == "1"){
			$result = $this->sales_model->search_custcode($customer);
			if (!empty($result)){
				$data['response'] = "true";
				foreach ($result as $key => $value) {
					$data['result'][] = array("label" => $value->cust_code, "cust_name" => $value->cust_name, "id" => $value->id);
				}
			}
		}else{
			$result = $this->sales_model->search_custname($customer);
			if (!empty($result)){
				$data['response'] = "true";
				foreach ($result as $key => $value) {
					$data['result'][] = array("label" => $value->cust_name, "cust_code" => $value->cust_code, "id" => $value->id);
				}
			}
		}

		echo json_encode($data);

	}

	public function search_item(){
		$item_cat = $this->input->post("item_cat");
		$item_keyword = $this->input->post("item_keyword");
		$result = "";

		$result = $this->sales_model->search_item($item_cat, $item_keyword);

		$table_item = table_item($result);

		echo json_encode($table_item);
	}

	public function select_item(){
		$prod_id = $this->input->post("id");
		$data = array();
		$result = $this->sales_model->select_item($prod_id);


		foreach ($result as $key => $value) {
			$data['prod_name'] = $value->product_name;
			$data['prod_no'] = $value->product_no;
			$data['image_loc'] = $value->image_loc;
			$data['price'] = $value->reg_selling_price;
			$data['qty'] = $value->inventory_qty;
			$data['uom'] = $value->unit_desc;			
		}

		echo json_encode($data);
	}

	public function sales_query(){
		/* function for query and cancelled */

		$keyword = $this->input->post("keyword");
		$type = $this->input->post("type");

		if ($type == "3"){
			$status = $this->input->post("status");			
		}else{
			$status = "1";
		}

		$result = $this->sales_model->sales_query($keyword, $status);
		// var_dump($result);
		$table_query = table_query($result, $type);

		echo json_encode($table_query);
	}

	public function save_transaction() {
        $sales_hdr = $this->input->post('sales_hdr');
        $sales_dtl = $this->input->post('sales_dtl');
        $payment_dtl = $this->input->post('payment_dtl');

        $company = array(
	        	"comp_id" => $this->session->userdata("comp_id"), 
	        	"outlet_id" => $this->session->userdata("outlet_id")
        	);
        $sales_hdr = $company + $sales_hdr;

        $hdr_id = $this->sales_model->save_transaction_hdr($sales_hdr);
        $this->sales_model->save_transaction_dtl($sales_dtl,$hdr_id);

        $data = array(
                    'sales_hdr_id'   => $hdr_id,
                    'payment_date'   => date("Y-m-d", strtotime($payment_dtl['payment_date'])),
                    'payment_type_id'=> $payment_dtl['payment_type_id'],
                    'bank_id'        => $payment_dtl['bank_id'],
                    'check_card_no'  => $payment_dtl['check_card_no'],
                    'check_date'     => date("Y-m-d", strtotime($payment_dtl['check_date'])),
                    'curr_id'  		 => $payment_dtl['curr_id'],
                    'amount'         => $payment_dtl['amount']
                );
        // $query = $this->sales_model->save_transaction($sales_hdr,$sales_dtl,$payment_dtl);
        $query = $this->sales_model->save_payment_dtl($data);
        if($query == true){
            $status = "success";
        }else{
            $status = "failed";
        }

        // $this->output->set_content_type('application/json');
        // $this->output->set_output(json_encode(array('status' => $status)));
        echo json_encode(array('status' => $status));       
    }

    public function edit_transaction() {
		$hdr_id = $this->input->post('hdr_id');
        $sales_hdr = $this->input->post('sales_hdr');
        $sales_dtl = $this->input->post('sales_dtl');
        $payment_dtl = $this->input->post('payment_dtl');

        $this->sales_model->edit_transaction_hdr($sales_hdr,$hdr_id);
        $this->sales_model->edit_transaction_dtl($sales_dtl,$hdr_id);
        $data = array(
                    'payment_date'   => $payment_dtl['payment_date'],
                    'payment_type_id'=> $payment_dtl['payment_type_id'],
                    'bank_id'        => $payment_dtl['bank_id'],
                    'check_card_no'  => $payment_dtl['check_card_no'],
                    'check_date'     => $payment_dtl['check_date'],
                    'curr_id'  		 => $payment_dtl['curr_id'],
                    'amount'         => $payment_dtl['amount']
                );
        $query = $this->sales_model->edit_payment_dtl($data,$hdr_id);

        if($query == true){
            $status = "success";
        }else{
            $status = "failed";
        }

        echo json_encode(array('status' => $status));       
    }

    public function get_transaction(){
    	$id = $this->input->post('id');
    	$hdr_data = array();
    	$dtl_data = array();
    	$payment_data = array();
    	$result = $this->sales_model->get_transaction_hdr($id);
		$result2 = $this->sales_model->get_transaction_payment($id);

		$result3 = $this->sales_model->get_transaction_dtl($id);
		foreach ($result3->result() as $row) { 
			$dtl_data[] = array(
					'product_id' => $row->product_id,
					'qty' => $row->qty,
					'selling_price' => $row->selling_price,
					'total_price' => $row->total_price,
					'volume_discount' => $row->volume_discount,
					'total_selling_price' => $row->total_selling_price,
					'share' => $row->share,
					'share_amount' => $row->share_amount,
					'total_amount' => $row->total_amount,
					'reg_selling_price' => $row->reg_selling_price,
					'product_name' => $row->product_name,
					'unit_desc' => $row->unit_desc
				); 
		}

		echo json_encode(array('trans_hdr' => $result,'trans_dtl' => $dtl_data,'trans_payment' => $result2));
    }

    public function cancel_trans(){
    	$id = $this->input->post("id");
    	$result = $this->sales_model->cancel_trans($id);
    	echo json_encode($result);
    }

    public function select_id(){
    	$data = array();
    	$id = $this->input->post("id");
    	$result = $this->sales_model->get_transaction_dtl($id);
    	$data['header'] = $this->sales_model->get_transaction_hdr($id);
    	$data['detail'] = sales_dtl_query($result->result());
    	echo json_encode($data);
    }

}
