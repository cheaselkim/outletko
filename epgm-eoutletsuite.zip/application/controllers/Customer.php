<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Customer extends CI_Controller {

	public function __construct(){
	    parent::__construct();
            $this->load->model("activity_model");
	      	$this->load->model("customer_model");
	      	$this->load->helper("customer");
			$result = $this->login_model->check_session();
			if ($result != true){
				redirect("/");
			}

		/* 
			Note for function 
			1 = Insert
			2 = Edit / Update
			3 = Delete / Cancel
			4 = Query
	
			model function for history is already autoload;
			$this->activity_model->insert_activity($module, $submodule, $function);
			(if module has no submodule, submodule automatically 0);
		 */
	}

	public function customer_type(){
		$result = $this->customer_model->customer_type();
		echo json_encode($result);
	}

    public function outlet(){
        $result = $this->customer_model->outlet();
        echo json_encode(array("all_access" => $result['all_access'], "data" => $result['result']));
    }

	public function search_cust_city(){
		$cust_city = $this->input->post("cust_city");
		$data = array();
		$data['response'] = "false";

		$result = $this->customer_model->search_cust_city($cust_city);
		if (!empty($result)){
			$data['response'] = "true";
			foreach ($result as $key => $value) {
				$data['result'][] = array("label" => $value->city_desc, "cust_province" => $value->province_desc, "prov_id" => $value->prov_id, "city_id" => $value->city_id);
			}
		}

		echo json_encode($data);
	}

	public function save_customer() {
        $customer_hdr = $this->input->post('customer_hdr');
        $customer_hdr['comp_id'] =  $this->session->userdata('comp_id');
        $customer_hdr['date_insert'] =  date('Y-m-d');
        // var_dump($customer_hdr);
        // $this->activity_model->insert_activity("4", "6", "1");
        $query = $this->customer_model->save_customer($customer_hdr);
        // $query = true;
        
        if($query == true){
            $status = "success";
        }else{
            $status = "failed";
        }
        // $this->output->set_content_type('application/json');
        echo json_encode(array('status' => $status));       
    }

	public function search_field() {
        $result = $this->customer_model->search_field();
        $list = array();
        foreach ($result->result() as $row) {
            $list[] = array(
                'term' => $row->term
            );
        }
        $this->output->set_content_type('application/json');
        echo json_encode($list);
    }

    public function customer_list(){
    	$term = $this->input->post('term');
    	$function = $this->input->post("app_func");
		$result = $this->customer_model->customer_list($term);
		$table_customer = table_customer($result,$function);
		echo json_encode($table_customer);
	}

	public function get_customer_dtl(){
    	$id = $this->input->post('id');
    	$result = $this->customer_model->get_customer_dtl($id);
		echo json_encode(array('customer_dtl' => $result));
    }


    //FOR UPDATE
    public function update_customer() {
		$customer_id = $this->input->post('id');
        $customer_hdr = $this->input->post('customer_hdr');
        $this->activity_model->insert_activity("4", "6", "2");
        $query = $this->customer_model->update_customer($customer_hdr,$customer_id);
        if($query == true){
            $status = "success";
        }else{
            $status = "failed";
        }
        $this->output->set_content_type('application/json');
        echo json_encode(array('status' => $status));       
    }

    public function delete_customer(){
        $id = $this->input->post("id");
        $this->activity_model->insert_activity("4", "6", "4");
        $result = $this->customer_model->delete_customer($id);
        echo json_encode($result);        
    }

}
