<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Supplier extends CI_Controller {

	public function __construct(){
	    parent::__construct();
	      	$this->load->model("supplier_model");
	      	$this->load->helper("supplier");
			$result = $this->login_model->check_session();
			if ($result != true){
				redirect("/");
			}
	}

	public function supplier_type(){
		$result = $this->supplier_model->supplier_type();
		echo json_encode($result);
	}

    public function business_nature(){
        $result = $this->supplier_model->business_nature();
        echo json_encode($result);
    }

    public function get_classification(){
        $result = $this->supplier_model->get_classification();
        echo json_encode($result);
    }

    public function get_organization(){
        $result = $this->supplier_model->get_organization();
        echo json_encode($result);
    }

    public function outlet(){
        $result = $this->supplier_model->outlet();
        echo json_encode(array("all_access" => $result['all_access'], "data" => $result['result']));
    }

	public function search_supp_city(){
		$supp_city = $this->input->post("supp_city");
		$data = array();
		$data['response'] = "false";

		$result = $this->supplier_model->search_supp_city($supp_city);
		if (!empty($result)){
			$data['response'] = "true";
			foreach ($result as $key => $value) {
				$data['result'][] = array("label" => $value->city_desc, "supp_province" => $value->province_desc, "prov_id" => $value->prov_id, "city_id" => $value->city_id);
			}
		}

		echo json_encode($data);
	}

	public function save_supplier() {
        $supplier_hdr = $this->input->post('supplier_hdr');
        $supplier_hdr['comp_id'] =  $this->session->userdata('comp_id');
        $supplier_hdr['date_insert'] =  date('Y-m-d H:i:s');
        $this->activity_model->insert_activity("4", "7", "1");
        $query = $this->supplier_model->save_supplier($supplier_hdr);
        if($query == true){
            $status = "success";
        }else{
            $status = "failed";
        }
        // $this->output->set_content_type('application/json');
        echo json_encode(array('status' => $status));       
    }

	public function search_field() {
        $result = $this->supplier_model->search_field();
        $list = array();
        foreach ($result->result() as $row) {
            $list[] = array(
                'term' => $row->term
            );
        }
        $this->output->set_content_type('application/json');
        echo json_encode($list);
    }

    public function supplier_list(){
    	$term = $this->input->post('term');
    	$function = $this->input->post("app_func");
		$result = $this->supplier_model->supplier_list($term);
		$table_supplier = table_supplier($result,$function);
		echo json_encode($table_supplier);
	}

	public function get_supplier_dtl(){
    	$id = $this->input->post('id');
    	$result = $this->supplier_model->get_supplier_dtl($id);
		echo json_encode(array('supplier_dtl' => $result));
    }

    //FOR UPDATE
    public function update_supplier() {
		$supplier_id = $this->input->post('id');
        $supplier_hdr = $this->input->post('supplier_hdr');
        $this->activity_model->insert_activity("4", "7", "2");
        $query = $this->supplier_model->update_supplier($supplier_hdr,$supplier_id);
        if($query == true){
            $status = "success";
        }else{
            $status = "failed";
        }
        $this->output->set_content_type('application/json');
        echo json_encode(array('status' => $status));       
    }

    public function delete_supplier(){
        $id = $this->input->post("id");
        $result = $this->supplier_model->delete_supplier($id);
        echo json_encode($result);        
    }

}
