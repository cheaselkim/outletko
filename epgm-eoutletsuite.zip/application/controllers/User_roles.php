<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_roles extends CI_Controller {

	public function __construct(){
	    parent::__construct();
	      	$this->load->model("User_roles_model");
	      	$this->load->helper("user_roles");
			$result = $this->login_model->check_session();
    			if ($result != true){
    				redirect("/");
    			}
	}

    public function get_roles_function(){
        $module = $this->User_roles_model->get_module();
        $function = $this->User_roles_model->get_roles_function();
        $tbl = roles_function($module, $function);
        echo json_encode($tbl);
    }

    public function get_sales_force(){
        $sales_force = $this->User_roles_model->get_sales_force();
        $result = sales_force($sales_force);
        echo json_encode($result);
    }

    public function get_roles(){
        $id = $this->input->post("id");
        $result = $this->User_roles_model->get_roles($id);
        echo json_encode($result);
    }

}
