asda
   <div class="container-fluid">
      <div class="animated fadeIn">
        <div class="card">
          <div class="card-body">
          	<div class="row">
          		<div class="col-sm-12">

          		</div>
          	</div>
              
        </div> <!-- end of card body -->
      </div>  <!-- end of card -->      
    </div>
  </div> <!-- end of container fluid -->