  <!DOCTYPE html>
  <html lang="en">
  <head>
    <title>eOutlet Suite</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="EPGM eoutletsuite, eoutletsuite, eoutletsuite.com">
    <meta name="keywords" content="EPGM, eoutletsuite, eoutletsuite.com">

    <link rel="icon" href="assets/img/icon2.png" type="image/png" sizes="2x2">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/all.css" >
    <link rel="stylesheet" href="assets/css/login2.css">

    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/all.js"></script>
    <script src="assets/js/style.js"></script>
  </head>
  <body>

  <nav class="navbar navbar-expand-sm sticky-top bg-light">
    <a href="<?php echo base_url(); ?>" style="text-decoration: none !important;"><span class="h1 text-shadow-3"><span class="span-eprocurement">eOutlet</span><span class="span-suite">Suite</span></span></a>
    <span class="ml-auto mr-4 span-help">Help</span>
  </nav>

  <section class="section-eProcurement">
    <div class="container-fluid pt-3">
      <div class="row">
        <div class="col-lg-7 col-md-12 col-sm-12 div-left-login">
          <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
              <div class="text-white div-bottom div-run">
                <div class="row px-4 pt-3">
                  <div class="col bg-yellow div-card mx-2 px-0 text-center pt-4">
                    <p class="text-white" style="line-height: 140%; font-size: 14px;">
                      MANAGE AND <br>
                      MONITOR <br>
                      SALES
                    </p>
                  </div>
                  <div class="col bg-blue div-card mx-2 px-0 text-center pt-4">
                    <p class="text-white" style="line-height: 140%; font-size: 14px;">
                      MANAGE AND <br>
                      MONITOR YOUR<br>
                      INVENTORY
                    </p>
                  </div>
                  <div class="col bg-green div-card mx-2 px-0 text-center pt-4">
                    <p class="text-white" style="line-height: 140%; font-size: 14px;">
                      CASH AND <br>
                      COLLECTION <br>
                      MANAGEMENT
                    </p>
                  </div>
                  <div class="col bg-brown div-card mx-2 px-0 text-center pt-4">
                    <p class="text-white" style="line-height: 140%; font-size: 14px;">
                      IMPROVE<br>
                      CUSTOMER <br>
                      MANAGEMENT
                    </p>
                  </div>
                  <div class="col bg-violet div-card mx-2 px-0 text-center pt-4">
                    <p class="text-white" style="line-height: 140%; font-size: 14px;">
                      ACCESS TO <br>
                      BUSINESS <br>
                      INFORMATION
                    </p>
                  </div>
                </div>
                <div class="row px-3">
                  <div class="col-lg-12 col-md-12 col-sm-12">
                    <span class="h2 text-black text-shadow-2">Manage your business from your smartphone</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-md-9 col-sm-12 mx-auto pr-4 pb-3" style="padding-left: 65px;">
          <form  action="<?php echo site_url('login/check_login'); ?>" method="POST">
            <div class="div-login">
              <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 text-center pt-3 text-shadow-2" style="font-size: 30px;">
                  <span class="span-login-logo"><span class="span-eprocurement">eOutlet</span><span class="span-suite">Suite</span> </span>             
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12 text-center pt-5">
                  <span class="text-gray" style="font-size: 20px;">Sign in</span>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12 px-5 pt-5" id="div-username">
                  <input type="text" placeholder="Account no." class="" name="uname" id="uname" required="required">
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12 px-5 pt-5" id="div-password">
                  <input type="password" placeholder="Password" class="" name="pword" id="pword" required="required">
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12 px-5 pt-4" id="div-btn-next">
                  <button class="btn btn-block btn-green" id="next">Next</button>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12 px-5 pt-4" id="div-btn-login">
                  <input class="btn btn-block btn-green" type="submit" id="login" value="Login">
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12 px-5 pt-4 text-right">
                  <a href="<?php echo base_url(); ?>" class="span-green">Trouble signing in?</a>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </section>

  <section class="bg-white" style="height: 91vh;">
    <div class="container-fluid">
      <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12" style="background-color: rgb(119,147,60);">
          <div class="text-center py-4" style="height: 130px;line-height: 150px;">
            <p class="h1 text-white">Take your business on the go with eOutletSuite</p>
            <p class="h4 text-white">Managing a business has never been easier.</p>
          </div>
        </div>
        <div class="col-lg-12 col-md-12 col-sm-12">
          <div class="row">
            <div class="col-lg-3 px-0" style="height: 72vh;padding-top: 30px;">
              <div class="">
                <img src="<?php echo base_url('assets/img/hand-phone.png') ?>" style="height: 440px;width: 350px;">                
              </div>
            </div>
            <div class="col-lg-9 pt-3 pl-5 pr-3">
              <div class="row">
                <div class="col-lg-3 div-hardware-store"> 
                </div> 
                <div class="col-lg-3 div-beauty-salon"> 
                </div> 
                <div class="col-lg-3 div-shoe-store"> 
                </div> 
                <div class="col-lg-3 div-bake-shop"> 
                </div> 
              </div> 
              <div class="row pt-3">
                <div class="col-lg-3 div-gen-merchandise"> 
                </div> 
                <div class="col-lg-3 div-clothing-store"> 
                </div>
                <div class="col-lg-3 div-electronics-store"> 
                </div>
                <div class="col-lg-3 div-beauty-spa"> 
                </div>
              </div>
              <div class="row pt-2">
                <div class="col-lg-12 text-center">
                    <button class="btn btn-green" style="width: 300px;">Get Started</button> 
                </div> 
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>


  <footer class="text-center fixed-bottom bg-white">
    <span style="font-size: 13px;"><a href="<?php echo base_url('/terms') ?>" style='color: rgb(119,147,60)'>Terms</a> | <a href="<?php echo base_url('/privacy') ?>" style="color: rgb(119,147,60)">Privacy</a></span>  
  </footer>


  </body>
  </html>


