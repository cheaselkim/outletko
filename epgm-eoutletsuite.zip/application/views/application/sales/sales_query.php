<style type="text/css">
  .font-size-modal{
    font-size: 16px;
  }
</style>

<script type="text/javascript" src="<?php echo base_url('js/application/sales/sales_query.js') ?>"></script>
<input type="hidden" id="app_func" value="<?php echo $function; ?>">

<div class="container-fluid" id="div_edit">
  
</div>

<div class="container-fluid" style="height: auto;min-height: 85vh;" id="div_query">
  
  <div class="row pt-5">
    <div class="col-1"></div>
    <div class="col-10">
      <div class="form-inline">
        <label for="searching" class="font-weight-bold">Search : </label>
        <input type="text" class="form-control ml-3" id="keyword" placeholder="Customer/Transaction No" style="width: 300px;">
        <label class="ml-3" id="lbl_status">Status</label>
        <select class="form-control input-sm ml-3" id="status"> 
          <option value="0">All</option>
          <option value="1">Transaction</option>
          <option value="2">Cancelled</option>
        </select>
        <button class="btn btn-primary ml-3" id="btn_search">Search</button>
      </div>                    
    </div>
    <div class="col-1"></div>
  </div>
  
  <div class="row pt-4">
    <div class="col-1"></div>
    <div class="col-10">
      <div id="div_query_tbl">
        
      </div>
    </div>
    <div class="col-1"></div>
  </div>

</div>


<div class="modal fade" id="modal_query" role="dialog">
  <div class="modal-dialog modal-lg" style="position: absolute; top: -5%; right: 10%;z-index: 1;">
    <div class="modal-content">
      <div class="modal-header pt-3 pb-0">
        <h5>Sales Query</h5>
      </div>
      <div class="modal-body">
        <div class="row">
          <div class="col-lg-6 col-md-6 col-sm-12 mr-auto">
            <label class="font-size-modal">Customer</label>
            <div class="row">
              <div class="col-lg-4">
                <input type="text" class="form-control" id="mod_cust_code" readonly>
              </div>
              <div class="col-lg-8">
                <input type="text" class="form-control" id="mod_cust_name" readonly>
              </div>
            </div>
          </div>
          <div class="col-lg-3 ml-auto">
            <label class="font-size-modal">Transaction No</label>
            <input type="text" class="form-control" id="mod_trans_no" readonly>
          </div>
        </div>
        <div class="row pt-2">
          <div class="col-lg-5">
            <div class="row">
              <div class="col-lg-6">
                <label class="font-size-modal">Sales Discount</label>
                <input type="text" class="form-control text-right" id="mod_discount_sales" value="0.00" readonly>
              </div>
              <div class="col-lg-6">
                <label class="font-size-modal">Total Amount</label>
                <input type="text" class="form-control text-right" id="mod_tot_amount" value="0.00"  readonly>
              </div>
            </div>
          </div>
          <div class="col-lg-2"></div>
          <div class="col-lg-5">
            <div class="row">
              <div class="col-lg-6">
                <label class="font-size-modal">Total VAT Amount</label>
                <input type="text" class="form-control text-right" id="mod_tot_vat" value="0.00"  readonly>
              </div>
              <div class="col-lg-6">
                <label class="font-size-modal">Total Net of VAT</label>
                <input type="text" class="form-control text-right" id="mot_net_vat" value="0.00"  readonly>
              </div>
            </div>            
          </div>
        </div>
        <div class="row pt-3">
          <div class="col-lg-12">
            <div id="div_query_items" style="height: 200px;">
              
            </div>
          </div>
        </div>

      </div>
      <div class="modal-footer">
        <button class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
