<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/application/sales.css') ?>">
<script type="text/javascript" src="<?php echo base_url('js/application/sales/sales_insert.js') ?>"></script>
<input type="hidden" id="prod_id">
<input type="hidden" id="tbl_item_row">

<body>

<div class="container-fluid pt-3">
    <div class="div-trans-header">
        <div class="row">
            <div class="col-xs-12 col-md-12 text-date">
                <div class="row">
                    <!-- For medium, large screen -->
                    <div class="col-8 col-md-2 order-1 order-md-1 text-date d-none d-md-block d-lg-block d-xl-block">
                        <span>Trans. No.: </span><span id="sales_trans_no">00001</span>
                    </div>

                    <!-- For small screen -->
                    <div class="col-6 col-md-2 order-1 order-md-1 text-date d-block d-md-none d-lg-none d-xl-none">
                        <span>Trans. No.: </span><span id="sales_trans_no">00001</span>
                    </div>

                    <div class="col-12 col-md-8 order-12 order-md-2 text-date">

                        <div class="input-group">
                            <span class="span-customer">Customer</span>
                            <div class="input-group-prepend cust_code_wd">
                                <input type="text" class="form-control" placeholder="<?php echo str_pad($this->session->userdata('outlet_id'), 3,0, STR_PAD_LEFT) ?>00001" value="<?php echo str_pad($this->session->userdata('outlet_id'), 3,0, STR_PAD_LEFT) ?>00001" id="cust_code" data-id = "0">
                            </div>
                            <input type="text" class="form-control" placeholder="CASH" id="cust_name">
                        </div>
                    </div>

                    <!-- For medium, large screen -->
<!--                     <div class="col-4 col-md-2 order-2 order-md-12 ctmspacing d-none d-md-block d-lg-block d-xl-block">
                        <button class="form-control"> + Customer</button>
                    </div>
 -->
                    <!-- For small screen -->
<!--                     <div class="col-6 col-md-2 order-2 order-md-12 ctmspacing d-block d-md-none d-lg-none d-xl-none">
                        <button class="form-control"> + Customer</button>
                    </div> -->
                </div>
            </div>
        </div>
    </div>

    <hr style="color: black;" class="my-2">

    <div class="div-trans-header">
        <div class="row">
            <div class="col-xs-12 col-md-12 col-lg-12 text-date">
                <div class="row">
                    <!-- For small, medium, large screen -->
                    <div class="col-4 col-md-3 col-lg-2 order-1 order-md-1 order-lg-1">
                        <div class="div-prod-img" id="image-box">
                        </div>
                    </div>

                    <!-- For small screen -->
                    <div class="col-8 col-md-9 col-lg-8 order-12 order-md-2 order-lg-2 d-block d-md-none d-lg-none d-xl-none prod-dtl-small">
                        <div class="row">
                            <div class="col-12 col-md-6 text-sales">
                                <div class="input-group">
                                    <span class="span-prodno">Product No</span>
                                    <div class="input-group-prepend prod_no_wd">
                                        <input type="text" class="form-control" id="prod_no" readonly>
                                    </div>
                                </div>
                            </div>

                            <div class="col-12 col-md-6 text-sales pt-1">
                                <div class="input-group">
                                    <span class="span-stockqty">Stock Qty</span>
                                    <div class="input-group-prepend stock_qty_wd">
                                        <input type="text" class="form-control" id="stock_qty" readonly>
                                    </div>
                                    <input type="text" class="form-control" id="stock_uom" readonly>
                                </div>
                            </div>
                        </div>

                        <div class="row pt-1">
                            <div class="col-12 col-md-12 text-sales">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="pr-2">Product Name</span>
                                    </div>
                                    <input class="form-control prod_name" id="prod_name" readonly>
                                </div>
                            </div>
                        </div>

                        <div class="row pt-1 d-block d-md-block d-lg-none d-xl-none">
                            <div class="col-12 col-md-12">
                                <div class="row">
                                    <div class="col-8 col-md-8 col-lg-12 order-1 order-md-1 order-lg-12 text-sales">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="span-agent">Partner/Agent</span>
                                                <input class="form-control" id="partner" readonly>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-4 col-md-4 col-lg-12 order-12 order-md-12 order-lg-1">
                                        <button class="form-control" id="btn_select_item">Select Item</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- For medium screen -->
                    <div class="col-8 col-md-9 col-lg-8 order-12 order-md-2 order-lg-2 d-none d-md-block d-lg-block d-xl-block prod-dtl-med">
                        <div class="row">
                            <div class="col-12 col-md-6 text-sales pl-0">
                                <div class="input-group">
                                    <span class="span-prodno">Product No</span>
                                    <div class="input-group-prepend prod_no_wd" >
                                        <input type="text" class="form-control" id="prod_no" readonly>
                                    </div>
                                </div>
                            </div>

                            <div class="col-12 col-md-6 text-sales">
                                <div class="input-group">
                                    <span class="pr-3">Stock Qty</span>
                                    <div class="input-group-prepend stock_qty_wd">
                                        <input type="text" class="form-control ml-1" id="stock_qty" readonly>
                                    </div>
                                    <input type="text" class="form-control ml-1" id="stock_uom" readonly>
                                </div>
                            </div>
                        </div>

                        <div class="row pt-2">
                            <div class="col-12 col-md-12 text-sales pl-0">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="pr-2">Product Name</span>
                                    </div>
                                    <input class="form-control prod_name" id="prod_name" readonly>
                                </div>
                            </div>
                        </div>

                        <div class="row pt-2 d-block d-md-block d-lg-none d-xl-none">
                            <div class="col-6 col-md-12">
                                <div class="row">
                                    <div class="col-12 col-md-8 col-lg-12 order-1 order-md-1 order-lg-12 text-sales">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="span-agent">Partner/Agent</span>
                                            </div>
                                            <input class="form-control" id="partner" readonly>
                                        </div>
                                    </div>

                                    <div class="col-12 col-md-4 col-lg-12 order-12 order-md-12 order-lg-1">
                                        <button class="form-control" id="btn_select_item">Select Item</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- For large screen -->
                    <div class="col-lg-2 order-lg-12 d-none d-md-none d-lg-block d-xl-block">
                        <div class="form-group row">
                            <div class="col-lg-12 order-lg-12 text-sales text-center">
                                <span class="">Partner/Agent</span>
                                <input class="form-control" id="partner" readonly>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-lg-12 order-lg-1">
                                <button class="form-control" id="btn_select_item">Select Item</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="div-prod-header pt-2">
        <div class="row">
            <div class="col-xs-12 col-md-12 text-date">
                <div class="row">


                    <!-- For medium screen -->
                    <div class="col-3 col-md-4 col-lg-4 d-none d-md-block">
                        <div class="row">
                            <div class="col-12 col-md-12">
                                <!-- For large screen -->
                                <div class="form-horizontal d-none d-md-none d-lg-block d-xl-block">
                                    <div class="form-group row mb-1">
                                        <span class="col-7 col-md-7 col-lg-7 form-lbl-text" for="text-input">Regular Price</span>
                                        <div class="col-5 col-md-5 col-lg-5">
                                            <input class="form-control text-right" id="reg_price" type="text" placeholder="0.00" readonly>
                                        </div>
                                    </div>

                                    <hr class="my-1">
                                    <div class="form-group row mb-1">
                                        <span class="col-7 col-md-7 col-lg-7 form-lbl-text" for="text-input">Selling Price</span>
                                        <div class="col-5 col-md-5 col-lg-5">
                                            <input class="form-control text-right" id="sel_price" type="text" placeholder="0.00" >
                                        </div>
                                    </div>
                                    <div class="form-group row mb-1">
                                        <span class="col-7 col-md-7 col-lg-7 form-lbl-text" for="text-input">Quantity</span>
                                        <div class="col-5 col-md-5 col-lg-5">
                                            <input class="form-control text-right" id="qty" type="text" placeholder="0.00">
                                        </div>
                                    </div>
                                    <div class="form-group row mb-1">
                                        <span class="col-7 col-md-7 col-lg-7 form-lbl-text" for="text-input">Total Price</span>
                                        <div class="col-5 col-md-5 col-lg-5">
                                            <input class="form-control text-right" id="total_price" type="text" placeholder="0.00" readonly>
                                        </div>
                                    </div>
                                    <hr class="my-1">
                                    <div class="form-group row mb-1">
                                        <span class="col-7 col-md-7 col-lg-7 form-lbl-text" for="text-input">Volume Discount</span>
                                        <div class="col-5 col-md-5 col-lg-5">
                                            <input class="form-control text-right" id="volume_discount" type="text" placeholder="0.00" >
                                        </div>
                                    </div>
                                    <div class="form-group row mb-1">
                                        <span class="col-7 col-md-7 col-lg-7 form-lbl-text" for="text-input">Total Selling Price</span>
                                        <div class="col-5 col-md-5 col-lg-5">
                                            <input class="form-control text-right" id="total_selling_price" type="text" placeholder="0.00" readonly>
                                        </div>
                                    </div>
                                    <hr class="my-1">
                                    <div class="form-group row mb-1">
                                        <span class="col-3 col-md-2 col-lg-3 form-lbl-text" for="text-input">Share %</span>
                                        <div class="col-4 col-md-4 col-lg-4"> 
                                            <input class="form-control text-right" id="share_per" type="text" placeholder="5.00" value="5.00" readonly>
                                        </div>
                                        <div class="col-5 col-md-5 col-lg-5">
                                            <input class="form-control text-right" id="share_amount" type="text" placeholder="0.00" readonly>
                                        </div>
                                    </div>
                                    <div class="form-group row mb-2">
                                        <div class="col-7 col-md-7 col-lg-7">
                                            <button class="form-control btn-warning" data-toggle="modal" data-target="#payment_modal">Payment Type</button>
                                        </div>
                                        <div class="col-5 col-md-5 col-lg-5">
                                            <input class="form-control" id="pay_hdr_type" type="text" placeholder="CASH" readonly>
                                        </div>
                                    </div>
                                    <div class="form-group row mb-1">
                                      <div class="col-7 col-md-7 col-lg-7">
                                        <button class="form-control btn-danger" onclick="reset_input();">Cancel</button>
                                      </div>
                                      <div class="col-5 col-md-5 col-lg-5 div-btn-cancel">
                                        <button class="form-control btn-primary" id="add_item">Enter</button>
                                      </div>                
                                    </div>
                                </div>


                                <!-- For medium screen  -->
                                <div class="form-group row d-none d-md-block d-lg-none d-xl-none">
                                    <div class="col-xs-12 col-md-12">
                                        <span>Regular Price</span>
                                        <input class="form-control text-right" id="reg_price" type="text" placeholder="0.00" readonly>
                                    </div>

                                    <div class="col-xs-12 col-md-12">
                                        <span>Selling Price</span>
                                        <input class="form-control text-right" id="sel_price" type="text" placeholder="0.00" >
                                    </div>

                                    <div class="col-xs-12 col-md-12">
                                        <span>Quantity</span>
                                        <input class="form-control text-right" id="qty" type="text" placeholder="0.00">
                                    </div>

                                    <div class="col-xs-12 col-md-12">
                                        <span>Total Price</span>
                                        <input class="form-control text-right" id="total_price" type="text" placeholder="0.00" readonly>
                                    </div>

                                    <div class="col-xs-12 col-md-12">
                                        <span>Volume Discount</span>
                                        <input class="form-control text-right" id="volume_discount" type="text" placeholder="0.00" >
                                    </div>

                                    <div class="col-xs-12 col-md-12">
                                        <span>Total Selling Price</span>
                                        <input class="form-control text-right" id="total_selling_price" type="text" placeholder="0.00" readonly>
                                    </div>

                                    <div class="col-xs-12 col-md-12">
                                        <span class="pr-2">Share %</span>
                                        <div class="input-group">
                                            <div class="input-group-prepend share-wd">
                                                <input type="text" class="form-control text-right" id="share_per" type="text" placeholder="5.00" value="5.00" readonly>
                                            </div>
                                            <input type="text" class="form-control text-right" id="share_amount" type="text" placeholder="0.00" readonly>
                                        </div>
                                    </div>

                                    <div class="col-xs-12 col-md-12 pt-2">
                                        <input class="form-control" id="pay_hdr_type" type="text" placeholder="CASH" readonly>
                                    </div>

                                    <div class="col-xs-12 col-md-12 pt-2">
                                        <button class="btn btn-block btn-warning" data-toggle="modal" data-target="#payment_modal">Payment Type</button>
                                    </div>

                                    <div class="col-xs-12 col-md-12 pt-2">
                                        <button class="btn btn-block btn-danger" onclick="reset_input();">Cancel</button>
                                    </div>

                                    <div class="col-xs-12 col-md-12 pt-2">
                                        <button class="btn btn-block btn-primary" id="add_item">Enter</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- For medium screen -->
                    <div class="col-9 col-md-8 col-lg-8 d-none d-md-block" >
                        <div class="row">  
                            <div class="col-12 px-0">   
                                <div class="div-tbl-prod">
                                    <div class="col-12 pl-0">
                                        <div class="col-lg-12">
                                            <table class="table table-striped table-fixed fixed_header" id="tbl-products">
                                                <thead>
                                                    <tr>
                                                      <th class="d-xl-table-cell d-lg-none d-md-none d-sm-none text-left">PN</th>
                                                      <th>Product Name</th>
                                                      <th>Qty.</th>
                                                      <th>UM</th>
                                                      <th hidden>Regular Price</th>
                                                      <th>Selling Price</th>
                                                      <th hidden>Total Price</th>
                                                      <th hidden>Volume Discount</th>
                                                      <th>Total Selling Price</th>
                                                      <th hidden>Share Percent</th>
                                                      <th hidden>Share Amount</th>
                                                      <th hidden>Total Amount</th>
                                                      <th class="remove_hdr text-red text-center"><span class="fa fa-minus-circle"></span></th>
                                                    </tr>
                                                </thead>
                                                <tbody>                                                  
                                                <?php for ($i=1; $i <= 20; $i++) { ?>
                                                  <tr>
                                                    <td class="d-xl-table-cell d-lg-none d-md-none d-sm-none">PN <?php echo $i; ?></td>
                                                    <td>T-Shirt Red <?php echo $i; ?></td>
                                                    <td class="text-center">10<?php echo $i; ?></td>
                                                    <td class="text-center">pcs </td>
                                                    <td hidden>125 <?php echo $i; ?></td>
                                                    <td class="text-center">1,00<?php echo $i; ?></td>
                                                    <td class="text-center"><?php echo number_format("100".$i, 2); ?></td>
                                                    <td class="text-red text-center pl-5"><span class="fa fa-minus-circle"></span></td>
                                                  </tr>
                                                <?php } ?>
                                                </tbody>

                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row pb-2"> 
                            <div class="col-12">
                                <div class="div-total">
                                    <div class="row">
                                        <div class="col-3"> 
                                            <span>No. of Items. : <span id="no_of_items">0</span></span>
                                        </div>  
                                        <div class="col-9 pr-4">
                                            <div class="row pr-2">
                                                <div class="col-3 px-0"> 
                                                    <span>Sales Discount</span>
                                                </div>
                                                <div class="col-3"> 
                                                    <input type="text" class="form-control text-right" id="sales_discount" placeholder="0.00">
                                                </div>
                                                <div class="col-3 px-0"> 
                                                    <span>Total PHP</span>
                                                </div>
                                                <div class="col-3"> 
                                                    <input type="text" class="form-control text-right" placeholder="0.00" id="grand_total" readonly>    
                                                </div>
                                            </div>  
                                            <div class="row mt-1 pr-2"> 
                                                <div class="col-3 px-0"> 
                                                    <span>Total VAT Amount</span>
                                                </div>
                                                <div class="col-3"> 
                                                    <input type="text" class="form-control text-right" placeholder="0.00" id="vat_amount" readonly>  
                                                </div>
                                                <div class="col-3 px-0"> 
                                                    <span>Total Net of VAT</span>
                                                </div>
                                                <div class="col-3"> 
                                                    <input type="text" class="form-control text-right" placeholder="0.00" id="net_vat" readonly>
                                                </div>
                                            </div>
                                        </div>
                                    </div>       
                                    <div class="row">
                                        <div class="col-12">
                                            <div class="div-btn-save bottom pt-2 pr-2">  
                                                <div class="row">
                                                    <div class="col-6">
                                                        <button class="form-control btn-success" data-toggle="modal" data-target="#trans_modal" id="save_trans">Save</button>  
                                                    </div>  
                                                    <div class="col-6 pr-4"> 
                                                        <button class="form-control btn-info" data-toggle="modal" data-target="#preview_modal" onclick="preview_data();">Preview</button>
                                                    </div>
                                                </div>
                                            </div>                                              
                                        </div>
                                    </div>                   
                                </div>
                            </div>
                        </div>
                    </div>



                </div>
            </div>
        </div>
    </div>
</div>


<!-- Modal for Payment -->
<div class="modal fade" id="payment_modal" role="dialog">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5>Payment Details</h5>
      </div>

      <div class="modal-body">
        <div class="col-12 col-md-12 col-lg-12">
          <div class="form-group row">
            <div class="col-6 col-md-6 col-lg-6">
              <span>Payment Date</span>
            </div>
            <div class="col-6 col-md-6 col-lg-6">
              <input type="date" class="form-control" id="payment_date">
            </div>
          </div>

          <div class="form-group row">
            <div class="col-6 col-md-6 col-lg-6">
              <span>Payment Type</span>
            </div>
            <div class="col-6 col-md-6 col-lg-6">
              <select class="form-control border-black" id="payment_type">
              </select>
            </div>
          </div>

          <div class="form-group row">
            <div class="col-6 col-md-6 col-lg-6">
              <span>Bank Name</span>
            </div>
            <div class="col-6 col-md-6 col-lg-6">
              <select class="form-control border-black" id="bank_name">
                <option selected hidden></option>
              </select>
            </div>
          </div>

          <div class="form-group row">
            <div class="col-6 col-md-6 col-lg-6">
              <span>Check/Card No.</span>
            </div>
            <div class="col-6">
              <input type="text" class="form-control" id="check_no">
            </div>
          </div>

          <div class="form-group row">
            <div class="col-6 col-md-6 col-lg-6">
              <span>Check Date</span>
            </div>
            <div class="col-6">
              <input type="date" class="form-control" id="check_date">
            </div>
          </div>

          <div class="form-group row">
            <div class="col-6 col-md-6 col-lg-6">
              <span>Currency</span>
            </div>
            <div class="col-6 col-md-6 col-lg-6">
              <select class="form-control border-black" id="currency">
                
              </select>
            </div>
          </div>

          <div class="form-group row">
            <div class="col-6 col-md-6 col-lg-6">
              <span>Amount</span>
            </div>
            <div class="col-6 col-md-6 col-lg-6">
              <input type="text" class="form-control text-right" id="payment_amount" value="0.00">
            </div>
          </div>
        </div>
      </div>

      <div class="modal-footer">
        <div class="col-12 col-md-12 col-lg-12">
          <div class="form-group row">
            <div class="col-6 col-md-6 col-lg-6 left">
              <button class="btn btn-danger text-lg" data-dismiss="modal">Cancel</button>
            </div>
            <div class="col-6 col-md-6 col-lg-6 right">
              <button class="btn btn-warning text-lg" data-dismiss="modal">Continue</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- END Modal for Payment -->

<!-- Modal for Select Other Item -->
<div class="modal fade" id="select_item_modal" role="dialog">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5>Products / Services</h5>
      </div>

      <div class="modal-body">
        <div class="col-12">
          <div class="form-group row">
            <div class="col-3">
              <select class="form-control" id="item_category" style="height: 35px;">
                <option value="1">T-Shirt</option>
              </select>
            </div>
            <div class="col-9">
              <div class="input-group md-form form-sm form-2 pl-0">
                <input class="form-control" placeholder="Search" aria-label="Search" id="item_keyword" style="height: 35px;">
                <div class="input-group-append">
                  <span class="input-group-button">
                    <button class="btn btn-info btn-md" type="button">
                      <i class="fas fa-search text-grey" aria-hidden="true"></i>
                    </button>
                  </span>
                </div>
              </div>
            </div>
          </div>

          <div class="row">
            <div class="col-12" style="height: auto;">
              <div id="div-tbl-items">
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="modal-footer">
        <div class="col-12">
          <div class="row">
            <div class="col-9 text-right">
              <button class="btn btn-success text-lg" hidden><i class="fas fa-check"></i> Select</button>
            </div>
            <div class="col-3 text-right">
              <button class="btn btn-grey text-lg" data-dismiss="modal">Close</button>
            </div>            
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- END Modal for Select Other Item -->

  <!-- Modal for Preview -->
<div class="modal fade" id="preview_modal" role="dialog">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <div class="form-group row col-12">
          <div class="col-7">
            <h5>SALES TRANSACTION</h5>
          </div>
          <div class="col-5">
            <div class="col-12">
              <div class="row">
                <div class="col-6">
                  <span>DATE: </span>
                </div>
                <div class="col-6">
                  <span><?php echo date("m/d/Y"); ?></span>
                </div>
              </div>
            </div>
             <div class="col-12">
              <div class="row ">
                <div class="col-6">
                  <span>Outlet ID: </span>
                </div>
                <div class="col-6">
                  <span><?php echo $this->session->userdata("outlet_code"); ?></span>
                </div>
              </div>
            </div>
            <div class="col-12">
              <div class="row ">
                <div class="col-6">
                  <span>User ID: </span>
                </div>
                <div class="col-6">
                  <span>CAS01</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="modal-body">
        <div class="col-12">
          <div class="row">
            <div class="col-3">
              <span>Transaction No: </span>
            </div>
            <div class="col-3">
              <span id="mod_prev_trans_no"></span>
            </div>
          </div>
        </div>
        <div class="col-12">
          <div class="row">
            <div class="col-3">
              <span>Customer No: </span>
            </div>
            <div class="col-3">
              <span id="mod_prev_cust_code"></span>
            </div>
          </div>
        </div>
        <div class="col-12">
          <div class="row">
            <div class="col-3">
              <span>Customer Name: </span>
            </div>
            <div class="col-3">
              <span id="mod_prev_cust_name"></span>
            </div>
          </div>
        </div>
        <br>
        <div class="col-12">
          <div class="row">
            <div class="col-12" style="height: auto;" id="div-tbl-prev-items">
          </div>
          </div>
        </div>

        <div class="col-12">
          <div class="row">
            <div class="col-8"></div>
            <div class="col-4">
              <div class="row">
                <div class="col-6">
                  <span>Discount : </span>
                </div>
                <div class="col-6 px-5">
                  <span id="mod_prev_discount"> - </span>
                </div>
              </div>  
            </div>
          </div>

          <div class="row">
            <div class="col-8"></div>
            <div class="col-4">
              <div class="row">
                <div class="col-6">
                  <span>Total PHP : </span>
                </div>
                <div class="col-6 px-5">
                  <span id="mod_prev_grand_total">900.00</span>
                </div>
              </div>  
            </div>
          </div>
        </div>
      </div>

      <div class="modal-footer">
        <div class="col-12">
          <div class="form-group row right">
            <div class="col-6 ">
              <button class="btn btn-grey text-lg" data-dismiss="modal">Close</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- END Modal for Preview -->

<!-- Modal for Save Transaction -->
<div class="modal fade" id="trans_modal" role="dialog">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5>Transaction <span id="mod_trans_no"></span></h5>
      </div>

      <div class="modal-body">
        <div class="col-12">
          <div class="form-group row text-sales">
            <div class="col-6">
              <span>Payment Type</span>
            </div>
            <div class="col-6">
              <span id="mod_payment_type">CASH</span>
            </div>
          </div>

          <div class="form-group row">
            <div class="col-6">
              <span>Total Sales</span>
            </div>
            <div class="col-6">
              <span id="mod_total_sales">950.00</span>
            </div>
          </div>

          <div class="form-group row">
            <div class="col-6">
              <span>Discount</span>
            </div>
            <div class="col-6">
              <span id="mod_discount">50.00</span>
            </div>
          </div>

          <div class="form-group row">
            <div class="col-6">
              <span>Grand Total Sales</span>
            </div>
            <div class="col-6">
              <span class="text-date" id="mod_grand_total">900.00</span>
            </div>
          </div>

          <div class="form-group row">
            <div class="col-6">
              <span>Amount Paid</span>
            </div>
            <div class="col-6">
              <span class="text-date" id="mod_amount_paid">1,000.00</span>
            </div>
          </div>

          <div class="form-group row">
            <div class="col-6">
              <span>Change</span>
            </div>
            <div class="col-6">
              <span class="text-date" id="mod_change">100.00</span>
            </div>
          </div>

          <div class="form-group row">
            <div class="col-6">
              <span>Partner / Agent</span>
            </div>
            <div class="col-6">
              <span class="text-date" id="mod_partner">Francis</span>
            </div>
          </div>

          <div class="form-group row">
           <div class="col-3">
              <span>Share %:</span>
            </div>
             <div class="col-3 col-auto">
              <span>5 %</span>
            </div>
            <div class="col-5">
              <span class="text-date" id="mod_share">45.00</span>
            </div>
          </div>

          <div class="form-group row">
            <div class="col-12 text-center">
              <button class="btn btn-primary btn-block" onclick="window.location.reload();">OK</button>
            </div>
          </div>

        </div>
      </div>
    </div>
  </div>
</div>


</body>

