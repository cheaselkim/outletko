<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/application/product.css') ?>">
<script type="text/javascript" src="<?php echo base_url('js/application/master_data/product/product_entry.js') ?>"></script>
<script type="text/javascript" src="<?php echo base_url('js/application/master_data/product/product_edit.js') ?>"></script>
<body>

<div class="container-fluid pt-5">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-md-12">
                <div class="container">
                    <div class="form-group row">
                        <div class="col-xs-12 col-md-4 text-date">
                        <span>Edit Users Information</span>
                    </div>
                    </div>
                </div>
            </div>
        </div>

        <hr style="color: black;" class="my-2">

        <!-- Entry Product Master Data -->
        <div class="row">
            <div class="col-xs-12 col-md-12">
                <div class="col-xs-12 col-md-12 px-0">
                    <div class="form-group row">
                        <div class="col-xs-12 col-md-9">
                            
                            <div class="form-group row py-0 my-1">
                                <div class="col-xs-12 col-md-4">
                                    <span>Outlet No. <span class="required">*</span></span>
                                    <select class="form-control" id="outlet_no">
                                        <option value="0">All</option>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group row py-0 my-1">
                                <div class="col-xs-12 col-md-4">
                                    <span>Product No. <span class="required">*</span></span>
                                    <input type="text" class="form-control" id="product_no" data-id = "<?php echo $trans_id; ?>">
                                </div>
                                <div class="col-xs-12 col-md-4"></div>
                                <div class="col-xs-12 col-md-4">
                                    <span>Product Type <span class="required">*</span></span>
                                    <select class="form-control" id="product_type">
                                        <option></option>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group row py-0 my-1">
                                <div class="col-xs-12 col-md-12">
                                    <span>Product Name <span class="required">*</span></span>
                                    <input type="text" class="form-control" id="product_name">
                                </div>
                            </div>

                            <div class="form-group row py-0 my-1">
                                <div class="col-xs-12 col-md-12">
                                    <span>Product Specification <span class="required">*</span></span>
                                    <input type="text" class="form-control" id="product_specs">
                                </div>
                            </div>

                        </div>

                        <div class="col-xs-12 col-md-3">
                            <img id='img-upload' class="img-fluid img-thumbnail mx-auto d-block p-1 float-right text-center img-prod" />                            
                            <div class="input-group pl-4 ml-2">
                                <span class="input-group-btn pt-2 ml-1">
                                    <span class="btn btn-primary btn-file">
                                        Browse… <input type="file" id="imgInp">
                                    </span>
                                </span>
                                <span class="text-img ml-3"></span><br>

                            </div>
                            <div class="col-12 text-center pl-5">
                                <small class="text-muted ml-2">(ONLY .JPG, .JPEG, .PNG)</small>                                
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xs-12 col-md-12 px-0">

                    <div class="form-group row py-0 my-1">
                        <div class="col-xs-12 col-md-4">
                            <span>Brand</span>
                            <select class="form-control" id="product_brand">
                                <option hidden></option>
                                
                            </select>
                        </div>
                        <div class="col-xs-12 col-md-4">
                            <span>Model</span>
                            <select class="form-control" id="product_model">
                                <option hidden></option>
                                
                            </select>
                        </div>
                        <div class="col-xs-12 col-md-4">
                            <span>Category</span>
                            <select class="form-control" id="product_category">
                                <option hidden></option>
                                
                            </select>
                        </div>
                    </div>

                    <div class="form-group row py-0 my-1">
                        <div class="col-xs-12 col-md-4">
                            <span>Color <span class="required">*</span></span>
                            <select class="form-control" id="product_color"> 
                                <option hidden></option>
                                
                            </select>
                        </div>
                        <div class="col-xs-12 col-md-4">
                            <span>Size <span class="required">*</span></span>
                            <select class="form-control" id="product_size">
                                <option hidden></option>
                                
                            </select>
                        </div>
                        <div class="col-xs-12 col-md-4">
                            <span>Class</span>
                            <select class="form-control" id="product_class">
                                <option hidden></option>
                                
                            </select>
                        </div>
                    </div>

                    <div class="form-group row py-0 my-1">
                        <div class="col-xs-12 col-md-4">
                            <span>Re Order Level</span>
                            <select class="form-control" id="product_level">
                                <option hidden></option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                            </select>
                        </div>
                        <div class="col-xs-12 col-md-4">
                            <span>Stock Unit <span class="required">*</span></span>
                            <select class="form-control" id="product_stock_unit">
                                <option hidden></option>
                                
                            </select>
                        </div>
                        <div class="col-xs-12 col-md-4">
                            <span>Selling Price<span class="required">*</span></span>
                            <input type="text" class="form-control" id="selling_price">
                                
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <!-- END Entry Product Master Data -->

        <div class="row">
            <div class="col-xs-12 col-md-12">
                <div class="container">
                    <br>
                    <div class="form-group row">
                        <div class="col-xs-12 col-md-2"></div>
                        <div class="col-xs-12 col-md-4">
                            <button type="button" class="btn btn-block" id="update_product">Update</button>
                        </div>
                        <div class="col-xs-12 col-md-4">
                            <a href="<?php echo base_url(); ?>"><button type="button" class="btn btn-block">Cancel</button></a>
                        </div>
                        <div class="col-xs-12 col-md-2"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal for Save Products -->
<div class="modal fade" id="save_modal" role="dialog">
    <div class="modal-dialog modal-dialog-centered modal-md">
        <div class="modal-content">
            <div class="modal-body">
                <div class="col-xs-12 col-md-12">
                    <span>Product No. S000001 has been updated.</span>
                </div>
            </div>

            <div class="modal-footer">
                <div class="col-xs-12 col-md-4"></div>
                <div class="col-xs-12 col-md-4">
                    <button class="btn btn-grey btn-block">OK</button>
                </div>
                <div class="col-xs-12 col-md-4"></div>
            </div>
        </div>
    </div>
</div>
<!-- END Modal for Save Products -->

</body>


<script>
    $(document).ready( function() {
        $(document).on('change', '.btn-file :file', function() {
        var input = $(this),
            label = input.val().replace(/\\/g, '/').replace(/.*\//, '');
        input.trigger('fileselect', [label]);
        });

        $('.btn-file :file').on('fileselect', function(event, label) {
            
            var input = $(this).parents('.input-group').find(':text'),
                log = label;
            
            if( input.length ) {
                input.val(log);
            } else {
                if( log ) alert(log);
            }
        
        });
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                
                reader.onload = function (e) {
                    $('#img-upload').attr('src', e.target.result);
                }
                
                reader.readAsDataURL(input.files[0]);
            }
        }

        $("#imgInp").change(function(){
            readURL(this);
        });     
    });
</script>