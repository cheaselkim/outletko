<script type="text/javascript" src="<?php echo base_url() ?>js/application/master_data/supplier/supplier_edit.js"></script>
<body>
<input type="hidden" id="supplier_id" value="<?php echo $trans_id; ?>">
<div class="container-fluid pt-5">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-md-12">
                <div class="container">
                    <div class="form-group row">
                        <div class="col-xs-12 col-md-4">
                            <h5>Edit Supplier Information</h5>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <hr style="color: black;" class="my-2">

        <!-- Entry Supplier Information -->
        <div class="row">
            <div class="col-xs-12 col-md-12">
                <div class="col-xs-12 col-md-12">
                    <div class="form-group row">
                        <div class="col-xs-12 col-md-2">
                            <span>Supplier Code</span>
                            <input type="text" class="form-control" id="supp_code">
                        </div>
                        <div class="col-xs-12 col-md-6">
                            <span>Supplier Name</span>
                            <input type="text" class="form-control" id="supp_name">
                        </div>
                        <div class="col-xs-12 col-md-2">
                            <span>Supplier Type</span>
                            <select class="form-control" id="supp_type"></select>
                        </div>
                        <div class="col-xs-12 col-md-2">
                            <span>Supplier Status</span>
                            <select class="form-control" id="supp_status">
                                <option value="1">Active</option>
                                <option value="2">Inactive</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-xs-12 col-md-6">
                            <span>Address</span>
                            <input type="text" class="form-control" id="supp_address">
                        </div>
                        <div class="col-xs-12 col-md-3">
                            <span>City</span>
                            <input type="text" class="form-control" id="supp_city">
                            <input type="hidden" class="form-control" id="supp_city_id" readonly>
                        </div>
                        <div class="col-xs-12 col-md-3">
                            <span>Province</span>
                            <input type="text" class="form-control" id="supp_province" readonly>
                            <input type="hidden" class="form-control" id="supp_province_id" readonly>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-xs-12 col-md-6">
                            <span>Factory Address</span>
                            <input type="text" class="form-control" id="factory_add">
                        </div>
                        <div class="col-xs-12 col-md-2">
                            <span>Region</span>
                            <input type="text" class="form-control" id="supp_region">
                        </div>
                        <div class="col-xs-12 col-md-2">
                            <span>Country</span>
                            <input type="text" class="form-control" id="supp_country">
                        </div>
                        <div class="col-xs-12 col-md-2">
                            <span>Zip Code</span>
                            <input type="text" class="form-control" id="supp_zip_code">
                        </div>
                    </div>
                </div>

                <div class="col-xs-12 col-md-12">

                    <div class="form-group row">
                        <div class="col-xs-12 col-md-3">
                            <span>Nature of Business</span>
                            <select class="form-control" id="nat_bus"></select>
                        </div>
                        <div class="col-xs-12 col-md-3">
                            <span>Form of Organization</span>
                            <select class="form-control" id="form_org"></select>
                        </div>
                        <div class="col-xs-12 col-md-3">
                            <span>Classification</span>
                            <select class="form-control" id="classif"></select>
                        </div>
                        <div class="col-xs-12 col-md-3">
                            <span>Date Organized</span>
                            <input type="date" class="form-control" id="date_org">
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-xs-12 col-md-4">
                            <span>Contact Person</span>
                            <input type="text" class="form-control" id="contact_person">
                        </div>
                        <div class="col-xs-12 col-md-4">
                            <span>Contact No.</span>
                            <input type="text" class="form-control" id="contact_no">
                        </div>
                        <div class="col-xs-12 col-md-4">
                            <span>Email Address</span>
                            <input type="text" class="form-control" id="email_add">
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-xs-12 col-md-4">
                            <span>Fax No.</span>
                            <input type="text" class="form-control" id="fax">
                        </div>
                        <div class="col-xs-12 col-md-4">
                            <span>Facebook</span>
                            <input type="text" class="form-control" id="facebook">
                        </div>
                        <div class="col-xs-12 col-md-4">
                            <span>Website</span>
                            <input type="text" class="form-control" id="website">
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <!-- END Entry Supplier Information -->

        <div class="row">
            <div class="col-xs-12 col-md-12">
                <div class="container">
                    <br>
                    <div class="form-group row">
                        <div class="col-xs-12 col-md-2"></div>
                        <div class="col-xs-12 col-md-4">
                            <button type="button" class="btn btn-block" id="save">Update</button>
                        </div>
                        <div class="col-xs-12 col-md-4">
                            <button type="button" class="btn btn-block">Quit</button>
                        </div>
                        <div class="col-xs-12 col-md-2"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal for Save Supplier Info -->
<div class="modal fade" id="save_modal" role="dialog">
    <div class="modal-dialog modal-dialog-centered modal-md">
        <div class="modal-content">
            <div class="modal-body">
                <div class="col-xs-12 col-md-12">
                    <span>Supplier 00001 Succesfully Updated.</span>
                </div>
            </div>

            <div class="modal-footer">
                <div class="col-xs-12 col-md-4"></div>
                <div class="col-xs-12 col-md-4">
                    <button class="btn btn-grey btn-block">OK</button>
                </div>
                <div class="col-xs-12 col-md-4"></div>
            </div>
        </div>
    </div>
</div>
<!-- END Modal for Save Supplier Info -->

</body>
