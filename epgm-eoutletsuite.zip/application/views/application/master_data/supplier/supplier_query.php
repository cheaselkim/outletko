 <script type="text/javascript" src="<?php echo base_url() ?>js/application/master_data/supplier/supplier_query.js"></script>
<body>
<input type="hidden" id="supplier_func" value="<?php echo $function; ?>">
<div class="container-fluid pt-3">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-md-12">
                <div class="row">
                    <div class="col-xs-12 col-md-4 text-date">
                        <span>Query Supplier's Information</span>
                    </div>
                </div>
            </div>
        </div>

        <hr style="color: black;" class="my-2">

        <div class="row">
            <div class="col-xs-12 col-md-12">
                <div class="container">
                    <div class="form-group row">
                        <div class="col-xs-12 col-md-4"></div>
                        <div class="col-xs-12 col-md-4"></div>
                        <div class="col-xs-12 col-md-4">
                            <span>Search</span>
                            <div class="input-group">
                                <input class="form-control" id="search_box">
                                <div class="input-group-append">
                                    <span class="input-group-text show_cur_pass">
                                    <button id="search"><i class="fa fa-search" ></i></button>
                                    </span>
                                </div>
                            </div>

                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col-xs-2 col-md-12" id="query-table">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


</body>

