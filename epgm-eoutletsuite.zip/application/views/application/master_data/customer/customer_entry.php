<script type="text/javascript" src="<?php echo base_url() ?>js/application/master_data/customer/customer_entry.js"></script>
<body>

<div class="container-fluid pt-5">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-md-12">
                <div class="container">
                    <div class="form-group row">
                        <div class="col-xs-12 col-md-4">
                            <h5>Customer Information</h5>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <hr style="color: black;" class="my-2">

        <!-- Entry Customer Information -->
        <div class="row">
            <div class="col-xs-12 col-md-12">
                <div class="col-xs-12 col-md-12">
                    <div class="form-group row">
                        <div class="col-xs-12 col-md-2">
                            <span>Outlet No. <span class="required">*</span></span>
                            <select class="form-control" id="outlet_no">
                                <option value="0">All</option>
                            </select>
                        </div>
                        <div class="col-xs-12 col-md-2">
                            <span>Customer No. <span class="required">*</span></span>
                            <input type="text" class="form-control" id="cust_id">
                        </div>
                        <div class="col-xs-12 col-md-6">
                            <span>Customer Name <span class="required">*</span></span>
                            <input type="text" class="form-control" id="cust_name">
                        </div>
                        <div class="col-xs-12 col-md-2">
                            <span>Customer Type <span class="required">*</span></span>
                            <select class="form-control" id="cust_type">
                                <option value="0" hidden></option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-xs-12 col-md-2">
                            <span>Customer Status</span>
                            <select class="form-control" id="cust_status">
                                <option value="1">Active</option>
                                <option value="2">Inactive</option>
                            </select>
                        </div>
                        <div class="col-xs-12 col-md-7">
                            <span>Address <span class="required">*</span></span>
                            <input type="text" class="form-control" id="cust_address">
                        </div>
                        <div class="col-xs-12 col-md-3">
                            <span>Town/City <span class="required">*</span></span>
                            <input type="text" class="form-control" id="cust_city">
                            <input type="hidden" class="form-control" id="cust_city_id" readonly>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-xs-12 col-md-3">
                            <span>Province</span>
                            <input type="text" class="form-control" id="cust_province" readonly>
                            <input type="hidden" class="form-control" id="cust_province_id" readonly>
                        </div>
                        <div class="col-xs-12 col-md-3">
                            <span>Country <span class="required">*</span></span>
                            <input type="text" class="form-control" id="cust_country" value="Philippines" >
                        </div>
                        <div class="col-xs-12 col-md-2">
                            <span>Zip Code</span>
                            <input type="text" class="form-control" id="cust_zip_code">
                        </div>
                        <div class="col-xs-12 col-md-4">
                            <span>Industry</span>
                            <input type="text" class="form-control" id="industry">
                        </div>
                    </div>
                </div>

                <div class="col-xs-12 col-md-12">
                    <div class="form-group row">
                        <div class="col-xs-12 col-md-4">
                            <span>Contact Person <span class="required">*</span></span>
                            <input type="text" class="form-control" id="contact_person">
                        </div>
                        <div class="col-xs-12 col-md-4">
                            <span>Contact No. <span class="required">*</span></span>
                            <input type="text" class="form-control" id="contact_no">
                        </div>
                        <div class="col-xs-12 col-md-4">
                            <span>Email Address</span>
                            <input type="text" class="form-control" id="email_add">
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-xs-12 col-md-3">
                            <span>Website</span>
                            <input type="text" class="form-control" id="website">
                        </div>
                        <div class="col-xs-12 col-md-3">
                            <span>Fax No.</span>
                            <input type="text" class="form-control" id="fax">
                        </div>
                        <div class="col-xs-12 col-md-3">
                            <span>Tax No.</span>
                            <input type="text" class="form-control" id="tax">
                        </div>
                        <div class="col-xs-12 col-md-3">
                            <span>Credit Limit</span>
                            <input type="text" class="form-control" id="credit_limit">
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <!-- END Entry Customer Information -->

        <div class="row">
            <div class="col-xs-12 col-md-12">
                <div class="container">
                    <br>
                    <div class="form-group row">
                        <div class="col-xs-12 col-md-2"></div>
                        <div class="col-xs-12 col-md-4">
                            <button type="button" class="btn btn-block" id="save">Save</button>
                        </div>
                        <div class="col-xs-12 col-md-4">
                            <button type="button" class="btn btn-block">Quit</button>
                        </div>
                        <div class="col-xs-12 col-md-2"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal for Save Customer Info -->
<div class="modal fade" id="save_modal" role="dialog">
    <div class="modal-dialog modal-dialog-centered modal-md">
        <div class="modal-content">
            <div class="modal-body">
                <div class="col-xs-12 col-md-12">
                    <span>New Customer Succesfully Added.</span>
                </div>
            </div>

            <div class="modal-footer">
                <div class="col-xs-12 col-md-4"></div>
                <div class="col-xs-12 col-md-4">
                    <button class="btn btn-grey btn-block">OK</button>
                </div>
                <div class="col-xs-12 col-md-4"></div>
            </div>
        </div>
    </div>
</div>
<!-- END Modal for Save Customer Info -->

</body>
