<script type="text/javascript" src="<?php echo base_url() ?>js/application/users/user_account_edit.js"></script>

<div class="container-fluid pt-3">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-md-12">
                <div class="row">
                    <div class="col-xs-12 col-md-4 text-date">
                        <span>Sales Force</span>
                    </div>
                </div>
            </div>
        </div>

        <hr style="color: black;" class="my-2">

        <div class="row">
            <div class="col-xs-12 col-md-12">
                <div class="container">
                    <div class="form-group row">
                        <div class="col-lg-6 col-md-6 col-sm-12">
                            <span>Last Name <span class="required">*</span></span>
                            <input class="form-control" id="last_name">
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-12"></div>
                        <div class="col-lg-3 col-md-3 col-sm-12">
                            <span>Status</span>
                            <input type="text" class="form-control" id="status" readonly>
                        </div>
                    </div>                            
                    <div class="form-group row">
                        <div class="col-lg-6 col-md-6 col-sm-12">
                            <span>First Name <span class="required">*</span></span>
                            <input class="form-control" id="first_name">
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-12"></div>
                        <div class="col-lg-3 col-md-3 col-sm-12">
                            <span>Type <span class="required">*</span></span>
                            <input type="text" class="form-control" id="sales_force_type" readonly>
                        </div>
                    </div>                            
                    <div class="form-group row">
                        <div class="col-lg-6 col-md-6 col-sm-12">
                            <span>Middle Name <span class="required">*</span></span>
                            <input class="form-control" id="mid_name">
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-12"></div>
                        <div class="col-lg-3 col-md-3 col-sm-12">
                            <span>Nickname</span>
                            <input type="text" class="form-control" id="nick_name">
                        </div>
                    </div>                            
                    <div class="form-group row">
                        <div class="col-lg-6 col-md-6 col-sm-12">
                            <span>Email <span class="required">*</span></span>
                            <input class="form-control" id="email">
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-12"></div>
                        <div class="col-lg-3 col-md-3 col-sm-12">
                            <span>Account ID</span>
                            <input type="text" class="form-control" id="account_id" readonly>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <hr style="color: black;" class="my-2">

        <div class="row">
            <div class="col-xs-12 col-md-12">
                <div class="container">

                    <div class="form-group row">
                        <div class="col-xs-12 col-md-4">
                            <span>Position</span>
                            <input class="form-control" id="position" readonly>
                        </div>
                        <div class="col-xs-12 col-md-4">
                            <span>Date Started</span>
                            <input type="date" class="form-control" id="date_start" readonly>
                        </div>
                        <div class="col-xs-12 col-md-4">
                            <span>Monthly Quota</span>
                            <input type="text" class="form-control text-right" id="monthly_quota" value="0" readonly>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-xs-12 col-md-4" hidden>
                            <span>Hierarchy</span>
                            <input class="form-control" id="hierarchy">
                        </div>
                        <div class="col-xs-12 col-md-4" hidden>
                            <span>Type of Share</span>
                            <input class="form-control" id="share_type">
                        </div>
                        <div class="col-xs-12 col-md-4">
                            <span>Outlet No/Area</span>
                            <input type="text" class="form-control" id="outlet"  readonly>
                        </div>
                        <div class="col-xs-12 col-md-4">
                            <span>% of Amount (PHP) </span>
                            <input type="text" class="form-control text-right" id="share" value="0" readonly>
                        </div>
                        <div class="col-xs-12 col-md-4">
                            <span>Salary Allowance (PHP)</span>
                            <input class="form-control text-right" id="salary" value="0" readonly>
                        </div>
                    </div>

                    <div class="form-group row">

                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-xs-12 col-md-12 pt-3">
                <div class="container">
                    <div class="form-group row">
                        <div class="col-xs-12 col-md-2"></div>
                        <div class="col-xs-12 col-md-4">
                            <button type="button" class="btn btn-block btn-primary" id="save">Save</button>
                        </div>
                        <div class="col-xs-12 col-md-4">
                            <a href="<?php echo base_url(); ?>" class="btn btn-danger btn-block">Cancel</a>
                        </div>
                        <div class="col-xs-12 col-md-2"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


</body>

