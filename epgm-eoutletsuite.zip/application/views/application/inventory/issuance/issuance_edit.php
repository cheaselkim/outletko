<script type="text/javascript" src="<?php echo base_url('js/application/inventory/issue/issue_edit.js') ?>"></script>
<body>
<input type="hidden" id="tbl_item_row">
<div class="container-fluid pt-2">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-md-12">
                <div class="row">
                    <div class="col-xs-12 col-md-4 pt-3">
                        <h3>Issuance Inventory</h3>
                    </div>
                </div>
            </div>
        </div>

        <hr style="color: black;" class="mt-0">

        <!-- Receiving Entry -->
        <div class="row">
            <div class="col-xs-12 col-md-12">
                <div class="container">
                    <div class="form-group row">
                        <div class="col-xs-12 col-md-4 px-1">
                            <span>Issuance No.</span>
                            <input class="form-control" id="issue_no" data-id = "<?php echo $trans_id ?>">
                        </div>
                        <div class="col-xs-12 col-md-4 px-1">
                            <span>Issuance Date</span>
                            <input type="date" class="form-control" id="issue_date">
                        </div>
                        <div class="col-xs-12 col-md-4 px-1">
                            <span>Transaction Type</span>
                            <select class="form-control" id="trans_type">
                                <option value="5">Purchase Replacement</option>
                                <option value="6">Sample Request</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-xs-12 col-md-2 px-1">
                            <span>Recipient Code</span>
                            <input class="form-control" id="recipient_code" data-id = "">
                        </div>
                        <div class="col-xs-12 col-md-5 px-1">
                            <span>Recipient Name</span>
                            <input class="form-control" id="recipient_name">
                        </div>
                        <div class="col-xs-12 col-md-2 px-1">
                            <span>Ref Trans No.</span>
                            <input class="form-control" id="trans_no">
                        </div>
                        <div class="col-xs-12 col-md-3 px-1 ">
                            <span>Ref Trans Date</span>
                            <input type="Date" class="form-control" id="trans_date">
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-xs-12 col-md-8 px-1">
                            <span>Purpose</span>
                            <input class="form-control" id="purpose">
                        </div>
                        <div class="col-xs-12 col-md-4 px-1">
                            <span>Issuing Outlet</span>
                            <input class="form-control" id="issue_outlet" data-id="" readonly="">
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-xs-12 col-md-12 px-1">
                <div class="container">
                    <hr style="color: black;" class="my-2">

                    <div class="form-group row">
                        <div class="col-xs-12 col-md-6"></div>
                        <div class="col-xs-12 col-md-2">
                            <button class="btn btn-block btn-add">Add Item</button>
                        </div>
                        <div class="col-xs-12 col-md-2">
                            <button class="btn btn-block btn-exit">Exit</button>
                        </div>
                        <div class="col-xs-12 col-md-2">
                            <button class="btn btn-block" id="enter_item">Enter</button>
                        </div>
                    </div>                                    
                </div>
            </div>            
        </div>

        <!-- Product Details Entry -->
        <div class="row prod_entry collapse hide">
            <div class="col-xs-12 col-md-12">
                <div class="col-xs-12 col-md-12">
                    <div class="form-group row">
                        <div class="col-xs-12 col-md-8">
                            
                            <div class="form-group row">
                                <div class="col-xs-12 col-md-4 px-1">
                                    <span>Product No.</span>
                                    <input class="form-control" id="prod_no">
                                </div>
                                <div class="col-xs-12 col-md-8 px-1">
                                    <span>Product Name</span>
                                    <input class="form-control" id="prod_name">
                                </div>
                            </div>

                            <div class="form-group row">
                                <div class="col-xs-12 col-md-4 px-1" >
                                    <span>Product Type</span>
                                    <input class="form-control" id="product_type"  readonly>
                                </div>
                                <div class="col-xs-12 col-md-8 px-1">
                                    <span>Product Specification</span>
                                    <input class="form-control" id="product_specs" readonly>
                                </div>
                            </div>

                        </div>

                        <div class="col-xs-12 col-md-4">
                            <img id='img-upload' class="rounded mx-auto d-block pt-3" />
                            <div class="input-group">
                                <span class="input-group-btn">
                                    <span class="btn btn-default btn-file">
                                        Browse… <input type="file" id="imgInp" id="imgInp" disabled="">
                                    </span>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xs-12 col-md-12">

                    <div class="form-group row">
                        <div class="col-xs-12 col-md-3 px-1">
                            <span>Brand</span>
                            <input class="form-control" id="product_brand" readonly>
                        </div>
                        <div class="col-xs-12 col-md-3 px-1">
                            <span>Model</span>
                            <input class="form-control"id="product_model" readonly>
                        </div>
                        <div class="col-xs-12 col-md-3 px-1" >
                            <span>Category</span>
                            <input class="form-control" id="product_category" readonly>
                        </div>
                        <div class="col-xs-12 col-md-3 px-1">
                            <span>Issued Qty</span>
                            <input class="form-control" id="qty">
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-xs-12 col-md-4 px-1">
                            <span>Color</span>
                            <input class="form-control" id="product_color" readonly>
                        </div>
                        <div class="col-xs-12 col-md-4 px-1">
                            <span>Size</span>
                            <input class="form-control" id="product_class" readonly>
                        </div>
                        <div class="col-xs-12 col-md-4 px-1">
                            <span>Class</span>
                            <input class="form-control" id="product_size" readonly>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <!-- END Product Details Entry -->

        <br>

        <!-- Table for Product Details Entry -->
        <div class="row">
            <div class="col-xs-12 col-md-12 px-3">
                <div class="container">
                    <div class="form-group row">
                        <table class="table table-striped table-responsive"" id="tbl-products">
                            <thead>
                                <tr>
                                    <th style="width: 8%;">Product No</th>    
                                    <th style="width: 28%;">Product Name</th>
                                    <th style="width: 16%;">Unit</th>
                                    <th style="width: 18%;">On Hand</th>
                                    <th style="width: 20%;">Issued Qty</th>
                                    <th style="width: 15%;">Currency</th>
                                    <th style="width: 2%;">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- END Table for Product Details Entry -->
 
        <div class="row">
            <div class="col-xs-12 col-md-12">
                <div class="container">
                    <div class="form-group row">
                        <div class="col-xs-12 col-md-2"></div>
                        <div class="col-xs-12 col-md-4">
                            <button type="button" class="btn btn-block" id="save">Save</button>
                        </div>
                        <div class="col-xs-12 col-md-4">
                            <button type="button" class="btn btn-block">Cancel</button>
                        </div>
                        <div class="col-xs-12 col-md-2"></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- END Receiving Entry -->
    </div>
</div>

<!-- Modal for Saving Receiving Product -->
<div class="modal fade" id="save_modal" role="dialog">
    <div class="modal-dialog modal-dialog-centered modal-md">
        <div class="modal-content">
            <div class="modal-body">
                <div class="col-xs-12 col-md-12">
                    <span>Issuance No. S000001 has been saved.</span>
                </div>
            </div>

            <div class="modal-footer">
                <div class="col-xs-12 col-md-4"></div>
                <div class="col-xs-12 col-md-4">
                    <button class="btn btn-grey btn-block">OK</button>
                </div>
                <div class="col-xs-12 col-md-4"></div>
            </div>
        </div>
    </div>
</div>
<!-- END Modal for Saving Receiving Product -->

</body>

<script>
    $(document).ready( function() {
        $(document).on('change', '.btn-file :file', function() {
        var input = $(this),
            label = input.val().replace(/\\/g, '/').replace(/.*\//, '');
        input.trigger('fileselect', [label]);
        });

        $('.btn-file :file').on('fileselect', function(event, label) {
            
            var input = $(this).parents('.input-group').find(':text'),
                log = label;
            
            if( input.length ) {
                input.val(log);
            } else {
                //if( log ) alert(log);
            }
        
        });
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                
                reader.onload = function (e) {
                    $('#img-upload').attr('src', e.target.result);
                }
                
                reader.readAsDataURL(input.files[0]);
            }
        }

        $("#imgInp").change(function(){
            readURL(this);
        });    

        $(".btn-add").click(function(){
            $(".prod_entry").collapse('show');
        });
        $(".btn-exit").click(function(){
            $(".prod_entry").collapse('hide');
        }); 

    });

    
</script>

