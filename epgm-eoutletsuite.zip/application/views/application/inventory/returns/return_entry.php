<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/application/inventory.css') ?>">
<script type="text/javascript" src="<?php echo base_url('js/application/inventory/return/return_entry.js') ?>"></script>
<input type="hidden" id="tbl_item_row">

<div class="container-fluid pt-2">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-md-12">
                <div class="row">
                    <div class="col-xs-12 col-md-4 pt-3">
                        <h3>Return Inventory</h3>
                    </div>
                </div>
            </div>
        </div>

        <hr style="color: black;" class="mt-0">


        <!-- Receiving Entry -->
        <div class="row">
            <div class="col-xs-12 col-md-12">
                <div class="container text-sales">
                    <div class="form-group row">
                        <div class="col-8">
                            <div class="form-group row mb-0">
                                <div class="col-xs-12 col-md-3 px-1">
                                    <span>Return No. <span class="required">*</span></span>
                                    <input class="form-control txt-box-text-size" id="return_no">
                                </div>
                                <div class="col-xs-12 col-md-3 px-1">
                                    <span>Return Date <span class="required">*</span></span>
                                    <input type="date" class="form-control txt-box-text-size" id="return_date" value="<?php echo date("Y-m-d") ?>">
                                </div>
                                <div class="col-xs-12 col-md-6 px-1">
                                    <span>Transaction Type <span class="required">*</span></span>
                                    <select class="form-control txt-box-text-size" id="tran_type">
                                        <option>Purchase Returns</option>
                                        <option>Transfer</option>
                                    </select>
                                </div>                                 
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="form-group row mb-0">  
                                <div class="col-xs-12 col-md-6 px-1 ml-auto">
                                    <span>Source Outlet</span>
                                    <input type="text" class="form-control txt-box-text-size" value="<?php echo $this->session->userdata('outlet_code') ?>" readonly>   
                                </div> 
                            </div>                               
                        </div>                        
                    </div>

                    <div class="form-group row">
                        <input type="hidden" id="recipient_id">
                        <input type="hidden" id="recipient_type">
                        <div class="col-xs-12 col-md-2 px-1">
                            <span>Returned To Code </span>
                            <input class="form-control txt-box-text-size" id="recipient_code">
                        </div>
                        <div class="col-xs-12 col-md-6 px-1">
                            <span>Returned To Name <span class="required">*</span></span>
                            <input class="form-control txt-box-text-size" id="recipient_name">
                        </div>
                        <div class="col-xs-12 col-md-2 px-1">
                            <span>Ref Trans No.</span>
                            <input class="form-control txt-box-text-size" id="ref_trans_no">
                        </div>
                        <div class="col-xs-12 col-md-2 px-1">
                            <span>Ref Trans Date</span>
                            <input type="Date" class="form-control txt-box-text-size" id="ref_trans_date" value="<?php echo date('Y-m-d') ?>">
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-xs-12 col-md-12 px-1">
                            <span>Reason</span>
                            <input class="form-control" id="reason">
                        </div>
                    </div>
                </div>

            </div>
        </div>

        <div class="row">
            <div class="col-xs-12 col-md-12 px-1">
                <div class="container">
                    <hr style="color: black;" class="my-2">

                    <div class="form-group row py-2 mx-0 bg-button">
                        <div class="col-xs-12 col-md-6"></div>
                        <div class="col-xs-12 col-md-2">
                            <button class="btn btn-block btn-danger btn-exit">Exit</button>
                        </div>
                        <div class="col-xs-12 col-md-2">
                            <button class="btn btn-block btn-primary btn-enter" id="enter_item">Enter</button>
                        </div>
                        <div class="col-xs-12 col-md-2">
                            <button class="btn btn-block btn-add btn-success">Add Item</button>
                        </div>
                    </div>                                      
                </div>
            </div>            
        </div>

        <!-- Product Details Entry -->
        <div class="row prod_entry collapse hide"> <!--   -->
            <div class="col-xs-12 col-md-12 text-sales">
                <div class="col-xs-12 col-md-12">
                    <div class="form-group row">
                        <div class="col-xs-12 col-md-12">
                            
                            <div class="form-group row">
                                <div class="col-xs-12 col-md-3 px-1">
                                    <span>Product No.</span>
                                    <input class="form-control txt-box-text-size" id="prod_no">
                                </div>
                                <div class="col-xs-12 col-md-9 px-1">
                                    <span>Product Name</span>
                                    <input class="form-control txt-box-text-size" id="prod_name">
                                </div>
                            </div>

                            <div class="form-group row" hidden>
                                <div class="col-xs-12 col-md-4 px-1" >
                                    <span>Product Type</span>
                                    <input class="form-control txt-box-text-size" id="product_type"  readonly>
                                </div>
                                <div class="col-xs-12 col-md-8 px-1">
                                    <span>Product Specification</span>
                                    <input class="form-control txt-box-text-size" id="product_specs" readonly>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>

                <div class="col-xs-12 col-md-12">
                    <div class="row">
                        <div class="col-xs-12 col-md-2 px-1" >
                            <span>Qty On Hand</span>
                            <input class="form-control txt-box-text-size text-right" id="onhand_qty"  readonly>
                        </div>                        
                        <div class="col-xs-12 col-md-2 px-1">
                            <span>Qty to Return</span>
                            <input class="form-control txt-box-text-size text-right" id="qty">
                        </div>
                        <div class="col-xs-12 col-md-1 px-1">
                            <span>Unit</span>
                            <input class="form-control txt-box-text-size" id="prod_unit" readonly>
                        </div>
                        <div class="col-xs-12 col-md-1 px-1">
                            <span>Currency</span>
                            <input class="form-control txt-box-text-size" id="prod_curr" readonly>
                        </div>
                        <div class="col-xs-12 col-md-3 px-1">
                            <span>Selling Unit Price</span>
                            <input class="form-control text-right txt-box-text-size" id="prod_price" readonly>
                        </div>
                        <div class="col-xs-12 col-md-3 px-1">
                            <span>Total Amount</span>
                            <input class="form-control text-right txt-box-text-size" id="prod_total_price" readonly>
                        </div>
                    </div>
                </div>

                <div class="col-xs-12 col-md-12" hidden>

                    <div class="form-group row">
                        <div class="col-xs-12 col-md-3 px-1">
                            <span>Brand</span>
                            <input class="form-control" id="product_brand" readonly>
                        </div>
                        <div class="col-xs-12 col-md-3 px-1">
                            <span>Model</span>
                            <input class="form-control" id="product_model" readonly>
                        </div>
                        <div class="col-xs-12 col-md-3 px-1" >
                            <span>Category</span>
                            <input class="form-control" id="product_category" readonly>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-xs-12 col-md-4 px-1">
                            <span>Color</span>
                            <input class="form-control" id="product_color" readonly>
                        </div>
                        <div class="col-xs-12 col-md-4 px-1">
                            <span>Size</span>
                            <input class="form-control" id="product_class" readonly>
                        </div>
                        <div class="col-xs-12 col-md-4 px-1">
                            <span>Class</span>
                            <input class="form-control" id="product_size" readonly>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <!-- END Product Details Entry -->

        <br>

        <!-- Table for Product Details Entry -->
        <div class="row">
            <div class="col-xs-12 col-md-12 px-3">
                <div class="container">
                    <div class="form-group row">
                        <table class="table table-striped table-fixed fixed_header text-table" id="tbl-products">
                            <thead class="w-100">
                                <tr>
                                    <th style="width: 1.5%;" class="text-left">Product No</th>
                                    <th style="width: 3%;" class="text-left">Product Name</th>
                                    <th style="width: 1.5%;" class="text-left">Qty</th>
                                    <th style="width: 1%;" class="text-left">Unit</th>
                                    <th style="width: 1.1%;" class="text-left">Currency</th>
                                    <th style="width: 1.5%;" class="text-left">Unit Price</th>
                                    <th style="width: 2%;" class="text-left">Total Amount</th>
                                    <th style="width: 1%;" class="text-center">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr hidden>
                                    <td class="text-left" style="width: 1.5%;">S00001</td>
                                    <td class="text-left" style="width: 3%;">Joey Nubuck Sneakers</td>
                                    <td class="text-left" style="width: 1.5%;">20,000.00</td>
                                    <td class="text-left" style="width: 1%;">pc/s</td>
                                    <td class="text-left" style="width: 1.1%;">PHP</td>
                                    <td class="text-left" style="width: 1.5%;">1,500.00</td>
                                    <td class="text-left" style="width: 2%;">1,000,000.00</td>
                                    <td class="text-center" style="width: 1%;"><span class="text-red"><i class="fa fa-minus-circle"></i></span></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- END Table for Product Details Entry -->
 
        <div class="row mb-4">
            <div class="col-xs-12 col-md-12">
                <div class="container">
                    <div class="form-group row">
                        <div class="col-xs-12 col-md-2"></div>
                        <div class="col-xs-12 col-md-4">
                            <button type="button" class="btn btn-block btn-success cust-text" id="save">Save</button>
                        </div>
                        <div class="col-xs-12 col-md-4">
                            <button type="button" class="btn btn-block btn-danger cust-text">Cancel</button>
                        </div>
                        <div class="col-xs-12 col-md-2"></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- END Receiving Entry -->
    </div>
</div>

<!-- Modal for Saving Receiving Product -->
<div class="modal fade" id="save_modal" role="dialog">
    <div class="modal-dialog modal-dialog-centered modal-md">
        <div class="modal-content">
            <div class="modal-body">
                <div class="col-xs-12 col-md-12">
                    <span>Return No. S000001 has been saved.</span>
                </div>
            </div>

            <div class="modal-footer">
                <div class="col-xs-12 col-md-4"></div>
                <div class="col-xs-12 col-md-4">
                    <button class="btn btn-grey btn-block">OK</button>
                </div>
                <div class="col-xs-12 col-md-4"></div>
            </div>
        </div>
    </div>
</div>
<!-- END Modal for Saving Receiving Product -->


