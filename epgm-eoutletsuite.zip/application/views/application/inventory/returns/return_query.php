<script type="text/javascript" src="<?php echo base_url('js/application/inventory/return/return_query.js') ?>"></script>
<input type="hidden" id="app_func" value="<?php echo $function; ?>">

<div class="container-fluid pt-3">
    <div class="container">

        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <h1>Return Query</h1>
            </div>            
        </div>

        <hr style="color: black;" class="my-1">

        <div class="row pt-3">
            <div class="col-xs-12 col-md-12">
                <div class="container">
                    <div class="form-group row">
                        <div class="col-xs-12 col-md-4 px-1">
                            <input type="text" class="form-control" placeholder="Search Transfer No, Recepient Name" id="keyword">
                        </div>

                        <div class="col-xs-12 col-md-1 px-1">
                            <button class="btn btn-primary btn-block" id="search">Search</button>
                        </div>

                    </div>
                </div>
            </div>
        </div>


        <div class="row">
            <div class="col-xs-2 col-md-12 pb-5" id="div-query">
            </div>
        </div>
    </div>
</div>
