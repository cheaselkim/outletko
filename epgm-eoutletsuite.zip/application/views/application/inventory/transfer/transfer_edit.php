<script type="text/javascript" src="<?php echo base_url('js/application/inventory/transfer/transfer_entry.js') ?>"></script>
<script type="text/javascript" src="<?php echo base_url('js/application/inventory/transfer/transfer_edit.js') ?>"></script>
<input type="hidden" id="trans_id" value="<?php echo $trans_id ?>">

<div class="container-fluid pt-2">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-md-12">
                <div class="row">
                    <div class="col-xs-12 col-md-4 pt-3">
                        <h3>Transfer Inventory</h3>
                    </div>
                </div>
            </div>
        </div>

        <hr style="color: black;" class="mt-0">


        <!-- Receiving Entry -->
        <div class="row">
            <div class="col-xs-12 col-md-12">
                <div class="container">
                    <div class="form-group row">
                        <div class="col-xs-12 col-md-4 px-1">
                            <span>Transfer No. <span class="required">*</span></span>
                            <input type="text" class="form-control" id="transfer_no">
                        </div>
                        <div class="col-xs-12 col-md-4 px-1">
                            <span>Transfer Date <span class="required">*</span></span>
                            <input type="date" class="form-control" id="transfer_date">
                        </div>
                        <div class="col-xs-12 col-md-4 px-1">
                            <span>Transaction Type <span class="required">*</span></span>
                            <select class="form-control" id="transaction_type">
                                <option value="7">Purchase Transfer Request</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group row">
                        <input type="hidden" id="recipient_type">
                        <input type="hidden" id="recipient_id">
                        <div class="col-xs-12 col-md-2 px-1">
                            <span>Recipient Code <span class="required">*</span></span>
                            <input type="text" class="form-control" id="recipient_code">
                        </div>
                        <div class="col-xs-12 col-md-5 px-1">
                            <span>Recipient Name <span class="required">*</span></span>
                            <input type="text" class="form-control" id="recipient_name">
                        </div>
                        <div class="col-xs-12 col-md-2 px-1">
                            <span>Ref Trans No.</span>
                            <input type="text" class="form-control" id="ref_trans_no">
                        </div>
                        <div class="col-xs-12 col-md-3 px-1">
                            <span>Ref Trans Date</span>
                            <input type="Date" class="form-control" id="ref_trans_date">
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-xs-12 col-md-8 px-1">
                            <span>Purpose <span class="required">*</span></span>
                            <input type="text" class="form-control" id="purpose">
                        </div>
                        <div class="col-xs-12 col-md-4 px-1">
                            <span>Source Outlet</span>
                            <input type="text" class="form-control" value="<?php echo $this->session->userdata('outlet_code') ?>" readonly>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-xs-12 col-md-12 px-1">
                <div class="container">
                    <hr style="color: black;" class="my-2">

                    <div class="form-group row">
                        <div class="col-xs-12 col-md-6"></div>
                        <div class="col-xs-12 col-md-2">
                            <button class="btn btn-block btn-add">Add Item</button>
                        </div>
                        <div class="col-xs-12 col-md-2">
                            <button class="btn btn-block btn-exit">Exit</button>
                        </div>
                        <div class="col-xs-12 col-md-2">
                            <button class="btn btn-block" id="add_item">Enter</button>
                        </div>
                    </div>                                    
                </div>
            </div>            
        </div>


        <!-- Product Details Entry -->
        <div class="row prod_entry collapse hide">
            <input type="hidden" id="prod_id">
            <input type="hidden" id="tbl_item_row">
            <div class="col-xs-12 col-md-12">
                <div class="col-xs-12 col-md-12">
                    <div class="form-group row">
                        <div class="col-xs-12 col-md-8">
                            
                            <div class="form-group row">
                                <div class="col-xs-12 col-md-4 px-1">
                                    <span>Product No.</span>
                                    <input type="text" class="form-control" id="prod_no">
                                </div>
                                <div class="col-xs-12 col-md-8 px-1">
                                    <span>Product Name</span>
                                    <input type="text" class="form-control" id="prod_name">
                                </div>
                            </div>

                            <div class="form-group row">
                                <div class="col-xs-12 col-md-4 px-1">
                                    <span>Product Type</span>
                                    <input type="text" class="form-control" id="prod_type" readonly>
                                </div>
                                <div class="col-xs-12 col-md-8 px-1">
                                    <span>Product Specification</span>
                                    <input type="text" class="form-control" id="prod_specs" readonly>
                                </div>
                            </div>

                        </div>

                        <div class="col-xs-12 col-md-4">
                            <img id='img-upload' class="rounded mx-auto d-block pt-3" />
                            <div class="input-group">
                                <span class="input-group-btn">
                                    <span class="btn btn-default btn-file">
                                        Browse… <input type="file" id="imgInp">
                                    </span>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xs-12 col-md-12">

                    <div class="form-group row">
                        <div class="col-xs-12 col-md-3 px-1">
                            <span>Brand</span>
                            <input type="text" class="form-control" id="prod_brand" readonly>
                        </div>
                        <div class="col-xs-12 col-md-3 px-1">
                            <span>Model</span>
                            <input type="text" class="form-control" id="prod_model" readonly>
                        </div>
                        <div class="col-xs-12 col-md-3 px-1">
                            <span>Category</span>
                            <input type="text" class="form-control" id="prod_category" readonly>
                        </div>
                        <div class="col-xs-12 col-md-3 px-1">
                            <span>Transfered Qty <span class="required">*</span> </span>
                            <input type="text" class="form-control text-right" placeholder="0.00" id="prod_transfer_qty">
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-xs-12 col-md-4 px-1">
                            <span>Color</span>
                            <input type="text" class="form-control" id="prod_color" readonly>
                        </div>
                        <div class="col-xs-12 col-md-4 px-1">
                            <span>Size</span>
                            <input type="text" class="form-control" id="prod_size" readonly>
                        </div>
                        <div class="col-xs-12 col-md-4 px-1">
                            <span>Class</span>
                            <input type="text" class="form-control" id="prod_class" readonly>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-xs-12 col-md-4 px-1">
                            <span>Unit</span>
                            <input type="text" class="form-control" id="prod_unit" readonly>
                        </div>
                        <div class="col-xs-12 col-md-4 px-1">
                            <span>Selling Price</span>
                            <input type="text" class="form-control text-right" id="prod_price" placeholder="0.00" readonly>
                        </div>
                        <div class="col-xs-12 col-md-4 px-1">
                            <span>On Hand Qty</span>
                            <input type="text" class="form-control text-right" id="prod_onhand_qty" placeholder="0.00" readonly>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <!-- END Product Details Entry -->

        <br>

        <!-- Table for Product Details Entry -->
        <div class="row">
            <div class="col-xs-12 col-md-12 px-3">
                <div class="container">
                    <div class="form-group row">
                        <table class="table table-striped table-responsive" id="tbl-item">
                            <thead>
                                <tr>
                                    <th style="width: 8%;">Product No</th>    
                                    <th style="width: 18%;">Product Name</th>
                                    <th style="width: 6%;">Unit</th>
                                    <th style="width: 8%;">On Hand</th>
                                    <th style="width: 10%;">Transfered Qty</th>
                                    <th style="width: 5%;">Currency</th>
                                    <th style="width: 10%;">Selling Price</th>
                                    <th style="width: 8%;">Total Price</th>
                                    <th style="width: 2%;">Action</th>
                                </tr>
                            </thead>
                            <tbody>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- END Table for Product Details Entry -->
 
        <div class="row">
            <div class="col-xs-12 col-md-12">
                <div class="container">
                    <div class="form-group row">
                        <div class="col-xs-12 col-md-2"></div>
                        <div class="col-xs-12 col-md-4">
                            <button type="button" class="btn btn-block" id="update">Save</button>
                        </div>
                        <div class="col-xs-12 col-md-4">
                            <button type="button" class="btn btn-block">Cancel</button>
                        </div>
                        <div class="col-xs-12 col-md-2"></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- END Receiving Entry -->
    </div>
</div>

<!-- Modal for Saving Receiving Product -->
<div class="modal fade" id="save_modal" role="dialog">
    <div class="modal-dialog modal-dialog-centered modal-md">
        <div class="modal-content">
            <div class="modal-body">
                <div class="col-xs-12 col-md-12">
                    <span>Transfer No. S000001 has been saved.</span>
                </div>
            </div>

            <div class="modal-footer">
                <div class="col-xs-12 col-md-4"></div>
                <div class="col-xs-12 col-md-4">
                    <button class="btn btn-grey btn-block">OK</button>
                </div>
                <div class="col-xs-12 col-md-4"></div>
            </div>
        </div>
    </div>
</div>
<!-- END Modal for Saving Receiving Product -->

