<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/application/inventory.css') ?>">
<script type="text/javascript" src="<?php echo base_url('js/application/inventory/receive/receive_entry.js') ?>"></script>
<body>
<input type="hidden" id="tbl_item_row">
<div class="container-fluid pt-2">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-md-12">
                <div class="row">
                    <div class="col-xs-12 col-md-4 pt-3">
                        <h3>Receive Inventory</h3>
                    </div>
                </div>
            </div>
        </div>

        <hr style="color: black;" class="mt-0">


        <!-- Receiving Entry -->
        <div class="row">
            <div class="col-xs-12 col-md-12">
                <div class="container text-sales">

                    <div class="row">
                        <div class="col-8">
                            <div class="form-group row">
                                <div class="col-xs-12 col-md-3 px-1">
                                    <span>Receive No. <span class="required">*</span></span>
                                    <input class="form-control txt-box-text-size" id="receive_no">
                                </div>
                                <div class="col-xs-12 col-md-3 px-1">
                                    <span>Receive Date <span class="required">*</span></span>
                                    <input type="Date" class="form-control txt-box-text-size" id="receive_date" value="<?php echo date("Y-m-d") ?>">
                                </div>
                                <div class="col-xs-12 col-md-6 px-1">
                                    <span>Transaction Type</span>
                                    <select class="form-control txt-box-text-size" id="trans_type">
                                        <option value="1">Purchase</option>
                                        <option value="2">Production Transfer</option>
                                        <option value="3">Sales Return</option>
                                        <option value="4">Replacement</option>
                                        <option value="0">Other</option>
                                    </select>
                                </div>
                            </div>    
                        </div>
                        
                        <div class="col-4">
                            <div class="form-group row">  
                                <div class="col-xs-12 col-md-6 px-1 ml-auto">
                                    <span>Recieving Outlet</span>
                                    <input type="text" class="form-control txt-box-text-size" value="<?php echo $this->session->userdata('outlet_code') ?>" readonly>   
                                </div> 
                            </div>   
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-8">   
                            <div class="form-group row">
                                <div class="col-xs-12 col-md-4 px-1">
                                    <span>Outlet/Vendor Code <span class="required">*</span></span>
                                    <input class="form-control txt-box-text-size" id="outlet_code" data-type_1="0" data-id = "">
                                </div>
                                <div class="col-xs-12 col-md-8 px-1">
                                    <span>Outlet/Vendor Name <span class="required">*</span></span>
                                    <input class="form-control txt-box-text-size" id="outlet_name">
                                </div>
                            </div>
                        </div>   
                        <div class="col-4"> 
                            <div class="form-group row"> 
                                <div class="col-xs-12 col-md-6 px-1">
                                    <span>Ref Trans No.</span>
                                    <input class="form-control txt-box-text-size" id="trans_no">
                                </div>
                                <div class="col-xs-12 col-md-6 px-1">
                                    <span>Ref Trans Date</span>
                                    <input type="Date" class="form-control txt-box-text-size" id="trans_date">
                                </div>                              
                            </div>                          
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-12">   
                            <div class="form-group row">
                                <div class="col-xs-12 col-md-12 px-1">
                                    <span>Remarks</span>
                                    <input class="form-control txt-box-text-size" id="remarks">
                                </div>
                            </div>
                        </div>   
                    </div>

                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-xs-12 col-md-12 px-1">
                <div class="container">
                    <hr style="color: black;" class="my-2">

                    <div class="form-group row py-2 mx-0 bg-button">
                        <div class="col-xs-12 col-md-6"></div>
                        <div class="col-xs-12 col-md-2">
                            <button class="btn btn-block btn-danger btn-exit">Exit</button>
                        </div>
                        <div class="col-xs-12 col-md-2">
                            <button class="btn btn-block btn-primary btn-enter" id="enter_item">Enter</button>
                        </div>
                        <div class="col-xs-12 col-md-2">
                            <button class="btn btn-block btn-add btn-success">Add Item</button>
                        </div>
                    </div>                                    
                </div>
            </div>            
        </div>

        <!-- Product Details Entry -->
        <div class="row prod_entry  collapse hide "> <!---->
            <div class="col-xs-12 col-md-12 text-sales">
                <div class="col-xs-12 col-md-12">
                    <div class="form-group row">
                        <div class="col-xs-12 col-md-12">
                            


                            <div class="form-group row" hidden>
                                <div class="col-xs-12 col-md-4 px-1">
                                    <span>Product Type</span>
                                    <input class="form-control txt-box-text-size" id="product_type"  readonly>
                                </div>
                                <div class="col-xs-12 col-md-8 px-1">
                                    <span>Product Specification</span>
                                    <input class="form-control txt-box-text-size" id="product_specs" readonly>
                                </div>
                            </div>

                        </div>

                    </div>
                </div>

                <div class="col-xs-12 col-md-12">

                    <div class="form-group row" >
                        <div class="col-xs-12 col-md-4 px-1">
                            <span>Product No.</span>
                            <input class="form-control txt-box-text-size" id="prod_no" data-unit="" data-id = "0s">
                        </div>
                        <div class="col-xs-12 col-md-8 px-1">
                            <span>Product Name</span>
                            <input class="form-control txt-box-text-size" id="prod_name">
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-xs-12 col-md-1 px-1">
                            <span>Qty</span>
                            <input class="form-control text-right txt-box-text-size" id="qty">
                        </div>
                        <div class="col-xs-12 col-md-1 px-1">
                            <span>Unit</span>
                            <input type="text" class="form-control txt-box-text-size" id="prod_unit" readonly>
                        </div>
                        <div class="col-xs-12 col-md-1 px-1">
                            <span>Currency</span>
                            <select class="form-control txt-box-text-size" id="currency">
                                
                            </select>
                        </div>
                        <div class="col-xs-12 col-md-2 px-1">
                            <span>Unit Price</span>
                            <input type="text" class="form-control txt-box-text-size text-right" id="cost" value="0">
                        </div>
                        <div class="col-xs-12 col-md-1 px-1">
                            <span>VAT</span>
                            <select class="form-control txt-box-text-size" id="vat">
                                <option value="1">Yes</option>
                                <option value="2">No</option>
                            </select>
                        </div>
                        <div class="col-xs-12 col-md-2 px-1">
                            <span>Net of VAT</span>
                            <input type="text" class="form-control text-right txt-box-text-size" id="net_vat" value="0" readonly>
                        </div>
                        <div class="col-xs-12 col-md-2 px-1">
                            <span>Total (w/VAT)</span>
                            <input type="text" class="form-control text-right txt-box-text-size" id="tot_w_vat" value="0" readonly>
                        </div>
                        <div class="col-xs-12 col-md-2 px-1">
                            <span>Total (w/0 VAT)</span>
                            <input type="text" class="form-control text-right txt-box-text-size" id="tot_w_o_vat" value="0" readonly>
                        </div>

                    </div>

                    <div class="form-group row" hidden>
                        <div class="col-xs-12 col-md-3 px-1">
                            <span>Brand</span>
                            <input class="form-control" id="product_brand" readonly>
                              
                        </div>
                        <div class="col-xs-12 col-md-3 px-1">
                            <span>Model</span>
                            <input class="form-control" id="product_model" readonly>
                               
                        </div>
                        <div class="col-xs-12 col-md-3 px-1">
                            <span>Category</span>
                            <input class="form-control" id="product_category" readonly>
                            
                        </div>
                    </div>

                    <div class="form-group row" hidden>
                        <div class="col-xs-12 col-md-3 px-1">
                            <span>Color</span>
                            <input class="form-control" id="product_color" readonly> 
                             
                        </div>
                        <div class="col-xs-12 col-md-3 px-1">
                            <span>Size</span>
                            <input class="form-control" id="product_class" readonly>
                            
                        </div>
                        <div class="col-xs-12 col-md-3 px-1">
                            <span>Class</span>
                            <input class="form-control" id="product_size" readonly>
                               
                        </div>
                        <div class="col-xs-12 col-md-3 px-1">
                            <span>Purchase Cost</span>
                            <input class="form-control" id="cost">
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <!-- END Product Details Entry -->

        <br>

        <!-- Table for Product Details Entry -->
        <div class="row">
            <div class="col-xs-12 col-md-12 px-3">
                <div class="container">
                    <div class="form-group row">
                        <table class="table table-striped table-fixed fixed_header text-table table-hover table-sm" id="tbl-products">
                            <thead style="width: 100%;">
                                <tr>
                                    <th style="width: 2.5%;" class="text-left">Product No</th>
                                    <th style="width: 7%;" class="text-left">Product Name</th>
                                    <th style="width: 1%;" class="text-left">Qty</th>
                                    <th style="width: 1%;" class="text-left">Unit</th>
                                    <th style="width: 1%;" class="text-left">Curr</th>
                                    <th style="width: 1%;" class="text-left">Cost</th>
                                    <th style="width: 1%;" class="text-center">VAT</th>
                                    <th style="width: 2%;" class="text-left">Total Price</th>
                                    <th style="width: 1%;" class="text-left">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr hidden>
                                    <td style="width: 2.5%;">S222211</td>
                                    <td style="width: 7%;">Hair Spray</td>
                                    <td style="width: 1%;">1,000.00</td>
                                    <td style="width: 1%;">Pc/s</td>
                                    <td style="width: 1%;">PHP</td>
                                    <td style="width: 1%;">2,500.00</td>
                                    <td style="width: 1%;" class="text-center">Y</td>
                                    <td style="width: 2%;">2,500,000.00</td>
                                    <td style="width: 1%;" class="text-center"><i class="fa fa-minus-circle"></i></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- END Table for Product Details Entry -->
 
        <div class="row">
            <div class="col-xs-12 col-md-12">
                <div class="container">
                    <div class="form-group row">
                        <div class="col-xs-12 col-md-2"></div>
                        <div class="col-xs-12 col-md-4">
                            <button type="button" class="btn btn-block btn-success cust-text"  id="save">Save</button>
                        </div>
                        <div class="col-xs-12 col-md-4">
                            <button type="button" class="btn btn-block btn-danger cust-text">Cancel</button>
                        </div>
                        <div class="col-xs-12 col-md-2"></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- END Receiving Entry -->
    </div>
</div>

<!-- Modal for Saving Receiving Product -->
<div class="modal fade" id="save_modal" role="dialog">
    <div class="modal-dialog modal-dialog-centered modal-md">
        <div class="modal-content">
            <div class="modal-body">
                <div class="col-xs-12 col-md-12">
                    <span>Receive No. S000001 has been saved.</span>
                </div>
            </div>

            <div class="modal-footer">
                <div class="col-xs-12 col-md-4"></div>
                <div class="col-xs-12 col-md-4">
                    <button class="btn btn-grey btn-block">OK</button>
                </div>
                <div class="col-xs-12 col-md-4"></div>
            </div>
        </div>
    </div>
</div>
<!-- END Modal for Saving Receiving Product -->

</body>

