<script type="text/javascript" src="<?php echo base_url('js/application/inventory/receive/receive_query.js') ?>"></script>
<body>
<input type="hidden" id="receive_func" value="<?php echo $function; ?>">
<div class="container-fluid pt-5">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-md-12">
                <div class="container">
                    <div class="form-group row">
                        <div class="col-xs-12 col-md-3 px-1">
                            <select class="form-control"type="text" hidden>
                                <option hidden>Product Type</option>
                            </select>
                        </div>

                        <div class="col-xs-12 col-md-4 px-1">
                            <input type="text" class="form-control" placeholder="Search Receive No, Vendor Name" id="search_box">
                        </div>

                        <div class="col-xs-12 col-md-1 px-1">
                            <button class="btn btn-primary btn-block" id="search">Search</button>
                        </div>

                    </div>
                </div>
            </div>
        </div>

<!--         <hr style="color: black;" class="my-2"> -->

        <div class="row">
            <div class="col-xs-2 col-md-12" id="query-table">
                
            </div>
        </div>
    </div>
</div>

</body>


<script>
    $(document).ready( function() {
        $(document).on('change', '.btn-file :file', function() {
        var input = $(this),
            label = input.val().replace(/\\/g, '/').replace(/.*\//, '');
        input.trigger('fileselect', [label]);
        });

        $('.btn-file :file').on('fileselect', function(event, label) {
            
            var input = $(this).parents('.input-group').find(':text'),
                log = label;
            
            if( input.length ) {
                input.val(log);
            } else {
                if( log ) alert(log);
            }
        
        });
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                
                reader.onload = function (e) {
                    $('#img-upload').attr('src', e.target.result);
                }
                
                reader.readAsDataURL(input.files[0]);
            }
        }

        $("#imgInp").change(function(){
            readURL(this);
        });     
    });
</script>