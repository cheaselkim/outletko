<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/application/outlet.css') ?>">
<script type="text/javascript" src="<?php echo base_url() ?>js/application/eoutlet/outlet_insert.js"></script>
<script type="text/javascript" src="<?php echo base_url() ?>js/application/eoutlet/outlet_edit.js"></script>
<input type="hidden" id="outlet_id" value="<?php echo $trans_id ?>">


<div class="container-fluid pt-5">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-md-12">
                <div class="row">
                    <div class="col-xs-12 col-md-4 text-date">
                        <span>Outlet Edit</span>
                    </div>
                </div>
            </div>
        </div>

        <hr style="color: black;" class="my-2">

        <div class="row">
            <div class="col-xs-12 col-md-12 px-0">
                <div class="container">
                    <div class="form-group row">
                        <div class="col-xs-12 col-md-4">
                            <span>Outlet No. <span class="required">*</span></span>
                            <input type="text" class="form-control" id="outlet_no">
                        </div>
                        <div class="col-xs-12 col-md-8">
                            <span>Outlet Name <span class="required">*</span></span>
                            <input type="text" class="form-control text-uppercase" id="outlet_name">
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-xs-12 col-md-6">
                            <span>Location <span class="required">*</span></span>
                            <input type="text" class="form-control" id="outlet_location">
                        </div>
                        <div class="col-xs-12 col-md-3">
                            <span>City/Town <span class="required">*</span></span>
                            <input type="text" class="form-control text-capitalize" placeholder="Search City/Town..." id="outlet_city">
                            <input type="hidden" class="form-control" id="outlet_city_id" readonly>
                        </div>
                        <div class="col-xs-12 col-md-3">
                            <span>Province <span class="required">*</span></span>
                            <input type="text" class="form-control" id="outlet_province" readonly>
                            <input type="hidden" class="form-control" id="outlet_province_id" readonly>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-xs-12 col-md-4">
                            <span>Outlet Type <span class="required">*</span></span>
                            <select class="form-control" id="outlet_type">
                                <option hidden></option>
                            </select>
                        </div>
                        <div class="col-xs-12 col-md-4">
                            <span>Monthly Quota <span class="required">*</span></span>
                            <input type="text" class="form-control text-right" id="outlet_quota" placeholder="0.00">
                        </div>
                        <div class="col-xs-12 col-md-4">
                            <span>Outlet Status <span class="required">*</span></span>
                            <select class="form-control" id="outlet_status">
                                <option value="1">Active</option>
                                <option value="0">Inactive</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <br>    
        <div class="row">
            <div class="col-xs-12 col-md-12">
                <div class="container">
                    <div class="form-group row">
                        <div class="col-xs-12 col-md-2"></div>
                        <div class="col-xs-12 col-md-4">
                            <button type="button" class="btn btn-block" id="save_outlet">Save</button>
                        </div>
                        <div class="col-xs-12 col-md-4">
                            <button type="button" class="btn btn-block">Cancel</button>
                        </div>
                        <div class="col-xs-12 col-md-2"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


