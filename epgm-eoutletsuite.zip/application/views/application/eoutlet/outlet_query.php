<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/application/outlet.css') ?>">
<script type="text/javascript" src="<?php echo base_url('js/application/eoutlet/outlet_query.js') ?>"></script>
<input type="hidden" id="outlet_func" value="<?php echo $function; ?>">

<div class="container-fluid pt-5">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-md-12">
                <div class="row">
                    <!-- <div class="col-xs-12 col-md-4">
                        <button type="button" class="btn btn-block">ADD</button>
                    </div>
                    <div class="col-xs-12 col-md-4">
                        <button type="button" class="btn btn-block" data-toggle="modal" data-target="#edit_modal">EDIT</button>
                    </div>
                    <div class="col-xs-12 col-md-4">
                        <button type="button" class="btn btn-block" data-toggle="modal" data-target="#query_modal">QUERY</button>
                    </div> -->

                    <div class="col-xs-12 col-md-4 text-date">
                        <h3>Outlet Query</h3>
                    </div>
                </div>
            </div>
        </div>

        <hr style="color: black;" class="my-2">

        <div class="row">
            <div class="col-xs-12 col-md-12 px-0">
                <div class="container">
                    <div class="form-group row">
                        <div class="col-xs-12 col-md-2">
                            <span>Outlet Type</span>
                            <select class="form-control" type="text" id="outlet_type">
                                <option value="">All</option>
                            </select>
                        </div>
                        <div class="col-xs-12 col-md-2" id="div-outlet-status">
                            <span>Outlet Status</span>
                            <select class="form-control" type="text" id="outlet_status">
                                <option value="1">Active</option>
                                <option value="2">Inactive</option>
                            </select>
                        </div>
                        <div class="col-xs-12 col-md-4">
                            <span>Search</span>
                            <div class="input-group mb-3">
                              <input type="text" class="form-control" placeholder="Search Outlet Code, Outlet Name..." aria-label="Recipient's username" aria-describedby="basic-addon2" id="search_box">
                              <div class="input-group-append">
                                <button class="btn btn-md" type="button" style="border: 1px solid black;" id="outlet_search">
                                  <i class="fas fa-search" aria-hidden="true" style="width: 50px;"></i>
                                </button>
                              </div>
                            </div>
                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col-xs-2 col-md-12" id="query-table">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="modal" id="modal_query">
<div class="modal-dialog modal-lg">
  <div class="modal-content">
    <div class="modal-header">
      <h4 class="modal-title">Outlet Query</h4>
    </div>
    <div class="modal-body">
        <div class="container">
            <div class="form-group row">
                <div class="col-xs-12 col-md-4">
                    <span>Outlet No.</span>
                    <input type="text" class="form-control" id="mod_no" >
                </div>
                <div class="col-xs-12 col-md-8">
                    <span>Outlet Name</span>
                    <input type="text" class="form-control" id="mod_name" >
                </div>
            </div>

            <div class="form-group row">
                <div class="col-xs-12 col-md-6">
                    <span>Location</span>
                    <input type="text" class="form-control" id="mod_loc" >
                </div>
                <div class="col-xs-12 col-md-3">
                    <span>City/Town</span>
                    <input type="text" class="form-control" id="mod_city" >
                </div>
                <div class="col-xs-12 col-md-3">
                    <span>Province</span>
                    <input type="text" class="form-control" id="mod_province" >
                </div>
            </div>

            <div class="form-group row">
                <div class="col-xs-12 col-md-4">
                    <span>Outlet Type</span>
                    <input type="text" class="form-control" id="mod_type" >
                </div>
                <div class="col-xs-12 col-md-4">
                    <span>Monthly Quota</span>
                    <input type="text" class="form-control text-right txt-box-text-size" id="mod_quota" placeholder="0.00" >
                </div>
                <div class="col-xs-12 col-md-4">
                    <span>Outlet Status</span>
                    <input type="text" class="form-control" id="mod_status" >
                </div>
            </div>
        </div>
    </div>
    <div class="modal-footer">
      <button type="button" class="btn btn-danger px-3" data-dismiss="modal">Close</button>
    </div>    
  </div>
</div>
</div>
  


