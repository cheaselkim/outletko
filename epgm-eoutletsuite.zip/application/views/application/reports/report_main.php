<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/application/report.css') ?>">
<script type="text/javascript" src="<?php echo base_url('js/application/report/report.js') ?>"></script>
<input type="hidden" id="submodule_id" value="0">

<div class="container-fluid" id="div-query">
    <div class="container">

        <div class="row">
            <div class="col-xs-12 col-md-12 pt-4">
                <div class="row">
                    <div class="col-xs-12 col-md-3">
                    	<select class="form-control" id="report_type">
                    	</select>
                    </div>
                    <div class="col-xs-12 col-md-4">
                    	<select class="form-control" id="reports">
                    	</select>
                    </div>
                </div>
            </div>
            <div class="col-xs-12 col-md-12 pt-4">
                <div class="row">
                    <div class="col-xs-12 col-md-2">
                    	<label style="font-size: 20px;color: black;font-weight: 520;">Date From</label>
                    	<input type="date" class="form-control" id="fdate" value="<?php echo date('Y-m-d') ?>">
                    </div>
                    <div class="col-xs-12 col-md-2">
                    	<label style="font-size: 20px;color: black;font-weight: 520;">Date To</label>
                    	<input type="date" class="form-control" id="tdate" value="<?php echo date('Y-m-d') ?>">
                    </div>
                    <div class="col-xs-12 col-md-2">
                        <label style="font-size: 20px;color: black;font-weight: 520;">Outlet</label>
                        <select class="form-control" id="outlet">
                            <option value="0">All</option>
                        </select>
                    </div>
                    <div class="col-xs-12 col-md-2" style="padding-top: 38px;">
                    	<button class="btn btn-success btn-block" id="view">View</button>
                    </div>
                </div>
            </div>
        </div>

        <hr class="my-3">

        <div class="row">
            <div class="col-lg-4 ml-auto">
                <div class="row div-total" id="div-sales-transaction">
                    <div class="col-lg-4 px-1">
                        <label style="color: black; font-weight: 520;">Total Trans</label>
                        <input type="text" class="form-control text-right total_trans" id="total_trans" value="0">
                    </div>
                    <div class="col-lg-3 px-1">
                        <label style="color: black; font-weight: 520;">Currency</label>
                        <input type="text" class="form-control" id="" value="PHP">
                    </div>
                    <div class="col-lg-5 pl-1">
                        <label style="color: black; font-weight: 520;">Total Amount</label>
                        <input type="text" class="form-control text-right total_amount" id="total_amount" value="0.00">
                    </div>
                </div>
                <div class="row div-total" id="div-sales-product">
                    <div class="col-lg-4 px-1">
                        <label style="color: black; font-weight: 520;">Total Trans</label>
                        <input type="text" class="form-control text-right total_trans" id="total_trans" value="0">
                    </div>
                    <div class="col-lg-4 px-1">
                        <label style="color: black; font-weight: 520;">Currency</label>
                        <input type="text" class="form-control" id="" value="PHP">
                    </div>
                    <div class="col-lg-4 pl-1">
                        <label style="color: black; font-weight: 520;">Total Amount</label>
                        <input type="text" class="form-control text-right total_amount" id="total_amount" value="0.00">
                    </div>
                </div>
                <div class="row div-total" id="div-sales-agent">
                    <div class="col-lg-4 px-1">
                        <label style="color: black; font-weight: 520;">Currency</label>
                        <input type="text" class="form-control" id="" value="PHP">
                    </div>
                    <div class="col-lg-4 pl-1">
                        <label style="color: black; font-weight: 520;">Total Amount</label>
                        <input type="text" class="form-control text-right total_amount" id="total_amount" value="0.00">
                    </div>
                    <div class="col-lg-4 px-1">
                        <label style="color: black; font-weight: 520;">Total Share</label>
                        <input type="text" class="form-control text-right total_share" id="total_share" value="0">
                    </div>
                </div>
                <div class="row div-total" id="div-inventory">
                    <div class="col-lg-4 px-1 ml-auto">
                        <label style="color: black; font-weight: 520;">Total Trans</label>
                        <input type="text" class="form-control text-right" id="total_trans" value="0">
                    </div>
                </div>
            </div>
        </div>

        <div class="row pt-4 mb-4">
        	<div class="col-lg-12 col-md-12 col-sm-12" id="div-report">
        		 
        	</div>
        </div>


    </div>
</div>


