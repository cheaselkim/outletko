<div class="container-fluid">
	<div class="row">
		<div class="col-lg-12 px-0">
			<div style="height:auto;min-height: 85vh;width: 100%;">

				<ul class="list-group" style="border-radius: 0;">
					<li class="list-group-item">Daily Sales</li>
					<li class="list-group-item">Collection</li>
					<li class="list-group-item">Stock on Hand</li>
					<li class="list-group-item">Purchases</li>
					<li class="list-group-item">Product Issuance</li>
					<li class="list-group-item">Stock Transfer</li>
					<li class="list-group-item">Returns</li>
					<li class="list-group-item">Partner / Agent's Share</li>
					<li class="list-group-item">Cost of Sales / Expenses</li>
				</ul>
				
			</div>
		</div>
	</div>
</div>

<style type="text/css">
.list-group-item:first-child {
    border-top-left-radius: 0 !important;
    border-top-right-radius: 0 !important;
}

.list-group-item:last-child {
    border-bottom-right-radius: 0 !important;
    border-bottom-left-radius: 0 !important;
}


</style>