<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/application/header.css') ?>">
<script type="text/javascript" src="<?php echo base_url('js/application/header.js') ?>"></script>
<input type="hidden" id="main_menu_module" value="<?php echo $menu_module ?>">
<input type="hidden" id="comp_id" value="<?php echo $this->session->userdata('comp_id') ?>">
<input type="hidden" id="outelt_id" value="<?php echo $this->session->userdata('outelt_id') ?>">

<div class="container-fluid px-0 mx-0">
    <div class="row mx-0">
        <div class="div-header">
            <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-12 div-title">
                    <span class="span-eoutletsuite"><span class="span-eoutlet">eOutlet</span><span class="span-suite">Suite</span></span>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-12"></div>
                <div class="col-lg-6 col-md-3 col-sm-12 div-account">
                    <div class="row">
                        <div class="col-lg-2">
                          
                        </div>
                        <div class="col-lg-3 col-md-4 col-sm-12">
                            <span>Account ID :</span><br>
                            <span><?php echo $this->session->userdata("account_id"); ?></span>
                        </div>
                        <div class="col-lg-3 col-md-4 col-sm-12">
                            <span>Outlet No :</span><br>
                            <span id="span_outlet_id"><?php echo $this->session->userdata("outlet_code"); ?></span>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-12">
                            <span>User :</span><br>
                            <span><?php echo $this->session->userdata("user_fullname"); ?></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row mx-0">
        <div class="div-subheader" id="div-subheader-1">
            <div class="row">
                <div class="col-auto div-subheader-trans mr-auto">
                  <span class="text-white span-date"><?php echo date("F d, Y"); ?></span>
                </div>
                <div class="col-auto div-subheader-trans mx-auto">
                    <div class="row">
                        <ul class="list-inline  my-0">
                            <li class="list-inline-item li-subheader"><label>Last Tran No. :&nbsp;</label><span class="last_tran_no text-white" id="last_tran_no">00000</span></li>
                            <li class="list-inline-item li-subheader"><label>No. of Trans :&nbsp;</label><span class="no_of_trans text-white" id="no_of_trans"></span></li>
                            <li class="list-inline-item li-subheader"><label>Total Sales :&nbsp;</label><span class="sub-header-curr text-white"> PHP </span></li>
                            <li class="list-inline-item li-subheader"><span id="total_sales_for_today" class="font-weight-bold total text-white total_sales_for_today">1000000.00</span></li>
                        </ul>
                    </div>
                </div>
                <div class="col-auto div-subheader-trans ml-auto py-0">
                  <div class="row">
                    <ul class="list-inline float-right my-0 py-0">
                        <li class="list-inline-item li-button"><a onclick='count_outlet();'><button class="btn btn-light btn-block"><i class="fas fa-building"></i></button></a></li>
                        <li class="list-inline-item li-button"><a href="<?php echo base_url('/') ?>"><button class="btn btn-light btn-block"><i class="fas fa-user"></i></button></a></li>
                        <li class="list-inline-item li-button"><button class="btn btn-light btn-block" id="btn_main_menu"><i class="fas fa-lock"></i></button></li>
                        <li class="list-inline-item li-button"><a href="<?php echo base_url('/logout') ?>"><button class="btn btn-light btn-block"><i class="fas fa-power-off" ></i></button></a></li>
                    </ul>                    
                  </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row mx-0 py-0 my-0">
      <div class="div-subheader py-2" id="div-subheader-2">
        <div class="row py-0 my-0">

          <div class="col-1 px-0 pl-2 text-white">
            <a class="fas fa-chart-line" id="icon-menu" onclick="report_menu();"></a>
          </div>

          <div class="col-9 text-center">
            <a onclick="sign_out();" id="sign_out"><span class="font-weight-bold text-white" style="font-size: 20px;">13520006</span></a>
          </div>

          <div class="col-1 pr-4 text-white" >
            <a  href="<?php echo base_url(); ?>" class="text-white"><span class="fas fa-bars" id="icon-menu"></span></a>
          </div>

          <div class="col-1" hidden>
            <a href="<?php echo base_url('/logout') ?>" class="btn btn-light"><i class="fas fa-power-off" ></i></a>
          </div>


        </div>
      </div>
    </div>

</div>

<div id="div-report-menu" hidden>
  <?php $this->load->view("application/reports/report_menu"); ?>
</div>


<!-- The Modal -->
<div class="modal" id="modal_outlet">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">List of Outlets</h4>
        <button type="button" class="close" data-dismiss="modal" hidden>&times;</button>
      </div>
      <div class="modal-body">
        <div class="div_list_outlet" id="div_list_outlet">
        </div>     
      </div>
      <div class="modal-footer">
        <a href="<?php echo base_url('/logout') ?>"><button type="button" class="btn btn-danger" >Logout</button></a>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="sales_modal" role="dialog">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
        <h5 id="header-menu"></h5>
      </div>
      <div class="modal-body">
        <div id="menu-content">
        </div>
      </div>
      <div class="modal-footer">
        <a href="<?php echo base_url('/') ?>"><button class="btn btn-danger" >Main Menu</button></a>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="prod_modal" role="dialog" hidden>
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
        <h5 id="header-menu"></h5>
      </div>
      <div class="modal-body">
        <div class="menu-content">

          <div class="row">

            <div class="col-3"> 
              <div class="flip-card">
                <div class="flip-card-inner">
                  <div class="flip-card-front">
                    <img src="<?php echo base_url('assets/images/app_menu/history.png') ?>" alt="Avatar" style="width:200px;height:200px;">
                    <label>Receive Inventory</label>
                  </div>
                  <div class="flip-card-back">
                    <div class="list-group h-100 rounded-0">
                      <a href="#" class="list-group-item list-group-item-action h-25 rounded-0 d-table"><span class="prod-submenu">Add</span></a>
                      <a href="#" class="list-group-item list-group-item-action h-25 rounded-0 d-table"><span class="prod-submenu">Edit</span></a>
                      <a href="#" class="list-group-item list-group-item-action h-25 rounded-0 d-table"><span class="prod-submenu">Cancel</span></a>
                      <a href="#" class="list-group-item list-group-item-action h-25 rounded-0 d-table"><span class="prod-submenu">Query</span></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-3"> 
              <div class="flip-card">
                <div class="flip-card-inner">
                  <div class="flip-card-front">
                    <img src="<?php echo base_url('assets/images/app_menu/history.png') ?>" alt="Avatar" style="width:200px;height:200px;">
                    <label>Issuance Inventory</label>
                  </div>
                  <div class="flip-card-back">
                    <div class="list-group h-100 rounded-0">
                      <a href="#" class="list-group-item list-group-item-action h-25 rounded-0 d-table"><span class="prod-submenu">Add</span></a>
                      <a href="#" class="list-group-item list-group-item-action h-25 rounded-0 d-table"><span class="prod-submenu">Edit</span></a>
                      <a href="#" class="list-group-item list-group-item-action h-25 rounded-0 d-table"><span class="prod-submenu">Cancel</span></a>
                      <a href="#" class="list-group-item list-group-item-action h-25 rounded-0 d-table"><span class="prod-submenu">Query</span></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-3"> 
              <div class="flip-card">
                <div class="flip-card-inner">
                  <div class="flip-card-front">
                    <img src="<?php echo base_url('assets/images/app_menu/history.png') ?>" alt="Avatar" style="width:200px;height:200px;">
                    <label>Transfer Inventory</label>
                  </div>
                  <div class="flip-card-back">
                    <div class="list-group h-100 rounded-0">
                      <a href="#" class="list-group-item list-group-item-action h-25 rounded-0 d-table"><span class="prod-submenu">Add</span></a>
                      <a href="#" class="list-group-item list-group-item-action h-25 rounded-0 d-table"><span class="prod-submenu">Edit</span></a>
                      <a href="#" class="list-group-item list-group-item-action h-25 rounded-0 d-table"><span class="prod-submenu">Cancel</span></a>
                      <a href="#" class="list-group-item list-group-item-action h-25 rounded-0 d-table"><span class="prod-submenu">Query</span></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-3"> 
              <div class="flip-card">
                <div class="flip-card-inner">
                  <div class="flip-card-front">
                    <img src="<?php echo base_url('assets/images/app_menu/history.png') ?>" alt="Avatar" style="width:200px;height:200px;">
                    <label>Returns Inventory</label>
                  </div>
                  <div class="flip-card-back">
                    <div class="list-group h-100 rounded-0">
                      <a href="#" class="list-group-item list-group-item-action h-25 rounded-0 d-table"><span class="prod-submenu">Add</span></a>
                      <a href="#" class="list-group-item list-group-item-action h-25 rounded-0 d-table"><span class="prod-submenu">Edit</span></a>
                      <a href="#" class="list-group-item list-group-item-action h-25 rounded-0 d-table"><span class="prod-submenu">Cancel</span></a>
                      <a href="#" class="list-group-item list-group-item-action h-25 rounded-0 d-table"><span class="prod-submenu">Query</span></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>

          </div>
          
        </div>
      </div>
      <div class="modal-footer">
        <a href="<?php echo base_url('/') ?>"><button class="btn btn-danger" >Main Menu</button></a>
      </div>
    </div>
  </div>
</div>