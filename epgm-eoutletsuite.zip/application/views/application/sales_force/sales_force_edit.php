<script type="text/javascript" src="<?php echo base_url() ?>js/application/sales_force/sales_force_edit.js"></script>
<body>
<input type="hidden" id="sales_force_id" value="1">
<div class="container-fluid pt-3"> 
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-md-12">
                <div class="row">
                    <div class="col-xs-12 col-md-4 text-date">
                        <span>Sales Force</span>
                    </div>
                </div>
            </div>
        </div>

        <hr style="color: black;" class="my-2">

        <div class="row">
            <div class="col-xs-12 col-md-12">
                <div class="container">
                    <div class="form-group row">
                        <div class="col-lg-6 col-md-6 col-sm-12">
                            <span>Last Name <span class="required">*</span></span>
                            <input class="form-control" id="last_name">
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-12"></div>
                        <div class="col-lg-3 col-md-3 col-sm-12">
                            <span>Status</span>
                            <select class="form-control" id="status">
                                <option value="1">Active</option>
                                <option value="2">Inactive</option>
                            </select>
                        </div>
                    </div>                            
                    <div class="form-group row">
                        <div class="col-lg-6 col-md-6 col-sm-12">
                            <span>First Name <span class="required">*</span></span>
                            <input class="form-control" id="first_name">
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-12"></div>
                        <div class="col-lg-3 col-md-3 col-sm-12">
                            <span>Nickname</span>
                            <input type="text" class="form-control" id="nick_name">
                        </div>
                    </div>                            
                    <div class="form-group row">
                        <div class="col-lg-6 col-md-6 col-sm-12">
                            <span>Middle Name <span class="required">*</span></span>
                            <input class="form-control" id="mid_name">
                        </div>
                    </div>                            
                </div>
            </div>
        </div>

        <hr style="color: black;" class="my-2">

        <div class="row">
            <div class="col-xs-12 col-md-12">
                <div class="container">

                    <div class="form-group row">
                        <div class="col-xs-12 col-md-4">
                            <span>Position</span>
                            <input class="form-control" id="position">
                        </div>
                        <div class="col-xs-12 col-md-4">
                            <span>Date Started</span>
                            <input type="date" class="form-control" id="date_start">
                        </div>
                        <div class="col-xs-12 col-md-4">
                            <span>Monthly Quota</span>
                            <input type="text" class="form-control" id="monthly_quota">
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-xs-12 col-md-4">
                            <span>Hierarchy</span>
                            <input class="form-control" id="hierarchy">
                        </div>
                        <div class="col-xs-12 col-md-4">
                            <span>Type of Share</span>
                            <input class="form-control" id="share_type">
                        </div>
                        <div class="col-xs-12 col-md-4">
                            <span>Salary Allowance (PHP)</span>
                            <input class="form-control" id="salary">
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-xs-12 col-md-4">
                            <span>Outlet No/Area</span>
                            <select class="form-control" id="outlet">
                                
                            </select>
                        </div>
                        <div class="col-xs-12 col-md-4">
                            <span>% / Amount (PHP)</span>
                            <input type="text" class="form-control" id="share">
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-xs-12 col-md-12 pt-5">
                <div class="container">
                    <div class="form-group row">
                        <div class="col-xs-12 col-md-2"></div>
                        <div class="col-xs-12 col-md-4">
                            <button type="button" class="btn btn-block" id="save">Save</button>
                        </div>
                        <div class="col-xs-12 col-md-4">
                            <button type="button" class="btn btn-block">Cancel</button>
                        </div>
                        <div class="col-xs-12 col-md-2"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


</body>

