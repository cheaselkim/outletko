<script type="text/javascript" src="<?php echo base_url() ?>js/application/sales_force/sales_force_query.js"></script>
<body>
<input type="hidden" id="force_func" value="<?php echo $function; ?>">
<div class="container-fluid pt-3">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-md-12">
                <div class="row">
                    <div class="col-xs-12 col-md-4 text-date">
                        <span>Query Sales Force Information</span>
                    </div>
                </div>
            </div>
        </div>

        <hr style="color: black;" class="my-2">

        <div class="row">
            <div class="col-xs-12 col-md-12">
                <div class="container">
                    <div class="form-group row">
                        <div class="col-xs-12 col-md-4">
                            <div class="input-group">
                                <input class="form-control" id="search_box" placeholder="Search Outlet, Name....">
                            </div>
                        </div>
                        <div class="col-xs-12 col-md-2 px-0">
                        	<button class="btn btn-primary px-5" id="search_name">Search</button>
                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col-xs-2 col-md-12" id="query-table">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


</body>

