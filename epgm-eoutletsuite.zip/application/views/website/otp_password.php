<!DOCTYPE html>
<html>
<head>
	<title>eOutletSuite</title>
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/node_modules/font-awesome/css/all.css') ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/node_modules/simple-line-icons/css/simple-line-icons.css') ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/login.css') ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/vendors/pace-progress/css/pace.min.css') ?>">
    <link rel="stylesheet" type="text/css" href="http://weareoutman.github.io/clockpicker/dist/jquery-clockpicker.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.4/css/bootstrap-datepicker.css">
    <link rel='stylesheet' type='text/css' href='<?php echo base_url('assets/css/eqcss.css') ?>'>

    <script async="" src="https://www.googletagmanager.com/gtag/js?id=UA-118965717-3"></script>
    <script type="text/javascript" src="<?php echo base_url('assets/node_modules/jquery/dist/jquery.min.js') ?>"></script>
    <script type="text/javascript" src="<?php echo base_url('assets/node_modules/popper.js/dist/umd/popper.min.js') ?>"></script>
    <script type="text/javascript" src="<?php echo base_url('assets/node_modules/bootstrap/dist/js/bootstrap.min.js') ?>"></script>
    
    <script type="text/javascript" src="<?php echo base_url('assets/node_modules/font-awesome/js/all.js') ?>"></script>
    <script type="text/javascript" src="<?php echo base_url('assets/node_modules/@coreui/coreui/dist/js/coreui.min.js') ?>"></script>
    <script type="text/javascript" src="<?php echo base_url('js/forgot_password.js') ?>"></script>
    <script>var base_url = '<?php echo base_url() ?>';</script>
</head>
<body>

	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-6 col-md-12 col-sm-12 mx-auto py-3 px-4" style="background: white;margin-top: 100px;">
				<div class="alert alert-danger" id="alert-danger">
					<span>Password does not match.</span>
				</div>
				<div class="alert alert-success" id="alert-success">
					<span>Your password has been changed successfully! Thank you</span><br>
					<small>You will redirect to login page in <span id="time">04</span> secs..</small>
				</div>
				<div>
					<label style="font-size: 20px;">New Password</label>
					<div class="input-group">
						<input type="password" class="form-control" id="new_pass" style="height: 40px;">
							<div class="input-group-append">
								<button class="input-group-text" id="new_pass_eye"><i class="fas fa-eye-slash" id="new_pass_icon"></i></button>
							</div>
					</div>					
				</div>

				<div class="form-group pt-3">
					<label style="font-size: 20px;">Confirm Password</label>
					<div class="input-group">
						<input type="password" class="form-control" id="conf_pass" style="height: 40px;">
							<div class="input-group-append">
								<button class="input-group-text" id="conf_pass_eye"><i class="fas fa-eye-slash" id="conf_pass_icon"></i></button>
							</div>
					</div>					
				</div>

				<div class="form-group">
					<button class="btn btn-primary btn-block" id="save" style="font-size: 20px;">Save</button>
				</div>


			</div>
		</div>
	</div>

	<script type="text/javascript">
		
		$("#new_pass_eye").click(function(){
			if ($("#new_pass").attr("type") == "text"){
				$("#new_pass_icon").removeClass("fa-eye");
				$("#new_pass_icon").addClass("fa-eye-slash");
				$("#new_pass").attr("type","password");
			}else{
				$("#new_pass_icon").removeClass("fa-eye-slash");
				$("#new_pass_icon").addClass("fa-eye");
				$("#new_pass").attr("type","text");
			}
		});


		$("#conf_pass_eye").click(function(){
			if ($("#conf_pass").attr("type") == "text"){
				$("#conf_pass_icon").removeClass("fa-eye");
				$("#conf_pass_icon").addClass("fa-eye-slash");
				$("#conf_pass").attr("type","password");
			}else{
				$("#conf_pass_icon").removeClass("fa-eye-slash");
				$("#conf_pass_icon").addClass("fa-eye");
				$("#conf_pass").attr("type","text");
			}
		});

	</script>

</body>
</html>

