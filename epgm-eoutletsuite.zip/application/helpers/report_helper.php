<?php 
if (!function_exists("report_17")){
	function report_17($query){

		$output = "";
		$currency = "";
		$total_trans = 0;
		$total_amount = 0;
		$total_vat = 0;
		$total_net_vat = 0;

		$output .= "<table class='table table-striped table-bordered'>
					<thead style='width: 100%;' class=''>
						<tr>
							<th class='text-center'>Outlet</th>
							<th class='text-center'>Currency</th>
							<th class='text-center'>No. of Trans</th>
							<th class='text-center'>Total Amount</th>
							<th class='text-center'>VAT Amount</th>
							<th class='text-center'>Net of VAT</th>
						</tr>
					</thead>
					<tbody>";

		if (!empty($query)){
			foreach ($query as $key => $value) {
				$output .= "<tr>
								<td>".$value->outlet_code."</td>
								<td class='text-center'>".$value->curr_code."</td>
								<td class='text-center'>".number_format($value->total_transaction)."</td>
								<td class='text-center'>".number_format($value->total_amount,2)."</td>
								<td class='text-center'>".number_format($value->total_vat_amount, 2)."</td>
								<td class='text-center'>".number_format($value->total_net_vat, 2)."</td>
							</tr>";
				$currency = $value->curr_code;
				$total_trans += $value->total_transaction;
				$total_amount += $value->total_amount;
				$total_vat += $value->total_vat_amount;
				$total_net_vat += $value->total_net_vat;

			}			
		}

		$output .= "</tbody>
					</tfoot>
						<tr>
							<th class='text-center'>Total</th>
							<th class='text-center'>".$currency."</th>
							<th class='text-center'>".number_format($total_trans)."</th>
							<th class='text-center'>".number_format($total_amount,2)."</th>
							<th class='text-center'>".number_format($total_vat,2)."</th>
							<th class='text-center'>".number_format($total_net_vat,2)."</th>
						</tr>
					</tfoot>
					</table>";


		return $output;

	}
}

if (!function_exists("sales_transaction")){
	function sales_transaction($query){

		$output = "";
		$status = "";

		$output .= "<table style='width: 100%' class='table table-striped table-bordered table-sm' id='tbl-receive'>
					<thead>
						<tr>
							<th style='width: 5%;'>Trans No.</th>
                            <th style='width: 7%;'>Trans Date</th>
                            <th style='width: 20%;'>Customer Name</th>
                            <th style='width: 3%;'>Currency</th>
                            <th style='width: 7%;'>Trans Amount</th>
                            <th style='width: 3%;'>Outlet</th>
                            <th style='width: 3%;'>Status</th>
                            <th style='width: 1%;'>Action</th>
						</tr>
					</thead>
					<tbody>";

		if (!empty($query)){
			foreach ($query as $key => $value) {

				if ($value->status == "1"){
					$status = "Served";
				}else{
					$status = "Cancelled";
				}

				$output .= "<tr>
								<td>".$value->trans_no."</td>
								<td>".date('m/d/Y', strtotime($value->date_insert))."</td>
								<td>".$value->cust_name."</td>
								<td>".$value->currency."</td>
								<td class='text-right'>".number_format($value->total_amount, 2)."</td>
								<td>".$value->outlet_code."</td>
								<td>".$status."</td>
								<td><a href=''>View</a></td>
  						    </tr>";
			}
		}else{
			$output .= "<tr>
						<td colspan='8'>No Data...</td>
					  </tr>";
		}


		$output .= "</tbody>
					</table>";


		return $output;


	}
}

if (!function_exists("sales_per_product")){
	function sales_per_product($query){

		$output = "";

		$output .= "<table style='width: 100%' class='table table-striped table-bordered table-sm' id='tbl-receive'>
					<thead>
						<tr>
							<th style='width: 10%;'>Product No</th>
                            <th style='width: 25%;'>Product Name</th>
                            <th style='width: 5%;'>Category</th>
                            <th style='width: 10%;'>Class</th>
                            <th style='width: 5%;'>Qty</th>
                            <th style='width: 5%;'>Unit</th>
                            <th style='width: 5%;'>Currency</th>
                            <th style='width: 10%;'>Total Amount</th>
                            <th style='width: 5%;'>Action</th>
						</tr>
					</thead>
					<tbody>";

		if (!empty($query)){
			foreach ($query as $key => $value) {
			
				if (!empty($value->product_no)){				
					$output .= "<tr>
									<td>".$value->product_no."</td>
									<td>".$value->product_name."</td>
									<td>".$value->category_desc."</td>
									<td>".$value->class_desc."</td>
									<td>".$value->total_qty."</td>
									<td>".$value->unit_desc."</td>
									<td>".$value->currency."</td>
									<td class='text-right'>".number_format($value->total_amount, 2)."</td>
									<td><a href=''>View</a></td>
	  						    </tr>";
				}

			}
		}else{
			$output .= "<tr>
						<td colpan='8'>No Data</td>
					  </tr>";
		}


		$output .= "</tbody>
					</table>";


		return $output;


	}
}

//-------FOR AGENT REPORT------------
if (!function_exists("sales_per_agent")){
	function sales_per_agent($query){

		$output = "";

		$output .= "<table style='width: 100%' class='table table-striped table-bordered table-sm' id='tbl-receive'>
					<thead>
						<tr>
							<th style='width: 5%;'>Agent/Partner ID</th>
                            <th style='width: 20%;'>Agent/Partner Name</th>
                            <th style='width: 5%;'>Currency</th>
                            <th style='width: 10%;'>Total Amount</th>
                            <th style='width: 10%;'>Share Amount</th>
                            <th style='width: 5%;'>Action</th>
						</tr>
					</thead>
					<tbody>";

		if (!empty($query)){
			foreach ($query as $key => $value) {
			

				$output .= "<tr>
								<td>".$value->id."</td>
								<td>".$value->agent_name."</td>
								<td>".$value->currency."</td>
								<td class='text-right'>".number_format($value->total_amount, 2)."</td>
								<td class='text-right'>".number_format($value->share, 2)."</td>
								<td><a href=''>View</a></td>
  						    </tr>";
			}
		}else{
			$output .= "<tr>
						<td colspan='8'>No Data</td>
					  </tr>";
		}


		$output .= "</tbody>
					</table>";


		return $output;


	}
}

if (!function_exists("inventory_transaction")){
	function inventory_transaction($query){

		$output = "";

		$output .= "<table style='width: 100%' class='table table-striped' id='tbl-receive'>
					<thead>
						<tr>
							<th style='width: 10%;'>Transaction No.</th>
                            <th style='width: 10%;'>Transaction Date</th>
                            <th style='width: 12%;'>Vendor/Outlet Code</th>
                            <th style='width: 20%;'>Vendor/Outlet Name</th>
                            <th style='width: 15%;'>Trans Type</th>
                            <th style='width: 5%;'>Outlet</th>
                            <th style='width: 2%;'>Action</th>
						</tr>
					</thead>
					<tbody>";

		if (!empty($query)){
			foreach ($query as $key => $value) {
			

				$output .= "<tr>
								<td>".$value->inv_no."</td>
								<td>".$value->inv_date."</td>
								<td>".$value->supplier_code2."</td>
								<td>".$value->supplier_name2."</td>
								<td>".$value->inventory_ref_type."</td>
								<td>".$value->outlet."</td>
								<td><a href=''>View</a></td>
  						    </tr>";
			}
		}else{
			$output .= "<tr>
						<td colspan='8'>No Data</td>
					  </tr>";
		}


		$output .= "</tbody>
					</table>";


		return $output;


	}
}