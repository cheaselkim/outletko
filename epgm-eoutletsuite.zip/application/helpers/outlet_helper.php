<?php 

if (!function_exists("table_outlet")){
	function table_outlet($query, $function){

		$output = "";

		$output .= "<table style='width: 100%' class='table table-striped' id='tbl-outlet'>
					<thead>
						<tr>
							<th style='width: 1%;'>#</th>
							<th style='width: 12%;'>Outlet No</th>
                            <th style='width: 35%;'>Outlet Name</th>
                            <th style='width: 30%;'>Address</th>
                            <th style='width: 5%;'>Type</th>
                            <th style='width: 30%;'>Montly Quota</th>
                            <th style='width: 5%;'>Status</th>
                            <th style='width: 5%;'Action</th>
						</tr>
					</thead>
					<tbody>";

		if (!empty($query)){
			$status = "";
			foreach ($query as $key => $value) {
				if ($value->outlet_status == "1"){
					$status = "Active";
				}else{
					$status = "Inactive";
				}

				if ($function == '2'){
					$btn = "<button class='btn btn-primary' onclick='edit_outlet(".$value->id.")'>Edit</button>";					
				}else if ($function == "3"){
					$btn = "<button class='btn btn-primary' onclick='view_outlet(".$value->id.")'>View</button>";
				}else{
					$btn = "<button class='btn btn-danger' onclick='delete_outlet(".$value->id.", ".$key.")'>Delete</button>";
				}

				$output .= "<tr>
								<td>".($key+1)."</td>
								<td>".$value->outlet_code."</td>
								<td>".$value->outlet_name."</td>
								<td>".$value->outlet_location."</td>
								<td>".$value->outlet_type."</td>
								<td>".number_format($value->outlet_monthly_quota, 2)."</td>
								<td>".$status."</td>
								<td>".$btn."</td>
  						    </tr>";
			}
		}else{
			$output .= "<tr>
						<td colpan='8'>No Data</td>
					  </tr>";
		}


		$output .= "</tbody>
					</table>";


		return $output;


	}
}

 ?>