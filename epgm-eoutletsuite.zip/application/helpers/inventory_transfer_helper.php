<?php 

if (!function_exists("tbl_query")){
	function tbl_query($query, $app_func){

		$output = "";
		$button = "";

		$output .= "<table class='table tbl-responsive table-striped' id='tbl-data'>
						<thead>
							<tr>
                            <th style='width: 8%;'>Transfer No.</th>
                            <th style='width: 10%;'>Transfer Date</th>
                            <th style='width: 15%;'>Transfer Type</th>
                            <th style='width: 20%;'>Recepient Name</th>
                            <th style='width: 5%;'>Total Qty</th>
                            <th style='width: 5%;'>Action</th>
							</tr>
						</thead>
						<tbody>";

		foreach ($query as $key => $value) {

			if ($app_func == "2"){
				$button = "<button class='btn btn-primary btn-block' onclick = 'edit_transfer(".$value->id.")'>Edit</button>";
			}else if ($app_func == "3"){
				$button = "<button class='btn btn-success btn-block'>View</button>";
			}else if ($app_func == "4"){
				$button = "<button class='btn btn-danger btn-block' onclick = 'cancel_transfer(".$value->id.", ".$key.")'>Cancel</button>";
			}

			$output .= "<tr>
							<td valign='bottom'>".$value->inv_no."</td>
							<td valign='bottom'>".date('m/d/Y', strtotime($value->inv_date))."</td>
							<td valign='bottom'>".$value->tran_type."</td>
							<td valign='bottom'>".$value->outlet_name."</td>
							<td valign='bottom'>".number_format($value->total_qty, 2)."</td>
							<td valign='bottom'>".$button."</td>
						</tr>";
		}

			$output .= "</tbody>
						</table>";

		return $output;
	}	
}

if (!function_exists("tbl_items")){
	function tbl_items($query){
		$output = "";

		foreach ($query as $key => $value) {
			$output .= "<tr  class='item_row_table'>
							<td class='tbl_id' hidden>".$value->id."</td>
							<td class='tbl_prod_no'>".$value->product_no."</td>
							<td class='tbl_prod_name'>".$value->product_name."</td>
							<td class='tbl_prod_unit'>".$value->unit_code."</td>
							<td class='tbl_prod_onhand_qty'>".$value->inventory_qty."</td>
							<td class='tbl_prod_transfer_qty'>".$value->qty."</td>
							<td class='tbl_prod_curr'>PHP</td>
							<td class='tbl_prod_price'>".$value->reg_selling_price."</td>
							<td class='tbl_prod_total_price'>".($value->reg_selling_price * $value->qty)."</td>
							<td class='text-center text-red remove_item'><i class='fa fa-minus-circle delete_item_table' style='color:red;cursor:pointer;' id='delete_item_table'></i></td>
							<td class='tbl_prod_id' hidden>".$value->prod_id."</td>
						</tr>";
		}

		return $output;
	}	
}