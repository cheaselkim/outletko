<?php 

if (!function_exists("table_customer")){
	function table_customer($query, $function){

		$output = "";

		$output .= "<table style='width: 100%' class='table table-striped' id='tbl-customer'>
					<thead>
						<tr>
							<th style='width: 8%;'>Customer No</th>
                            <th style='width: 25%;'>Customer Name</th>
                            <th style='width: 30%;'>Address</th>
                            <th style='width: 15%;'>Type</th>
                            <th style='width: 10%;'>Status</th>
                            <th style='width: 10%;'>Credit Limit</th>
                            <th style='width: 5%;'>Action</th>
						</tr>
					</thead>
					<tbody>";

		if (!empty($query)){
			$status = "";
			foreach ($query as $key => $value) {
				

				if ($function == '2'){
					$btn = "<button class='btn btn-primary' onclick='edit_customer(".$value->table_id.")'>Edit</button>";					
				}else if ($function == "3"){
					$btn = "<button class='btn btn-primary' onclick='view_customer(".$value->table_id.")'>View</button>";
				}else{
					$btn = "<button class='btn btn-danger' onclick='delete_customer(".$value->table_id.", ".$key.")'>Delete</button>";
				}

				// if ($value->cust_status == "1"){
				// 	$status = "Active";
				// }else{
				// 	$status = "Inactive";
				// }

				$output .= "<tr>
								<td>".$value->cust_code."</td>
								<td>".$value->cust_name."</td>
								<td>".$value->address_1."</td>
								<td>".$value->desc."</td>
								<td>".$value->cust_status."</td>
								<td>".$value->credit_limit."</td>
								<td>".$btn."</td>
  						    </tr>";
			}
		}else{
			$output .= "<tr>
						<td colpan='8'>No Data</td>
					  </tr>";
		}


		$output .= "</tbody>
					</table>";


		return $output;


	}
}

 ?>