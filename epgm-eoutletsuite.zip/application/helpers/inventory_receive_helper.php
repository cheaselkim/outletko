<?php 

if (!function_exists("table_receive")){
	function table_receive($query, $function){

		$output = "";

		$output .= "<table style='width: 100%' class='table table-striped' id='tbl-receive'>
					<thead>
						<tr>
							<th style='width: 12%;'>Receive No</th>
                            <th style='width: 15%;'>Receive Date</th>
                            <th style='width: 20%;'>Transaction Type</th>
                            <th style='width: 35%;'>Outlet / Vendor Name</th>
                            <th style='width: 10%;'>Total Qty</th>
                            <th style='width: 15%;'>Action</th>
						</tr>
					</thead>
					<tbody>";

		if (!empty($query)){
			$status = "";
			foreach ($query as $key => $value) {
				

				if ($function == '2'){
					$btn = "<button class='btn btn-primary' onclick='edit_receive(".$value->hdr_id.")'>Edit</button>";					
				}else if ($function == "3"){
					$btn = "<button class='btn btn-primary' onclick='view_receive(".$value->hdr_id.")'>View</button>";
				}else{
					$btn = "<button class='btn btn-danger' onclick='cancel_receive(".$value->hdr_id.", ".$key.")'>Cancel</button>";
				}

				$output .= "<tr>
								<td>".$value->inv_no."</td>
								<td>".date('m/d/Y', strtotime($value->inv_date))."</td>
								<td>".$value->inventory_ref_type."</td>
								<td>".$value->supplier_name2."</td>
								<td>".$value->total_qty."</td>
								<td>".$btn."</td>
  						    </tr>";
			}
		}else{
			$output .= "<tr>
						<td colpan='8'>No Data</td>
					  </tr>";
		}


		$output .= "</tbody>
					</table>";


		return $output;


	}
}

 ?>