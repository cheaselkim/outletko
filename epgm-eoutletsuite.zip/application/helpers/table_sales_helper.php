<?php 

if (!function_exists("table_item")){
	function table_item($query){

		$output = "";

		$output .= "<table style='width: 100%' class='table table-striped' id='table_item'>
					<thead>
						<tr>
							<th>#</th>
							<th>PN</th>
							<th>Product Name</th>
							<th>Qty</th>
							<th>UoM</th>
							<th>Price</th>
						</tr>
					</thead>
					<tbody>";

		if (!empty($query)){
			foreach ($query as $key => $value) {
				$output .= "<tr onclick='select_item(".$value->id.")'>
								<td>".($key+1)."</td>
								<td>".$value->product_no."</td>
								<td>".$value->product_name."</td>
								<td>".$value->inventory_qty."</td>
								<td>".$value->unit_desc."</td>
								<td>".number_format($value->reg_selling_price, 2)."</td>
  						    </tr>";
			}
		}else{
			$output .= "<tr>
							<td colspan='6'>No Data</td>
					  	</tr>";
		}


		$output .= "</tbody>
					</table>";


		return $output;


	}
}

if (!function_exists("table_query")){
	function table_query($query, $function){
		$output = "";
		$btn = "";


		$output .= "<table class='table table-striped'>
					<thead>
						<tr>
							<th>#</th>
							<th>Transaction No</th>
							<th>Customer</th>
							<th>Total Amount</th>
							<th>Sales Discount</th>
							<th>Grand Total</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody>";

		if (!empty($query)){
			foreach ($query as $key => $value) {

				if ($function == '2'){
					$btn = "<button class='btn btn-primary' onclick='edit_sales(".$value->id.")'>Edit</button>";					
				}else if ($function == "3"){
					$btn = "<button class='btn btn-primary' onclick='view_query(".$value->id.")'>View</button>";
				}else{
					$btn = "<button class='btn btn-danger' onclick='view_cancel(".$value->id.", ".$value->trans_no.")'>Cancel</button>";
				}

				$output .= "<tr>
								<td>".($key+1)."</td>
								<td>".$value->trans_no."</td>
								<td>".$value->cust_name."</td>
								<td>".number_format(($value->sales_discount + $value->total_amount), 2)."</td>
								<td>".number_format($value->sales_discount, 2)."</td>
								<td>".number_format($value->total_amount, 2)."</td>
								<td>".$btn."</td>
							</tr>";
			}
		}

		$output .= "</tbody>
					</table>";

		return $output;
	}
}


if (!function_exists("sales_dtl_query")){
	function sales_dtl_query($query){

		$output = "";

		$output .= "<table class='table table-striped table-bordered'>
					<tbody style='height: auto !important'>
						<tr>
							<th class='text-center' style='width: 3%;'>#</th>
							<th class='text-center'>Product No</th>
							<th class='text-center'>Product Name</th>
							<th class='text-center'>Qty</th>
							<th class='text-center'>UoM</th>
							<th class='text-center'>Selling Price</th>
							<th class='text-center'>Vol Discount</th>
							<th class='text-center'>Total Selling Price</th>
						</tr>";

		if (!empty($query)){
			foreach ($query as $key => $value) {
				$output .= "<tr>
								<td class='text-center' style='width: 3%;'>".($key+1)."</td>
								<td class='text-center'>".$value->product_no."</td>
								<td class='text-center'>".$value->product_name."</td>
								<td class='text-center'>".$value->qty."</td>
								<td class='text-center'>".$value->unit_desc."</td>
								<td class='text-center'>".number_format($value->selling_price, 2)."</td>
								<td class='text-center'>".number_format($value->volume_discount, 2)."</td>
								<td class='text-center'>".number_format($value->total_selling_price, 2)."</td>
							</tr>";
			}
		}else{

		}

		$output .= "</tbody>
					</table>";

		return $output;
	}
}
