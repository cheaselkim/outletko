<?php 

if (!function_exists("list_outlet")){
	function list_outlet($query){
		$output = "";
		$i = 0;
		$url = base_url()."assets/images/app_menu/outlet.png";
		$output .= "<div class='card-deck'>";
			foreach ($query as $key => $value) {
				$i++;
                if ($i % 5 == 0){
                  $output .="</div><div class='card-deck mt-4'>";
                } 
        $output .= "<div class='card' onclick='select_outlet(".$value->outlet_id.")'>
              <div class='card-block'>
                <div class='card-body card-body-menu text-center'>
                   <img src='".$url."' class='img-fluid'><br>
                  <label>".$value->outlet_code."</label>
                </div>              
              </div>
            </div>";
        	}
        $output .= "</div>";


		return $output;
	}
}

if (!function_exists("menu_roles")){
	function menu_roles($module,$submodule,$function_module, $query){

		$output = "";
		$count_roles = COUNT($query);
		$add_disabled = "";
		$edit_disabled = "";
		$cancel_disabled = "";
		$query_disabled = "";
		$delete_disabled = "";
		$disabled = "";
		$title = "";
		$icon = "";

		if ($count_roles == 1){
			foreach ($query as $key => $value) {
				$output .= $value->function_id;
			}
		}else{	
			$output .= "<div class='card-deck'>
				<input type='hidden' id='menu_module' value='".$module."'>
				<input type='hidden' id='menu_sub_module' value='".$submodule."' readonly>";	

				foreach ($function_module as $key => $value) {
					$function = $value->function;
					if ($function == "1"){
						$title = "Entry";
						$icon = "fa-pencil-alt";
					}else if ($function == "2"){
						$title = "Edit / Update";
						$icon = "fa-edit";
					}else if ($function == "3"){
						$title = "Query";
						$icon = "fa-info-circle";
					}else if ($function == "4"){
						$title = "Cancel";
						$icon = "fa-ban";
					}else if ($function == "5"){
						$title = "Delete";
						$icon = "fa-trash-alt";
					}

					foreach ($query as $key2 => $value2) {
						if ($function == $value2->function_id){
							$disabled = "";
							break;
						}else{
							$disabled = "disabled";
						}
					}

					$output .= "<a onclick='select_function(".$submodule.", ".$function.")' class='card ".$disabled."' readonly>
		              <div class='h-100 ".$disabled."'>
		                <div class='card-body card-body-menu text-center'>
		                  <span class='font-icons'><i class='fas ".$icon."'></i></span><br>
		                  <label>".$title."</label>
		                </div>
		              </div>             
		            </a>";
				}	

				if ($module == "5"){
					$output .= "<a onclick='select_function(".$submodule.", 6)' class='card' readonly>
		              <div class='h-100'>
		                <div class='card-body card-body-menu text-center'>
		                  <span class='font-icons'><i class='fas fa-user-cog'></i></span><br>
		                  <label>User Roles</label>
		                </div>
		              </div>             
		            </a>";					
				}else if ($module == "8"){
					$output .= "<a onclick='select_function(".$submodule.", 6)' class='card' readonly>
		              <div class='h-100'>
		                <div class='card-body card-body-menu text-center'>
		                  <span class='font-icons'><i class='fas fa-user-lock'></i></span><br>
		                  <label>Change Password</label>
		                </div>
		              </div>             
		            </a>";										
				}

			$output .= "</div>";
		}

        return $output;

	}
}

if (!function_exists("menu_roles_with_submodule")){
	function menu_roles_with_submodule($module,$submodule_query,$function_module, $query){

		$output = "";
		$submodule_name = "";
		$submodule_id = "";
		$function = "";
		$disabled = "";
		$title = "";
		$count_roles = COUNT($query);
		$add_disabled = "";
		$edit_disabled = "";
		$cancel_disabled = "";
		$query_disabled = "";
		$pt_5 = "";

		if ($count_roles == 1){
			foreach ($query as $key => $value) {
				$output .= $value->function_id;
			}
		}else{	
			$output .= '<div class="row">
			<input type="hidden" id="menu_module" value="'.$module.'">';

			foreach ($submodule_query as $key => $value) {
				$submodule_id = $value->id;
				$submodule_name = $value->sub_module_desc;

				if ($key > 3){
					$pt_5 = "pt-3";
				}else{
					$pt_5 = "";
				}

				$output .= '<div class="col-3 '.$pt_5.'"> 
              <div class="flip-card">
                <div class="flip-card-inner">
                  <div class="flip-card-front">
                    <label>'.$submodule_name.'</label>
                  </div>
                  <div class="flip-card-back">
                    <div class="list-group h-100 rounded-0">';
				foreach ($function_module as $key2 => $value2) {
					$submodule = $value2->sub_module;
					$function = $value2->function;

					if ($submodule_id == $value2->sub_module){

						if ($function == "1"){
							$title = "Entry";
							$icon = "fa-pencil-alt";
						}else if ($function == "2"){
							$title = "Edit / Update";
							$icon = "fa-edit";
						}else if ($function == "3"){
							$title = "Query";
							$icon = "fa-info-circle";
						}else if ($function == "4"){
							$title = "Cancel";
							$icon = "fa-ban";
						}else if ($function == "5"){
							$title = "Delete";
							$icon = "fa-trash-alt";
						}

						foreach ($query as $key3 => $value3) { 
							if ($function == $value3->function_id){
								$disabled = "";
								break;
							}else{
								$disabled = "disabled";
							}					
						}


		                $output .= '<a onclick="select_function('.$submodule_id.', '.$function.')" class="list-group-item list-group-item-action h-25 rounded-0 d-table text-black"><span class="prod-submenu" '.$disabled.'>'.$title.'</span></a>';
		            }else{

		            }
		        
		        }

                $output .= '</div>
	                  </div>
	                </div>
	              </div>
	              </div>';
			}
			$output .= '</div>';


		}

        return $output;

	}
}