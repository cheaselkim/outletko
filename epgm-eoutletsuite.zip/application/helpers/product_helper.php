<?php 

if (!function_exists("table_product")){
	function table_product($query, $function){

		$output = "";

		$output .= "<table style='width: 100%' class='table table-striped' id='tbl-product'>
					<thead>
						<tr>
							<th style='width: 5%;'>Line No</th>
							<th style='width: 12%;'>Product No</th>
                            <th style='width: 35%;'>Product Name</th> 
                            <th style='width: 35%;'>Product type</th>
                            <th style='width: 5%;'>Selling price</th>
                            <th style='width: 5%;'Action</th>
						</tr>
					</thead>
					<tbody>";
		if (!empty($query)){
			foreach ($query as $key => $value) {

				if ($function == '2'){
					$btn = "<button class='btn btn-primary' onclick='edit_product(".$value->id.")'>Edit</button>";					
				}else if ($function == "3"){
					$btn = "<button class='btn btn-primary' onclick='view_product(".$value->id.")'>View</button>";
				}else{
					$btn = "<button class='btn btn-danger' onclick='delete_product(".$value->id.", ".$key.")'>Delete</button>";
				}
				$output .= "<tr>
								<td>".($key+1)."</td>
								<td>".$value->product_no."</td>
								<td>".$value->product_name."</td>
								<td>".$value->prod_type_desc."</td>
								<td>".number_format($value->reg_selling_price, 2)."</td>
								<td>".$btn."</td>
  						    </tr>";
			}
		}else{
			$output .= "<tr>
						<td colpan='8'>No Data</td>
					  </tr>";
		}


		$output .= "</tbody>
					</table>";


		return $output;


	}
}

 ?>