<?php 

if (!function_exists("table_supplier")){
	function table_supplier($query, $function){

		$output = "";

		$output .= "<table style='width: 100%' class='table table-striped' id='tbl-supplier'>
					<thead>
						<tr>
							<th style='width: 8%;'>Supplier No</th>
                            <th style='width: 25%;'>Supplier Name</th>
                            <th style='width: 30%;'>Address</th>
                            <th style='width: 15%;'>Type</th>
                            <th style='width: 10%;'>Status</th>
                            <th style='width: 10%;'>Nature of Business</th>
                            <th style='width: 5%;'Action</th>
						</tr>
					</thead>
					<tbody>";

		if (!empty($query)){
			$status = "";
			foreach ($query as $key => $value) {
				

				if ($function == '2'){
					$btn = "<button class='btn btn-primary' onclick='edit_supplier(".$value->table_id.")'>Edit</button>";					
				}else if ($function == "3"){
					$btn = "<button class='btn btn-primary' onclick='view_supplier(".$value->table_id.")'>View</button>";
				}else{
					$btn = "<button class='btn btn-danger' onclick='delete_supplier(".$value->table_id.", ".$key.")'>Delete</button>";
				}

				$output .= "<tr>
								<td>".$value->supp_code."</td>
								<td>".$value->supp_name."</td>
								<td>".$value->supp_address."</td>
								<td>".$value->supplier_type."</td>
								<td>".$value->status."</td>
								<td>".$value->nature_desc."</td>
								<td>".$btn."</td>
  						    </tr>";
			}
		}else{
			$output .= "<tr>
						<td colpan='8'>No Data</td>
					  </tr>";
		}


		$output .= "</tbody>
					</table>";


		return $output;


	}
}

 ?>