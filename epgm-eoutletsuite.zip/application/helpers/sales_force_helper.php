<?php 

if (!function_exists("table_sales_force")){
	function table_sales_force($query, $function){

		$output = "";
		$status = "";

		$output .= "<table style='width: 100%' class='table table-striped' id='tbl-sales_force'>
					<thead>
						<tr>
							<th style='width: 12%;'>Outlet</th>
                            <th style='width: 25%;'>Name</th>
                            <th style='width: 10%;'>Status</th>
                            <th style='width: 5%;'>Action</th>
						</tr>
					</thead>
					<tbody>";

		if (!empty($query)){
			$status = "";
			foreach ($query as $key => $value) {

				if ($function == '2'){
					$btn = "<button class='btn btn-primary' onclick='edit_sales_force(".$value->table_id.")'>Edit</button>";					
				}else if ($function == "3"){
					$btn = "<button class='btn btn-primary' onclick='view_sales_force(".$value->table_id.")'>View</button>";
				}else{
					$btn = "<button class='btn btn-danger' onclick='delete_sales_force(".$value->table_id.", ".$key.")'>Delete</button>";
				}

				if ($value->active == "1"){
					$status = "Active";
				}else{
					$status = "Inactive";
				}

				$output .= "<tr>
								<td>".$value->outlet_name."</td>
								<td>".$value->name."</td>
								<td>".$status."</td>
								<td>".$btn."</td>
  						    </tr>";
			}
		}else{
			$output .= "<tr>
						<td colspan='4'>No Data....</td>
					  </tr>";
		}


		$output .= "</tbody>
					</table>";


		return $output;


	}
}

 ?>