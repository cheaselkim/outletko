<?php 

if (!function_exists("table_issue")){
	function table_issue($query, $function){

		$output = "";

		$output .= "<table style='width: 100%' class='table table-striped' id='tbl-issue'>
					<thead>
						<tr>
							<th style='width: 12%;'>ISSU No</th>
                            <th style='width: 25%;'>Receive Date</th>
                            <th style='width: 20%;'>Transaction Type</th>
                            <th style='width: 25%;'>Recipient Name</th>
                            <th style='width: 20%;'>Total Qty</th>
                            <th style='width: 5%;'Action</th>
						</tr>
					</thead>
					<tbody>";

		if (!empty($query)){
			$status = "";
			foreach ($query as $key => $value) {
				

				if ($function == '2'){
					$btn = "<button class='btn btn-primary' onclick='edit_issue(".$value->id.")'>Edit</button>";					
				}else if ($function == "3"){
					$btn = "<button class='btn btn-primary' onclick='view_issue(".$value->id.")'>View</button>";
				}else{
					$btn = "<button class='btn btn-danger' onclick='delete_issue(".$value->id.", ".$key.")'>Delete</button>";
				}

				$output .= "<tr>
								<td>".$value->inv_no."</td>
								<td>".date('m/d/Y', strtotime($value->inv_date))."</td>
								<td>".$value->tran_type."</td>
								<td>".$value->recipient."</td>
								<td>".$value->total_qty."</td>
								<td>".$btn."</td>
  						    </tr>";
			}
		}else{
			$output .= "<tr>
						<td colpan='8'>No Data</td>
					  </tr>";
		}


		$output .= "</tbody>
					</table>";


		return $output;


	}
}

 ?>