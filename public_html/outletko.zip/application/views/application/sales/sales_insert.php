<div class="container-fluid" style="width: 100%;background: black;">
	
	<div class="div-trans">
		
	</div>

	<div class="div-products">
		
	</div>

	<div class="div-body">
		<div class="row">
			<div class="col-5" style="background: green;">
				
			</div>
			<div class="col-7" style="background: red;">
				
			</div>
		</div>
	</div>

</div>