<!--     <link rel="stylesheet" href="<?php echo base_url('assets/css/font-awesome.min.css') ?>"> -->

<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/outletko/profile.css') ?>">

<!-- NAVRBAR -->
<nav class="navbar navbar-expand-md bg-light navbar-light" style="height: 40px;">
	<a class="navbar-brand font-small" href="#"><span class="span-eprocurement">Outlet</span><span class="text-red">Ko</span></a>
	<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
		<span class="navbar-toggler-icon"></span>
	</button>
	<div class="collapse navbar-collapse justify-content-end" id="collapsibleNavbar">

		<ul class="navbar-nav">
			<li class="nav-item">
				<a class="nav-link font-small" href="#"><span class="span-eprocurement">Outlet</span><span class="text-red">Ko</span></a>
			</li>
			<li class="nav-item">
				<a class="nav-link font-small" href="#"><span class="span-eprocurement">eOutlet</span><span class="span-suite">Suite</span></a>
			</li>
			<li class="nav-item">
				<a class="nav-link font-small" href="<?php echo base_url('/logout') ?>"><span class="font-green">Logout</span></a>
			</li>    
		</ul>
	</div>  
</nav>

<!-- END NAVBAR -->

<!-- SEARCH -->
<div class="container pt-2 ">
	<div class="row">
		<div class="col-12 col-md-12 px-0">
			<div class="row">
				<div class="col-12 col-md-6 col-lg-5 pad-right">
					<div class="input-group">
						<div class="input-group-prepend">
							<span class="input-group-text textbox-orange bg-white" id="basic-addon1"><i class="fa fa-search"></i></span>
						</div>
						<input type="text" class="form-control textbox-orange border-left-0 pl-1" id="searchbox" aria-describedby="basic-addon1">
					</div>
				</div>

				<div class="col-12 col-md-3 col-lg-2 pad-center">
					<div class="input-group">
						<div class="input-group-prepend">
							<span class="input-group-text textbox-orange bg-white" id="basic-addon1"><i class="fa fa-location-arrow"></i></span>
						</div>
						<input type="text" class="form-control textbox-orange border-left-0 pl-1" id="location" placeholder="Metro Manila" aria-label="Username" aria-describedby="basic-addon1">
					</div>
				</div>

				<div class="col-12 col-md-2 col-lg-2 pad-left">
					<button class="btn btn-block btn-warning font-small font-weight-600">Search</button>
				</div>
			</div>
		</div>
		
	</div>
</div>
<!-- END SEARCH -->