<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Signup extends CI_Controller {

    public function __construct(){
        parent::__construct();
            $this->load->model("signup_model");
    }


    public function business_category(){
        $data['result'] = $this->signup_model->business_category();
		$data['token'] = $this->security->get_csrf_hash();
        echo json_encode($data);
    }
    
    public function save_data() {
		$status = "failed";
        $info_outletsuite = $this->input->post('info_outletsuite', TRUE);
        $info_outletko = $this->input->post('info_outletko', TRUE);
        $info_outletko['date_insert'] = date("Y-m-d H:i:s");
        $info_outletsuite['date_created'] =  date("Y-m-d H:i:s");
	    
  	    $pass = $info_outletko['password'];
  		$email = $info_outletko['email'];
  		$uname = $info_outletko['username'];
  		
  		$year = date("y");
  		$user_type= "1";
		$account_id_result = $this->signup_model->account_id();
        $account_id = $year.$user_type.$account_id_result;
 		
 		$hashed_password = password_hash($pass, PASSWORD_DEFAULT);	
		$account=array(
			'account_id'=>$account_id,
			'account_name'=>$info_outletko['account_name'],
			'account_status'=>$info_outletko['account_status'],
			'business_category'=>$info_outletko['business_category'],
			'user_id'=>$info_outletko['user_id'],
			'first_name'=>$info_outletko['first_name'],
			'middle_name'=>$info_outletko['middle_name'],
			'last_name'=>$info_outletko['last_name'],
			'address'=>$info_outletko['address'],
			'confirm_email'=>$info_outletko['confirm_email'],
			'city'=>$info_outletko['city'],
			'email'=>$info_outletko['email'],
			'mobile_no'=>$info_outletko['mobile_no'],
			'date_insert'=>date("Y-m-d H:i:s")
		);
		
		
		
	
		$email_check = $this->signup_model->email_check($account['email']);
    $res = "";
    $send_email = ""; 

 		if($email_check){
 		    $res = $this->signup_model->register($account);
 		    $account2=array(
    			'account_id'=>$account_id,
    			'status'=>$info_outletko['account_status'],
    			'comp_id'=>$res,
    			'first_name'=>$info_outletko['first_name'],
    			'middle_name'=>$info_outletko['middle_name'],
    			'last_name'=>$info_outletko['last_name'],
     			'password'=>$hashed_password,
     			'user_type'=>$user_type,
    			'email'=>$info_outletko['email'],
     			'username'=>$info_outletko['username'],
          'account_type' => "0",
          'otp' => "0",
          'all_access' => "1"
    		);
    		$res2 = $this->signup_model->register_users($account2);
 			$send_email =  $this->send_email($email,$res,$uname,$pass);
		}else{
			$error = 'Email Already Exist !';
      $send_email = false;
			//$this->load->view('register' , $data);
		}
		
        if($send_email == true){
            $status = "success";
        }else{
            $status = "failed";
        }

        echo json_encode(array('status' => $status, "id" => $res, 'token' => $this->security->get_csrf_hash()));       
    }
    
    public function send_mail2($res,$email,$uname,$pass) { 
        

        $this->load->library('email');
        $config = array(
              'protocol'  => 'smtp',
              'smtp_host' => 'ssl://smtp.gmail.com',
              'smtp_port' => 465,
              'smtp_user' => 'epgmcompany@eoutletsuite.com',
              'smtp_pass' => 'epgmcompany101',
              'mailtype'  => 'html',
              'charset'   => 'utf-8'
        );
        // $hashed_email = password_hash($email, PASSWORD_DEFAULT);
        // var_dump($hashed_email);

        $message = $this->load->view();

        $this->email->initialize($config);
        $this->email->set_mailtype("text");
        $this->email->set_newline("\r\n");
        $this->email->to($email);
        $this->email->from('ellednaj11@gmail.com','Eoutletsuite');
        $this->email->subject('Email Verification');
        $this->email->message ("
        Thanks for signing up!
        You're almost ready to start your business in outletko - but first, click the link below to verify your email address

        Please click this link to activate your account:
        http://www.eoutletsuite.com/Signup/verify?id=$res&hash=$hashed_email
        ");

        // Your account has been created, you can login with you after you have activated your account by pressing the url below.

        // ------------------------
        // Username: $uname
        // Password: $pass
        // ------------------------

        //Send email
        if($this->email->send()) {
                return true;
                $this->session->set_flashdata("email_sent","Email sent successfully."); 
             	$this->load->view('message');}
        else {
                return false;
                $this->session->set_flashdata("email_sent","Error in sending Email."); 
        }
        
    }
    
    public function insert_account(){
		$user_app_result = 0;
		$users_result = 0;
		$email_result = 0;
		
		$year = date("y");
  		$user_type= "1";
  		$account_class = "1";
		$account_id_result = $this->signup_model->account_id();
        $account_id = $year.$user_type.$account_id_result;
        // $pass = $this->input->post("password", TRUE);
        // $hashed_password = password_hash($pass, PASSWORD_DEFAULT);	

		$user_app = array(
			"last_name" => strtoupper($this->input->post("last_name", TRUE)),
			"first_name" => strtoupper($this->input->post("first_name", TRUE)),
			"email" => $this->input->post("email", TRUE),
			"account_id" => $account_id,
			"account_status" => "1",
			"account_class" => "1",
			"account_type" => $user_type,
			"business_type" => $this->input->post("business_type", TRUE),
			"outlet_no" => "2",
			"date_insert" => date('Y-m-d H:i:s')
			);

		$user_app_result = $this->user_registry_model->insert_account($user_app);

		if ($account_class == "1"){
			$user_type2 = 2;
		}else{
			$user_type2 = 3;
		}


		$users = array(
			"comp_id" => $user_app_result,
			"account_id" => $account_id,
			"account_type" => "1",
			"first_name" => strtoupper($this->input->post("first_name", TRUE)),
			"last_name" => strtoupper($this->input->post("last_name", TRUE)),
			"username" => $account_id,
			"email" => $this->input->post("email", TRUE),
			"user_type" => $user_type2,
			"all_access" => "1"
		);

		$users_result = $this->user_registry_model->insert_users($users);
		$outlet_result = $this->user_registry_model->insert_outlet(array("user_id" => $users_result, "outlet_id" => "0"));
		$product_color = $this->user_registry_model->insert_product_color($user_app_result);
		$product_unit = $this->user_registry_model->insert_product_unit($user_app_result);
		$sales_discount = $this->user_registry_model->insert_sales_discount($user_app_result);
		$customer = $this->user_registry_model->insert_customer($user_app_result);
		$email_result = $this->send_email($this->input->post("email", TRUE), $this->input->post("account_id", TRUE));

		echo json_encode(array("user_app" => $user_app_result, "users" => $outlet_result, "email" => $email_result, 'token' => $this->security->get_csrf_hash()));

	}
	
	public function send_email($email, $account_id){
		$this->load->library("email");
		$status = 0;
		$randomString = $this->randomString();
		$result = $this->password_model->find_accountid($account_id, $randomString);
        $data = array();

        $data['account_id'] = $account_id;
        $data['password'] = $randomString;

        $message = $this->load->view("admin/email/email", $data, TRUE);

		if ($result > 0){
	        $config = array(
                        'protocol' => 'mail',
                        'mail_type' => 'html',
                        'smtp_host' => 'mail.outletko.com',
                        'smtp_port' => 465,
                        'smtp_user' => 'noreply@outletko.com',
                        'smtp_pass' => 'eoutletsuite_noreply',
                        'charset' => 'iso-8859-1',
                        'wordwrap' => TRUE

	                );


	        $this->email->initialize($config)
	                    ->set_newline("\r\n")
	                    ->from('noreply@outletko.com', 'eOutletSuite Application')
	                    ->to($email)
	                    ->subject('eOutletSuite Account Register')
	                    ->message($message);


	        if($this->email->send()) {
	        	$status = 1;
	        }else {
	        	$status = $this->email->print_debugger();
        	}
	    }else{
	    	$status = 0;
	    }
        // $status = 1;

		// var_dump($email);        

	    // var_dump($this->email->initialize($config));

        // var_dump($this->email->print_debugger());        

	    // var_dump($status);
	    
	    return $status;

	}

}
