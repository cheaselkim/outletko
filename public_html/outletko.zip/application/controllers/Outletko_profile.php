<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Outletko_profile extends CI_Controller {

	public function __construct(){
	    parent::__construct();
            $this->load->model("activity_model");
	      	$this->load->model("outletko_profile_model");
	      	$this->load->helper("outlet");
			$result = $this->login_model->check_session();
			if ($result != true){
				redirect("/");
			}

		/* 
			Note for function 
			1 = Insert
			2 = Edit / Update
			3 = Delete / Cancel
			4 = Query
	
			model function for history is already autoload;
			$this->activity_model->insert_activity($module, $submodule, $function);
			(if module has no submodule, submodule automatically 0);
		 */
	}

    

    

	public function get_profile_dtl(){
    	$id = $this->session->userdata("account_id");
    	$data['result'] = $this->outletko_profile_model->get_profile_dtl($id);
    	$data['token'] = $this->security->get_csrf_hash();
		echo json_encode($data);
    }

    public function edit_outlet() {
		
		$outlet_id = $this->input->post('outlet_id', TRUE);
        $outlet_hdr = $this->input->post('outlet_hdr', TRUE);
        $query = $this->sales_model->edit_outlet($outlet_hdr,$outlet_id);
        if($query == true){
            $status = "success";
        }else{
            $status = "failed";
        }
        $this->output->set_content_type('application/json');
        echo json_encode(array('status' => $status));       
    }

    //FOR UPDATE
    public function update_outlet() {
		$outlet_id = $this->input->post('outlet_id', TRUE);
        $outlet_hdr = $this->input->post('outlet_hdr', TRUE);
        $query = $this->outlet_model->update_outlet($outlet_hdr,$outlet_id);
        if($query == true){
            $status = "success";
        }else{
            $status = "failed";
        }
        $this->output->set_content_type('application/json');
        echo json_encode(array('status' => $status, 'token' => $this->security->get_csrf_hash()));       
    }

    public function delete_outlet(){
        $id = $this->input->post("id", TRUE);
        $data['result'] = $this->outlet_model->delete_outlet($id);
        $data['token'] = $this->security->get_csrf_hash();
        echo json_encode($data);        
    }

    public function cancel_outlet(){
        $id = $this->input->post("id", TRUE);
        $data['result'] = $this->outlet_model->cancel_outlet($id);
        $data['token'] = $this->security->get_csrf_hash();
        echo json_encode($data);                
    }

    public function select_id(){
        $id = $this->input->post("id", TRUE);
        $data['result'] = $this->outlet_model->get_outlet_dtl($id);
        $data['token'] = $this->security->get_csrf_hash();
        echo json_encode($data);
    }


    public function all_outlet_list(){
        $result = $this->outlet_model->all_outlet_list();
        $data['data'] = list_outlet($result);
        $data['token'] = $this->security->get_csrf_hash();
        echo json_encode($data);
    }

}
