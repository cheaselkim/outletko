<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Signup_model extends CI_Model {

	public function __construct(){
		parent::__construct();
		$this->load->database();
	}	

	public function business_category(){
		$query = $this->db->query("SELECT * FROM business_type")->result();
		return $query;
	}
	public function account_id(){
        $result = $this->db->query("SELECT account_id FROM users ORDER BY id DESC LIMIT 1")->row();
		return str_pad((substr($result->account_id, -4) + 1), 4, '0', STR_PAD_LEFT); 		
	}
    
    public function email_check($email){
        $this->db2->select('*');
        $this->db2->from('outletko_account');
        $this->db2->where('email',$email);
        $query=$this->db2->get();
        
        if($query->num_rows()>0){
                return false;
        }
        else{
                return true;
        }
 
    }
    
    public function register($account){
        $this->db2->insert('outletko_account', $account);
        return ($this->db2->affected_rows() == 1) ? $this->db2->insert_id() : false;
    }
    
    public function register_users($account){
        $this->db->insert('users', $account);
        return ($this->db->affected_rows() == 1) ? $this->db->insert_id() : false;
    }
    
    public function insert_account($user_app){
        $this->db->insert("account_application", $user_app);
        return ($this->db->affected_rows() > 0) ? $this->db->insert_id() : 0;		
	}

	public function insert_users($users){
        $this->db->insert("users", $users);
        return ($this->db->affected_rows() > 0) ? $this->db->insert_id() : 0;		
	}
}